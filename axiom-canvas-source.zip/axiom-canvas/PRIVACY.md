# Privacy

Axiom Canvas collects and transmits no data. It requests no network, location, contacts, camera, microphone, or storage-wide permission.

Named boards and drawings are autosaved in the app's private on-device storage. Export and import use Android's system document picker, so the app can access only the file location the user explicitly chooses. Removing the app may remove its private boards; export an Axiom project backup first if a drawing matters.
