package io.axiom.canvas;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PointF;
import android.graphics.RectF;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Geometry objects and their portable, backwards-compatible project representation. */
final class GeometryModel {
    enum Kind {
        POINT, FREEHAND, SEGMENT, LINE, RAY, RULER,
        CIRCLE, CIRCLE_MEASURE, ARC, ELLIPSE, RECTANGLE,
        TRIANGLE, POLYGON, REGULAR_POLYGON, AREA,
        ANGLE, PROTRACTOR, TEXT, GRAPH
    }

    enum GraphMode { CARTESIAN, POLAR, PARAMETRIC, PIECEWISE, IMPLICIT, INEQUALITY, DERIVATIVE }

    static final class Viewport {
        float scale = 72f;
        float density=1;
        float panX;
        float panY;
        int width;
        int height;
        double measurementScale = 1d;
        String measurementUnit = "units";
        int measurementPrecision = 2;
        boolean darkCanvas;

        PointF toScreen(PointF p) {
            return new PointF(width * .5f + panX + p.x * scale,
                    height * .5f + panY - p.y * scale);
        }

        PointF toWorld(float sx, float sy) {
            return new PointF((sx - width * .5f - panX) / scale,
                    -(sy - height * .5f - panY) / scale);
        }

        float left() { return (-width * .5f - panX) / scale; }
        float right() { return (width * .5f - panX) / scale; }
        float top() { return (height * .5f + panY) / scale; }
        float bottom() { return (-height * .5f + panY) / scale; }
    }

    abstract static class GeoObject {
        final Kind kind;
        int color;
        float strokeWidth;
        boolean selected;
        boolean visible = true;
        boolean locked;
        int dashStyle;
        float fillOpacity = .08f;
        String name = "";
        String id=java.util.UUID.randomUUID().toString(),groupId="";
        boolean measured; float labelDx,labelDy; final RectF labelBounds=new RectF();

        GeoObject(Kind kind, int color, float strokeWidth) {
            this.kind = kind;
            this.color = color;
            this.strokeWidth = strokeWidth;
            measured=kind==Kind.RULER||kind==Kind.PROTRACTOR||kind==Kind.AREA||kind==Kind.CIRCLE_MEASURE;
        }

        abstract void draw(Canvas canvas, Viewport view, Paint stroke, Paint fill, Paint text);
        abstract boolean hit(PointF p, float tolerance);
        abstract void translate(float dx, float dy);
        abstract JSONArray encodePoints() throws JSONException;
        abstract ArrayList<PointF> handles();

        JSONObject toJson() throws JSONException {
            JSONObject json = new JSONObject();
            json.put("kind", kind.name());
            json.put("color", color);
            json.put("width", strokeWidth);
            json.put("measured",measured);json.put("labelDx",labelDx);json.put("labelDy",labelDy);
            json.put("points", encodePoints());
            json.put("visible", visible);
            json.put("locked", locked);
            json.put("dash", dashStyle);
            json.put("fill", fillOpacity);
            json.put("id",id);if(!groupId.isEmpty())json.put("group",groupId);
            if (!name.isEmpty()) json.put("name", name);
            return json;
        }

        void configure(Paint stroke, Paint fill) {
            stroke.setColor(color);
            stroke.setStrokeWidth(strokeWidth);
            stroke.setStyle(Paint.Style.STROKE);
            stroke.setStrokeCap(Paint.Cap.ROUND);
            stroke.setStrokeJoin(Paint.Join.ROUND);
            if (dashStyle == 1) stroke.setPathEffect(new DashPathEffect(new float[]{18, 12}, 0));
            else if (dashStyle == 2) stroke.setPathEffect(new DashPathEffect(new float[]{3, 9}, 0));
            else stroke.setPathEffect(null);
            int alpha = Math.max(0, Math.min(255, Math.round(fillOpacity * 255f)));
            fill.setColor((color & 0x00FFFFFF) | (alpha << 24));
            fill.setStyle(Paint.Style.FILL);
        }

        void selection(Canvas canvas, Viewport view, Paint paint, List<PointF> points) {
            if (!selected) return;
            paint.setColor(locked ? 0xFFE49B38 : 0xFF6C8CFF);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(2.5f);
            paint.setPathEffect(null);
            for (PointF p : points) {
                PointF s = view.toScreen(p);
                paint.setStyle(Paint.Style.FILL);paint.setColor(Color.WHITE);canvas.drawCircle(s.x,s.y,7f*view.density,paint);paint.setStyle(Paint.Style.STROKE);paint.setColor(0xFF6558D9);canvas.drawCircle(s.x,s.y,7f*view.density,paint);
            }
        }

        void rotateScale(float cx, float cy, float degrees, float factor) {
            double radians = Math.toRadians(degrees);
            double cosine = Math.cos(radians), sine = Math.sin(radians);
            for (PointF point : handles()) {
                float x = point.x - cx, y = point.y - cy;
                point.x = cx + factor * (float) (x * cosine - y * sine);
                point.y = cy + factor * (float) (x * sine + y * cosine);
            }
        }

        PointF center() {
            ArrayList<PointF> points = handles();
            if (points.isEmpty()) return new PointF();
            float x = 0, y = 0;
            for (PointF point : points) { x += point.x; y += point.y; }
            return new PointF(x / points.size(), y / points.size());
        }

        String displayName() { return name.isEmpty() ? friendlyKind(kind) : name; }
    }

    static final class PointObject extends GeoObject {
        final PointF point;
        boolean showCoordinates;

        PointObject(PointF point, int color, float width) { this(point, color, width, false); }
        PointObject(PointF point, int color, float width, boolean showCoordinates) {
            super(Kind.POINT, color, width);
            this.point = new PointF(point.x, point.y);
            this.showCoordinates = showCoordinates; this.measured=showCoordinates;
        }

        @Override void draw(Canvas c, Viewport v, Paint s, Paint f, Paint t) {
            configure(s, f);
            PointF p = v.toScreen(point);
            s.setStyle(Paint.Style.FILL);
            c.drawCircle(p.x, p.y, Math.max(4.5f, strokeWidth + 2), s);
            if (!name.isEmpty()) label(c,p.x,p.y-17,name,t);
            selection(c, v, s, list(point));
        }

        @Override boolean hit(PointF p, float tolerance) { return distance(point, p) <= tolerance; }
        @Override void translate(float dx, float dy) { point.offset(dx, dy); }
        @Override JSONArray encodePoints() { return points(point); }
        @Override ArrayList<PointF> handles() { return list(point); }
        @Override JSONObject toJson() throws JSONException {
            JSONObject json = super.toJson();
            json.put("coordinates", showCoordinates);
            return json;
        }
    }

    static final class FreehandObject extends GeoObject {
        final ArrayList<PointF> path;
        FreehandObject(List<PointF> path, int color, float width) {
            super(Kind.FREEHAND, color, width);
            this.path = copy(path);
            fillOpacity = 0;
        }
        @Override void draw(Canvas c, Viewport v, Paint s, Paint f, Paint t) {
            if (path.isEmpty()) return;
            configure(s, f);
            c.drawPath(path(path, v, false), s);
            selection(c, v, s, list(path.get(0), path.get(path.size() - 1)));
        }
        @Override boolean hit(PointF p, float tolerance) {
            for (int i = 1; i < path.size(); i++) if (segmentDistance(p, path.get(i - 1), path.get(i)) <= tolerance) return true;
            return false;
        }
        @Override void translate(float dx, float dy) { for (PointF p : path) p.offset(dx, dy); }
        @Override JSONArray encodePoints() { return points(path); }
        @Override ArrayList<PointF> handles() { return path; }
    }

    static final class TwoPointObject extends GeoObject {
        final PointF a;
        final PointF b;
        TwoPointObject(Kind kind, PointF a, PointF b, int color, float width) {
            super(kind, color, width);
            this.a = new PointF(a.x, a.y);
            this.b = new PointF(b.x, b.y);
            fillOpacity = 0;
        }
        @Override void draw(Canvas c, Viewport v, Paint s, Paint f, Paint t) {
            configure(s, f);
            PointF aa = v.toScreen(a), bb = v.toScreen(b);
            if (kind == Kind.LINE || kind == Kind.RAY) {
                float dx = bb.x - aa.x, dy = bb.y - aa.y;
                float length = (float) Math.hypot(dx, dy);
                if (length > .01f) {
                    dx /= length; dy /= length;
                    if (kind == Kind.LINE) c.drawLine(aa.x - dx * 10000, aa.y - dy * 10000, aa.x + dx * 10000, aa.y + dy * 10000, s);
                    else c.drawLine(aa.x, aa.y, aa.x + dx * 10000, aa.y + dy * 10000, s);
                }
            } else c.drawLine(aa.x, aa.y, bb.x, bb.y, s);
            drawVertex(c, aa, s); drawVertex(c, bb, s);
            if (kind == Kind.RULER) drawDistanceMeasurement(c, v, s, aa, bb);
            selection(c, v, s, list(a, b));
        }

        private void drawDistanceMeasurement(Canvas c, Viewport v, Paint source, PointF aa, PointF bb) {
            float dx = bb.x - aa.x, dy = bb.y - aa.y;
            float length = (float) Math.hypot(dx, dy);
            if (length < .01f) {
                return;
            }
            float nx = -dy / length, ny = dx / length;
            if (ny > 0) { nx = -nx; ny = -ny; }
            float offset = 23f;
            PointF da = new PointF(aa.x + nx * offset, aa.y + ny * offset);
            PointF db = new PointF(bb.x + nx * offset, bb.y + ny * offset);
            Paint dimension = new Paint(source);
            dimension.setColor(color);
            dimension.setStrokeWidth(Math.max(1.5f, strokeWidth * .55f));
            dimension.setPathEffect(null);
            dimension.setAlpha(210);
            c.drawLine(aa.x, aa.y, da.x, da.y, dimension);
            c.drawLine(bb.x, bb.y, db.x, db.y, dimension);
            c.drawLine(da.x, da.y, db.x, db.y, dimension);
            drawArrow(c, da, db, dimension);
            drawArrow(c, db, da, dimension);
        }
        @Override boolean hit(PointF p, float tolerance) {
            if (kind == Kind.LINE) return lineDistance(p, a, b) <= tolerance;
            if (kind == Kind.RAY) return rayDistance(p, a, b) <= tolerance;
            return segmentDistance(p, a, b) <= tolerance;
        }
        @Override void translate(float dx, float dy) { a.offset(dx, dy); b.offset(dx, dy); }
        @Override JSONArray encodePoints() { return points(a, b); }
        @Override ArrayList<PointF> handles() { return list(a, b); }
    }

    static final class CircleObject extends GeoObject {
        final PointF center;
        final PointF edge;
        CircleObject(PointF center, PointF edge, int color, float width) { this(Kind.CIRCLE, center, edge, color, width); }
        CircleObject(Kind kind, PointF center, PointF edge, int color, float width) {
            super(kind, color, width);
            this.center = new PointF(center.x, center.y);
            this.edge = new PointF(edge.x, edge.y);
        }
        float radius() { return distance(center, edge); }
        @Override void draw(Canvas c, Viewport v, Paint s, Paint f, Paint t) {
            configure(s, f);
            PointF cc = v.toScreen(center);
            float r = radius() * v.scale;
            c.drawCircle(cc.x, cc.y, r, f); c.drawCircle(cc.x, cc.y, r, s); drawVertex(c, cc, s);
            selection(c, v, s, list(center, edge));
        }
        @Override boolean hit(PointF p, float tolerance) { return Math.abs(distance(center, p) - radius()) <= tolerance || distance(center, p) <= tolerance; }
        @Override void translate(float dx, float dy) { center.offset(dx, dy); edge.offset(dx, dy); }
        @Override JSONArray encodePoints() { return points(center, edge); }
        @Override ArrayList<PointF> handles() { return list(center, edge); }
    }

    static final class EllipseObject extends GeoObject {
        final PointF center;
        final PointF edge;
        EllipseObject(PointF center, PointF edge, int color, float width) {
            super(Kind.ELLIPSE, color, width);
            this.center = new PointF(center.x, center.y);
            this.edge = new PointF(edge.x, edge.y);
        }
        float radiusX() { return Math.abs(edge.x - center.x); }
        float radiusY() { return Math.abs(edge.y - center.y); }
        @Override void draw(Canvas c, Viewport v, Paint s, Paint f, Paint t) {
            configure(s, f);
            PointF cc = v.toScreen(center);
            RectF oval = new RectF(cc.x - radiusX() * v.scale, cc.y - radiusY() * v.scale,
                    cc.x + radiusX() * v.scale, cc.y + radiusY() * v.scale);
            c.drawOval(oval, f); c.drawOval(oval, s); drawVertex(c, cc, s);
            selection(c, v, s, list(center, edge));
        }
        @Override boolean hit(PointF p, float tolerance) {
            float rx = Math.max(.00001f, radiusX()), ry = Math.max(.00001f, radiusY());
            double normalized = Math.sqrt(Math.pow((p.x - center.x) / rx, 2) + Math.pow((p.y - center.y) / ry, 2));
            return Math.abs(normalized - 1) <= tolerance / Math.min(rx, ry) || distance(p, center) <= tolerance;
        }
        @Override void translate(float dx, float dy) { center.offset(dx, dy); edge.offset(dx, dy); }
        @Override JSONArray encodePoints() { return points(center, edge); }
        @Override ArrayList<PointF> handles() { return list(center, edge); }
    }

    static final class ArcObject extends GeoObject {
        final PointF center, start, end;
        ArcObject(PointF center, PointF start, PointF end, int color, float width) {
            super(Kind.ARC, color, width);
            this.center = new PointF(center.x, center.y);
            this.start = new PointF(start.x, start.y);
            this.end = new PointF(end.x, end.y);
            fillOpacity = 0;
        }
        @Override void draw(Canvas c, Viewport v, Paint s, Paint f, Paint t) {
            configure(s, f);
            PointF cc = v.toScreen(center);
            float r = distance(center, start) * v.scale;
            float from = screenAngle(center, start);
            float sweep = normalizeSweep(screenAngle(center, end) - from);
            c.drawArc(new RectF(cc.x - r, cc.y - r, cc.x + r, cc.y + r), from, sweep, false, s);
            selection(c, v, s, list(center, start, end));
        }
        @Override boolean hit(PointF p, float tolerance) { return Math.abs(distance(center, p) - distance(center, start)) <= tolerance; }
        @Override void translate(float dx, float dy) { center.offset(dx, dy); start.offset(dx, dy); end.offset(dx, dy); }
        @Override JSONArray encodePoints() { return points(center, start, end); }
        @Override ArrayList<PointF> handles() { return list(center, start, end); }
    }

    static final class PolyObject extends GeoObject {
        final ArrayList<PointF> vertices;
        PolyObject(Kind kind, List<PointF> points, int color, float width) {
            super(kind, color, width);
            vertices = copy(points);
            if (kind == Kind.ANGLE || kind == Kind.PROTRACTOR) fillOpacity = 0;
        }
        boolean closed() { return kind != Kind.ANGLE && kind != Kind.PROTRACTOR; }
        @Override void draw(Canvas c, Viewport v, Paint s, Paint f, Paint t) {
            if (vertices.isEmpty()) return;
            configure(s, f);
            Path p = path(vertices, v, closed());
            if (closed() && vertices.size() >= 3) c.drawPath(p, f);
            c.drawPath(p, s);
            for (PointF vertex : vertices) drawVertex(c, v.toScreen(vertex), s);
            if ((kind == Kind.ANGLE || kind == Kind.PROTRACTOR) && vertices.size() == 3) drawAngle(c, v, s, t);
            selection(c, v, s, vertices);
        }
        private void drawAngle(Canvas c, Viewport v, Paint s, Paint t) {
            PointF a = vertices.get(0), o = vertices.get(1), b = vertices.get(2);
            PointF so = v.toScreen(o);
            float start = screenAngle(o, a);
            float sweep = normalizeSweep(screenAngle(o, b) - start);
            if (sweep > 180) { start += sweep; sweep = 360 - sweep; }
            float radius = Math.min(42f, Math.min(distance(o, a), distance(o, b)) * v.scale * .35f);
            c.drawArc(new RectF(so.x - radius, so.y - radius, so.x + radius, so.y + radius), start, sweep, false, s);
        }
        @Override boolean hit(PointF p, float tolerance) {
            for (int i = 1; i < vertices.size(); i++) if (segmentDistance(p, vertices.get(i - 1), vertices.get(i)) <= tolerance) return true;
            return closed() && vertices.size() > 2 && segmentDistance(p, vertices.get(vertices.size() - 1), vertices.get(0)) <= tolerance;
        }
        @Override void translate(float dx, float dy) { for (PointF p : vertices) p.offset(dx, dy); }
        @Override JSONArray encodePoints() { return points(vertices); }
        @Override ArrayList<PointF> handles() { return vertices; }
    }

    static final class TextObject extends GeoObject {
        final PointF position;
        String value;
        TextObject(PointF position, String value, int color, float width) {
            super(Kind.TEXT, color, width);
            this.position = new PointF(position.x, position.y);
            this.value = value == null ? "" : value;
            fillOpacity = 0;
        }
        @Override void draw(Canvas c, Viewport v, Paint s, Paint f, Paint t) {
            PointF p = v.toScreen(position);
            float oldSize = t.getTextSize();
            int oldColor = t.getColor();
            Paint.Align oldAlign = t.getTextAlign();
            t.setColor(color); t.setTextSize(Math.max(13, 10 + strokeWidth * 1.6f)); t.setTextAlign(Paint.Align.LEFT);
            c.drawText(value, p.x, p.y, t);
            t.setTextSize(oldSize); t.setColor(oldColor); t.setTextAlign(oldAlign);
            selection(c, v, s, list(position));
        }
        @Override boolean hit(PointF p, float tolerance) { return distance(position, p) <= tolerance * 2.2f; }
        @Override void translate(float dx, float dy) { position.offset(dx, dy); }
        @Override JSONArray encodePoints() { return points(position); }
        @Override ArrayList<PointF> handles() { return list(position); }
        @Override JSONObject toJson() throws JSONException { JSONObject json = super.toJson(); json.put("text", value); return json; }
    }

    static final class GraphObject extends GeoObject {
        final GraphMode mode;
        String expression;
        String expressionY;
        double domainMin;
        double domainMax;
        double parameterA,parameterB=1,parameterC;private ExpressionParser.VariableExpression compiledA,compiledB;

        GraphObject(String expression, int color, float width) { this(GraphMode.CARTESIAN, expression, "", -1e9, 1e9, color, width); }
        GraphObject(GraphMode mode, String expression, String expressionY, double domainMin, double domainMax, int color, float width) {
            super(Kind.GRAPH, color, width);
            this.mode = mode; this.expression = expression; this.expressionY = expressionY == null ? "" : expressionY;
            this.domainMin = domainMin; this.domainMax = domainMax; fillOpacity = 0; compile();
        }
        GraphObject parameters(double a,double b,double c){parameterA=a;parameterB=b;parameterC=c;return this;}
        private void compile() {
            try { compiledA = ExpressionParser.compileVariables(expression); } catch (RuntimeException ignored) { compiledA = v -> Double.NaN; }
            if (mode == GraphMode.PARAMETRIC) {
                try { compiledB = ExpressionParser.compileVariables(expressionY); } catch (RuntimeException ignored) { compiledB = v -> Double.NaN; }
            }
        }
        private double value(double x,double y){return compiledA.evaluate(name->{switch(name){case"x":case"t":case"theta":return x;case"y":return y;case"a":return parameterA;case"b":return parameterB;case"c":return parameterC;default:return 0;}});}private double second(double t){return compiledB==null?Double.NaN:compiledB.evaluate(name->{switch(name){case"x":case"t":case"theta":return t;case"a":return parameterA;case"b":return parameterB;case"c":return parameterC;default:return 0;}});}
        PointF pointAt(double variable) {
            if(mode==GraphMode.CARTESIAN||mode==GraphMode.PIECEWISE)return new PointF((float)variable,(float)value(variable,0));
            if(mode==GraphMode.DERIVATIVE){double h=Math.max(1e-6,Math.abs(variable)*1e-6);return new PointF((float)variable,(float)((value(variable+h,0)-value(variable-h,0))/(2*h)));}
            if (mode == GraphMode.POLAR) {
                double r = value(variable,0);
                return new PointF((float) (r * Math.cos(variable)), (float) (r * Math.sin(variable)));
            }
            return new PointF((float)value(variable,0),(float)second(variable));
        }
        String equation() {
            if (mode == GraphMode.CARTESIAN) return "y = " + expression;
            if(mode==GraphMode.PIECEWISE)return"piecewise y = "+expression;if(mode==GraphMode.DERIVATIVE)return"d/dx ("+expression+")";if(mode==GraphMode.IMPLICIT)return expression+" = 0";if(mode==GraphMode.INEQUALITY)return expression;
            if (mode == GraphMode.POLAR) return "r = " + expression;
            return "x = " + expression + "  •  y = " + expressionY;
        }
        @Override void draw(Canvas c, Viewport v, Paint s, Paint f, Paint t) {
            configure(s, f);
            if(mode==GraphMode.IMPLICIT||mode==GraphMode.INEQUALITY){drawRelation(c,v,s,f);if(selected)label(c,112,30,equation(),t);return;}
            Path curve = new Path(); boolean started = false; float previousX = 0, previousY = 0;
            int samples; double from, to;
            if (mode == GraphMode.CARTESIAN||mode==GraphMode.PIECEWISE||mode==GraphMode.DERIVATIVE) { samples = Math.max(2, v.width / 2); from = Math.max(v.left(), domainMin); to = Math.min(v.right(), domainMax); }
            else { samples = Math.max(420, v.width); from = domainMin; to = domainMax; }
            if (!Double.isFinite(from) || !Double.isFinite(to) || to <= from) return;
            for (int i = 0; i <= samples; i++) {
                PointF world = pointAt(from + (to - from) * i / samples);
                if (!Float.isFinite(world.x) || !Float.isFinite(world.y) || Math.abs(world.x) > 1e8 || Math.abs(world.y) > 1e8) { started = false; continue; }
                PointF screen = v.toScreen(world); float jump = (float) Math.hypot(screen.x - previousX, screen.y - previousY);
                if (!started || jump > Math.max(v.width, v.height) * .75f) { curve.moveTo(screen.x, screen.y); started = true; }
                else curve.lineTo(screen.x, screen.y);
                previousX = screen.x; previousY = screen.y;
            }
            c.drawPath(curve, s);
            if (selected) label(c, 112, 30, equation(), t);
        }
        private void drawRelation(Canvas canvas,Viewport v,Paint s,Paint f){int step=mode==GraphMode.INEQUALITY?10:6;float threshold=Math.max(.03f,step/v.scale);f.setColor((color&0x00FFFFFF)|0x33000000);f.setStyle(Paint.Style.FILL);s.setStyle(Paint.Style.FILL);for(int y=0;y<v.height;y+=step)for(int x=0;x<v.width;x+=step){PointF p=v.toWorld(x+step*.5f,y+step*.5f);double relation=value(p.x,p.y);if(mode==GraphMode.INEQUALITY){if(relation>.5)canvas.drawRect(x,y,x+step+1,y+step+1,f);}else if(Double.isFinite(relation)&&Math.abs(relation)<threshold)canvas.drawCircle(x+step*.5f,y+step*.5f,Math.max(1.5f,strokeWidth*.4f),s);}}
        @Override boolean hit(PointF p, float tolerance) {
            if(mode==GraphMode.IMPLICIT)return Math.abs(value(p.x,p.y))<=tolerance;if(mode==GraphMode.INEQUALITY)return value(p.x,p.y)>.5;
            if (mode == GraphMode.CARTESIAN||mode==GraphMode.PIECEWISE||mode==GraphMode.DERIVATIVE) {
                if (p.x < domainMin || p.x > domainMax) return false;
                double y=pointAt(p.x).y;return Double.isFinite(y)&&Math.abs(y-p.y)<=tolerance;
            }
            PointF previous = null;
            for (int i = 0; i <= 240; i++) {
                PointF next = pointAt(domainMin + (domainMax - domainMin) * i / 240.0);
                if (previous != null && Float.isFinite(next.x) && Float.isFinite(next.y) && segmentDistance(p, previous, next) <= tolerance) return true;
                previous = next;
            }
            return false;
        }
        @Override void translate(float dx, float dy) { }
        @Override JSONArray encodePoints() { return new JSONArray(); }
        @Override ArrayList<PointF> handles() { return new ArrayList<>(); }
        @Override void rotateScale(float cx, float cy, float degrees, float factor) { }
        @Override JSONObject toJson() throws JSONException {
            JSONObject json = super.toJson(); json.put("mode", mode.name()); json.put("expression", expression);
            if (!expressionY.isEmpty()) json.put("expressionY", expressionY);
            json.put("domainMin", domainMin); json.put("domainMax", domainMax);json.put("parameterA",parameterA);json.put("parameterB",parameterB);json.put("parameterC",parameterC); return json;
        }
    }

    static GeoObject fromJson(JSONObject json) throws JSONException {
        Kind kind;
        try { kind = Kind.valueOf(json.getString("kind")); } catch (IllegalArgumentException error) { throw new JSONException("Unsupported object type"); }
        int color = json.optInt("color", Color.rgb(42, 52, 72)); float width = (float) json.optDouble("width", 4);
        ArrayList<PointF> p = decodePoints(json.optJSONArray("points")); GeoObject object;
        switch (kind) {
            case POINT: require(p, 1); object = new PointObject(p.get(0), color, width, json.optBoolean("coordinates", false)); break;
            case FREEHAND: require(p, 2); object = new FreehandObject(p, color, width); break;
            case SEGMENT: case LINE: case RAY: case RULER: require(p, 2); object = new TwoPointObject(kind, p.get(0), p.get(1), color, width); break;
            case CIRCLE: case CIRCLE_MEASURE: require(p, 2); object = new CircleObject(kind, p.get(0), p.get(1), color, width); break;
            case ELLIPSE: require(p, 2); object = new EllipseObject(p.get(0), p.get(1), color, width); break;
            case ARC: require(p, 3); object = new ArcObject(p.get(0), p.get(1), p.get(2), color, width); break;
            case RECTANGLE: case TRIANGLE: case POLYGON: case REGULAR_POLYGON: case AREA: case ANGLE: case PROTRACTOR:
                require(p, kind == Kind.RECTANGLE ? 4 : 3); object = new PolyObject(kind, p, color, width); break;
            case TEXT: require(p, 1); object = new TextObject(p.get(0), json.optString("text", "Text"), color, width); break;
            case GRAPH:
                GraphMode mode; try { mode = GraphMode.valueOf(json.optString("mode", "CARTESIAN")); } catch (IllegalArgumentException ignored) { mode = GraphMode.CARTESIAN; }
                object = new GraphObject(mode, json.getString("expression"), json.optString("expressionY", ""),
                        json.optDouble("domainMin", mode == GraphMode.CARTESIAN ? -1e9 : 0),
                        json.optDouble("domainMax", mode == GraphMode.CARTESIAN ? 1e9 : Math.PI * 2), color, width).parameters(json.optDouble("parameterA",0),json.optDouble("parameterB",1),json.optDouble("parameterC",0)); break;
            default: throw new JSONException("Unsupported object type");
        }
        object.measured=json.optBoolean("measured",object.measured);object.labelDx=(float)json.optDouble("labelDx",0);object.labelDy=(float)json.optDouble("labelDy",0);
        object.visible = json.optBoolean("visible", true); object.locked = json.optBoolean("locked", false);
        object.dashStyle = Math.max(0, Math.min(2, json.optInt("dash", 0)));
        object.fillOpacity = (float) Math.max(0, Math.min(1, json.optDouble("fill", object.fillOpacity)));
        object.name = json.optString("name", "");object.id=json.optString("id",object.id);object.groupId=json.optString("group",""); return object;
    }

    private static void require(List<PointF> points, int count) throws JSONException { if (points.size() < count) throw new JSONException("Object is missing geometry points"); }
    static ArrayList<PointF> decodePoints(JSONArray json) throws JSONException {
        ArrayList<PointF> points = new ArrayList<>(); if (json == null) return points;
        for (int i = 0; i < json.length(); i++) {
            JSONArray p = json.getJSONArray(i); double x = p.getDouble(0), y = p.getDouble(1);
            if (!Double.isFinite(x) || !Double.isFinite(y) || Math.abs(x) > 1e8 || Math.abs(y) > 1e8) throw new JSONException("Coordinate is outside the supported range");
            points.add(new PointF((float) x, (float) y));
        }
        return points;
    }

    static JSONArray points(PointF... values) { ArrayList<PointF> list = new ArrayList<>(); for (PointF p : values) list.add(p); return points(list); }
    static JSONArray points(List<PointF> values) {
        JSONArray out = new JSONArray();
        for (PointF p : values) { JSONArray pair = new JSONArray(); try { pair.put(p.x); pair.put(p.y); out.put(pair); } catch (JSONException impossible) { throw new IllegalStateException("A coordinate is not finite", impossible); } }
        return out;
    }
    @SafeVarargs static <T> ArrayList<T> list(T... values) { ArrayList<T> result = new ArrayList<>(); for (T value : values) result.add(value); return result; }
    static ArrayList<PointF> copy(List<PointF> source) { ArrayList<PointF> result = new ArrayList<>(); for (PointF p : source) result.add(new PointF(p.x, p.y)); return result; }
    static float distance(PointF a, PointF b) { return (float) Math.hypot(a.x - b.x, a.y - b.y); }
    static float lineDistance(PointF p, PointF a, PointF b) {
        float dx = b.x - a.x, dy = b.y - a.y, length = (float) Math.hypot(dx, dy);
        return length < 1e-6 ? distance(p, a) : Math.abs(dy * p.x - dx * p.y + b.x * a.y - b.y * a.x) / length;
    }
    static float rayDistance(PointF p, PointF a, PointF b) { float dx = b.x - a.x, dy = b.y - a.y; return (p.x - a.x) * dx + (p.y - a.y) * dy < 0 ? distance(p, a) : lineDistance(p, a, b); }
    static float segmentDistance(PointF p, PointF a, PointF b) {
        float dx = b.x - a.x, dy = b.y - a.y, l2 = dx * dx + dy * dy; if (l2 < 1e-12) return distance(p, a);
        float t = Math.max(0, Math.min(1, ((p.x - a.x) * dx + (p.y - a.y) * dy) / l2)); return distance(p, new PointF(a.x + t * dx, a.y + t * dy));
    }
    static double angleDegrees(PointF a, PointF o, PointF b) { if(distance(a,o)<1e-8||distance(b,o)<1e-8)return Double.NaN; double u = Math.atan2(a.y - o.y, a.x - o.x), v = Math.atan2(b.y - o.y, b.x - o.x), d = Math.abs(Math.toDegrees(v - u)) % 360; return d > 180 ? 360 - d : d; }
    static float screenAngle(PointF center, PointF p) { return (float) Math.toDegrees(Math.atan2(-(p.y - center.y), p.x - center.x)); }
    static float normalizeSweep(float angle) { angle %= 360; return angle < 0 ? angle + 360 : angle; }
    static String format(double value) {
        double abs = Math.abs(value); if ((abs > 0 && abs < .001) || abs >= 10000) return String.format(Locale.US, "%.2e", value);
        String s = String.format(Locale.US, "%.3f", value); return s.replaceAll("0+$", "").replaceAll("\\.$", "");
    }
    static Path path(List<PointF> points, Viewport v, boolean close) {
        Path result = new Path(); if (points.isEmpty()) return result; PointF first = v.toScreen(points.get(0)); result.moveTo(first.x, first.y);
        for (int i = 1; i < points.size(); i++) { PointF p = v.toScreen(points.get(i)); result.lineTo(p.x, p.y); } if (close) result.close(); return result;
    }
    static void drawVertex(Canvas c, PointF p, Paint paint) { Paint.Style old = paint.getStyle(); paint.setStyle(Paint.Style.FILL); c.drawCircle(p.x, p.y, 3.5f, paint); paint.setStyle(old); }
    static void drawArrow(Canvas canvas, PointF tip, PointF toward, Paint paint) {
        double angle = Math.atan2(toward.y - tip.y, toward.x - tip.x);
        float size = 9f;
        canvas.drawLine(tip.x, tip.y, tip.x + (float) Math.cos(angle + .55) * size, tip.y + (float) Math.sin(angle + .55) * size, paint);
        canvas.drawLine(tip.x, tip.y, tip.x + (float) Math.cos(angle - .55) * size, tip.y + (float) Math.sin(angle - .55) * size, paint);
    }

    static String measured(double value, Viewport view) {
        double scaled = value * view.measurementScale;
        return measurementNumber(scaled, view.measurementPrecision) + " " + view.measurementUnit;
    }

    static String lengthText(double worldValue, Viewport view) { return measured(worldValue, view); }
    static String areaText(double worldValue, Viewport view) {
        double scaled = worldValue * view.measurementScale * view.measurementScale;
        return measurementNumber(scaled, view.measurementPrecision) + " " + view.measurementUnit + "²";
    }
    static String angleText(double degrees, Viewport view) {
        return String.format(Locale.US, "%." + Math.min(2, view.measurementPrecision) + "f°", degrees);
    }
    static String coordinateText(double worldValue, Viewport view) {
        return measurementNumber(worldValue * view.measurementScale, view.measurementPrecision) + " " + view.measurementUnit;
    }
    private static String measurementNumber(double value, int precision) {
        if (!Double.isFinite(value)) return "not available";
        double absolute = Math.abs(value);
        if ((absolute > 0 && absolute < Math.pow(10, -precision)) || absolute >= 1e7) return String.format(Locale.US, "%.2e", value);
        return String.format(Locale.US, "%." + precision + "f", value);
    }

    static void measurementCallout(Canvas canvas, Viewport view, float centerX, float centerY, String title, int accent, String... values) {
        if (values == null || values.length == 0) return;
        float density = Math.max(1f, canvas.getDensity() / 160f);
        Paint titlePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        titlePaint.setTypeface(android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL));
        titlePaint.setTextSize(10.5f * density);
        titlePaint.setColor(view.darkCanvas ? 0xFFB8C1D5 : 0xFF667085);
        Paint valuePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        valuePaint.setTypeface(android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL));
        valuePaint.setTextSize(13.5f * density);
        valuePaint.setColor(view.darkCanvas ? 0xFFF5F7FC : 0xFF172033);
        float width = titlePaint.measureText(title.toUpperCase(Locale.US));
        for (String value : values) width = Math.max(width, valuePaint.measureText(value));
        width = Math.min(Math.max(120f * density, width + 30f * density), Math.max(120f * density, view.width - 16f * density));
        float lineHeight = 19f * density;
        float height = 23f * density + values.length * lineHeight;
        float x = Math.max(8f * density + width * .5f, Math.min(view.width - 8f * density - width * .5f, centerX));
        float y = Math.max(8f * density + height * .5f, Math.min(view.height - 8f * density - height * .5f, centerY));
        RectF panelBounds = new RectF(x - width * .5f, y - height * .5f, x + width * .5f, y + height * .5f);
        Paint panel = new Paint(Paint.ANTI_ALIAS_FLAG);
        panel.setColor(view.darkCanvas ? 0xF2232935 : 0xF9FFFFFF);
        panel.setShadowLayer(9f * density, 0, 3f * density, 0x26000000);
        canvas.drawRoundRect(panelBounds, 12f * density, 12f * density, panel);
        panel.clearShadowLayer();
        panel.setColor(accent);
        canvas.drawRoundRect(new RectF(panelBounds.left, panelBounds.top, panelBounds.left + 4f * density, panelBounds.bottom), 3f * density, 3f * density, panel);
        float textX = panelBounds.left + 15f * density;
        float baseline = panelBounds.top + 15f * density;
        canvas.drawText(title.toUpperCase(Locale.US), textX, baseline, titlePaint);
        baseline += 20f * density;
        for (String value : values) {
            canvas.drawText(value, textX, baseline, valuePaint);
            baseline += lineHeight;
        }
    }
    static void label(Canvas c, float x, float y, String value, Paint text) {
        text.setTextAlign(Paint.Align.CENTER); text.setColor(0xFF252A36);
        Paint.FontMetrics fm = text.getFontMetrics(); float width = text.measureText(value) + 18;
        RectF bg = new RectF(x - width / 2, y + fm.top - 7, x + width / 2, y + fm.bottom + 7);
        Paint panel = new Paint(Paint.ANTI_ALIAS_FLAG); panel.setColor(0xEFFFFFFF); c.drawRoundRect(bg, 9, 9, panel); c.drawText(value, x, y, text);
    }
    static double polygonArea(List<PointF> points) { double area = 0; for (int i = 0; i < points.size(); i++) { PointF a = points.get(i), b = points.get((i + 1) % points.size()); area += a.x * b.y - b.x * a.y; } return Math.abs(area) * .5; }
    static double polygonPerimeter(List<PointF> points) { double result = 0; for (int i = 0; i < points.size(); i++) result += distance(points.get(i), points.get((i + 1) % points.size())); return result; }
    static PointF polygonCentroid(List<PointF> points) { float x = 0, y = 0; for (PointF point : points) { x += point.x; y += point.y; } return new PointF(x / points.size(), y / points.size()); }
    static String friendlyKind(Kind kind) { String name = kind.name().toLowerCase(Locale.US).replace('_', ' '); return Character.toUpperCase(name.charAt(0)) + name.substring(1); }
}
