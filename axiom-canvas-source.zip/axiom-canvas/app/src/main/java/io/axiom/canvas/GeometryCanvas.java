package io.axiom.canvas;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PointF;
import android.graphics.RectF;
import android.graphics.pdf.PdfDocument;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

import static io.axiom.canvas.GeometryModel.*;

/** The offline construction surface, input engine, project store, and export renderer. */
public final class GeometryCanvas extends View {
    public enum Tool {
        SELECT("Select", "Drag objects • pinch or drag empty space to navigate", 0),
        PEN("Pencil", "Draw naturally with a finger or pressure-sensitive stylus", 0),
        ERASER("Eraser", "Tap or scrub over an object to remove it", 0),
        TEXT("Text", "Choose text, then tap where it belongs", 1),
        POINT("Point", "Tap to place a precise point", 1),
        SEGMENT("Segment", "Choose two endpoints", 2),
        LINE("Line", "Choose two points on an infinite line", 2),
        RAY("Ray", "Choose the origin, then its direction", 2),
        CIRCLE("Compass", "Choose a centre, then a radius", 2),
        ARC("Arc", "Choose centre, start, then end", 3),
        ELLIPSE("Ellipse", "Choose centre, then horizontal and vertical radii", 2),
        RECTANGLE("Rectangle", "Choose opposite corners", 2),
        TRIANGLE("Triangle", "Choose three vertices", 3),
        POLYGON("Polygon", "Tap vertices • tap the first point to close", -1),
        REGULAR_POLYGON("Regular", "Choose centre, then a vertex", 2),
        ANGLE("Angle", "Choose arm, vertex, then second arm", 3),
        MIDPOINT("Midpoint", "Choose two points", 2),
        PARALLEL("Parallel", "Choose two base points, then a through-point", 3),
        PERPENDICULAR("Perpendicular", "Choose two base points, then a through-point", 3),
        PERP_BISECTOR("Perp. bisector", "Choose the endpoints of a segment", 2),
        ANGLE_BISECTOR("Angle bisector", "Choose arm, vertex, then second arm", 3),
        RULER("Distance", "Choose two points for a persistent distance", 2),
        PROTRACTOR("Angle °", "Choose arm, vertex, then second arm", 3),
        AREA("Area", "Tap polygon vertices • Done closes and measures", -1),
        COORDINATE("Coordinates", "Tap to place a labelled coordinate", 1),
        CIRCLE_MEASURE("Circle data", "Choose centre and edge for radius, circumference and area", 2);

        public final String label;
        public final String hint;
        final int pointCount;
        Tool(String label, String hint, int pointCount) { this.label = label; this.hint = hint; this.pointCount = pointCount; }
    }

    public enum BackgroundStyle { CARTESIAN, DOTS, ISOMETRIC, PLAIN }
    public enum Instrument{NONE,RULER,COMPASS,PROTRACTOR,SET_SQUARE,DIVIDER}

    public interface Listener {
        void onToolStatus(String title, String hint, boolean canFinish);
        void onHistoryChanged(boolean canUndo, boolean canRedo);
        void onSelectionChanged(boolean selected);
    }

    public static final class EditSpec {
        public final String title;
        public final String[] labels;
        public final double[] values;
        EditSpec(String title, String[] labels, double[] values) { this.title = title; this.labels = labels; this.values = values; }
    }

    public static final class BoardInfo {
        public final String id;
        public final String title;
        BoardInfo(String id, String title) { this.id = id; this.title = title; }
    }

    private static final class SnapCandidate {
        final PointF point; final String label;
        SnapCandidate(PointF point, String label) { this.point = point; this.label = label; }
    }
    private static final class ConstraintLink{final String type,first,second;final double value;ConstraintLink(String t,String a,String b,double v){type=t;first=a;second=b;value=v;}JSONObject json()throws JSONException{JSONObject j=new JSONObject();j.put("type",type);j.put("first",first);j.put("second",second);j.put("value",value);return j;}static ConstraintLink from(JSONObject j){return new ConstraintLink(j.optString("type"),j.optString("first"),j.optString("second"),j.optDouble("value"));}}

    private static final int MAX_HISTORY = 100;
    private static final String PREFS = "axiom_canvas_project";
    private static final String LEGACY_PROJECT = "project_json_v1";
    private static final String BOARD_INDEX = "board_index_v2";
    private static final String ACTIVE_BOARD = "active_board_v2";
    private static final String BOARD_PREFIX = "board_v2_";
    private static final String RECOVERY_PREFIX="recovery_v3_";

    private final ArrayList<GeoObject> objects = new ArrayList<>();
    private final ArrayList<PointF> pending = new ArrayList<>();
    private final ArrayList<PointF> activeStroke = new ArrayList<>();
    private final ArrayDeque<String> undo = new ArrayDeque<>();
    private final ArrayDeque<String> redo = new ArrayDeque<>();
    private final ArrayList<GeoObject> multiSelection=new ArrayList<>();private final ArrayList<ConstraintLink>constraints=new ArrayList<>();
    private DataTableModel dataTable = new DataTableModel();
    private final Viewport view = new Viewport();
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint gridPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint preview = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint snapPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    private Tool tool = Tool.SELECT;
    private int drawColor = Color.rgb(40, 54, 78);
    private float drawWidth = 4f;
    private boolean snapEnabled = true;
    private boolean angleSnap = true;
    private boolean darkCanvas;
    private boolean movingObject, navigating, multiTouch, dragChanged,lassoMode;
    private boolean traceEnabled;
    private int regularSides = 6;
    private BackgroundStyle backgroundStyle = BackgroundStyle.CARTESIAN;
    private Instrument instrument=Instrument.NONE;private int presentationStep=Integer.MAX_VALUE;
    private GeoObject selected;
    private PointF lastWorld, hoverWorld, cursorWorld;
    private PointF lassoStart,lassoEnd;
    private String hoverSnapLabel, previousSnapLabel, beforeDrag, pendingText = "Label";
    private float lastFocusX, lastFocusY, lastTouchX, lastTouchY, traceX = Float.NaN;
    private float pressureTotal;
    private int pressureSamples;
    private long lastTapTime;
    private PointF lastTapWorld;
    private Listener listener;
    private String activeBoardId = "main";
    private String activeBoardTitle = "My Canvas";
    private final ScaleGestureDetector scaleDetector;

    public GeometryCanvas(Context context) { this(context, null); }
    public GeometryCanvas(Context context, AttributeSet attrs) {
        super(context, attrs);
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        setFocusable(true);
        text.setColor(0xFF252A36); text.setTextSize(dp(13));
        text.setTypeface(android.graphics.Typeface.create("sans", android.graphics.Typeface.BOLD));
        preview.setColor(0xAA6C8CFF); preview.setStyle(Paint.Style.STROKE); preview.setStrokeWidth(dp(2));
        preview.setStrokeCap(Paint.Cap.ROUND); preview.setStrokeJoin(Paint.Join.ROUND);
        preview.setPathEffect(new DashPathEffect(new float[]{dp(7), dp(6)}, 0));
        snapPaint.setColor(0xFFF0A52B); snapPaint.setStyle(Paint.Style.STROKE); snapPaint.setStrokeWidth(dp(2));
        scaleDetector = new ScaleGestureDetector(context, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override public boolean onScaleBegin(ScaleGestureDetector detector) { multiTouch = true; return true; }
            @Override public boolean onScale(ScaleGestureDetector detector) {
                float oldScale = view.scale, newScale = clamp(oldScale * detector.getScaleFactor(), 12f, 480f);
                PointF focusWorld = view.toWorld(detector.getFocusX(), detector.getFocusY()); view.scale = newScale;
                PointF moved = view.toScreen(focusWorld); view.panX += detector.getFocusX() - moved.x; view.panY += detector.getFocusY() - moved.y;
                invalidate(); return true;
            }
        });
        loadWorkspace();
    }

    public void setListener(Listener listener) { this.listener = listener; dispatchStatus(); }
    public Tool getTool() { return tool; }
    public boolean isGridVisible() { return backgroundStyle != BackgroundStyle.PLAIN; }
    public boolean isSnapEnabled() { return snapEnabled; }
    public boolean isAngleSnapEnabled() { return angleSnap; }
    public boolean isDarkCanvas() { return darkCanvas; }
    public boolean isTraceEnabled() { return traceEnabled; }
    public int getDrawColor() { return drawColor; }
    public float getDrawWidth() { return drawWidth; }
    public int getRegularSides() { return regularSides; }
    public int objectCount() { return objects.size(); }
    public BackgroundStyle getBackgroundStyle() { return backgroundStyle; }
    public String getActiveBoardTitle() { return activeBoardTitle; }
    public Instrument getInstrument(){return instrument;}public void setInstrument(Instrument value){instrument=value==null?Instrument.NONE:value;invalidate();}
    public String getMeasurementUnit(){return view.measurementUnit;}
    public double getMeasurementScale(){return view.measurementScale;}
    public int getMeasurementPrecision(){return view.measurementPrecision;}
    public void setMeasurementSettings(String unit,double scale,int precision){String cleaned=unit==null?"":unit.trim();if(cleaned.isEmpty())cleaned="units";if(cleaned.length()>12)throw new IllegalArgumentException("Keep the unit label under 13 characters");if(!Double.isFinite(scale)||scale<=0||scale>1e9)throw new IllegalArgumentException("One grid unit must be a positive finite value");checkpoint();view.measurementUnit=cleaned;view.measurementScale=scale;view.measurementPrecision=clampInt(precision,0,4);afterStateChange();}
    public DataTableModel getDataTable(){return dataTable;}public void tableChanged(){saveAutosave();}public void replaceDataTable(DataTableModel table){checkpoint();dataTable=table==null?new DataTableModel():table;afterStateChange();}
    public void plotTablePoints(int xColumn,int yColumn,int color){List<double[]>pairs=dataTable.pairs(xColumn,yColumn);if(pairs.isEmpty())throw new IllegalArgumentException("No numeric x/y pairs");checkpoint();for(double[]pair:pairs)objects.add(new PointObject(p(pair[0],pair[1]),color,Math.max(4f,drawWidth),true));select(objects.get(objects.size()-1));afterStateChange();zoomToFit();}
    public void plotRegression(DataTableModel.Fit fit,int color){addGraph(fit.expression(),color);}
    public void createRecoverySnapshot(){getContext().getSharedPreferences(PREFS,Context.MODE_PRIVATE).edit().putString(RECOVERY_PREFIX+activeBoardId,serialize()).apply();}public boolean restoreRecoverySnapshot(){String s=getContext().getSharedPreferences(PREFS,Context.MODE_PRIVATE).getString(RECOVERY_PREFIX+activeBoardId,null);if(s==null)return false;checkpoint();restore(s);afterStateChange();return true;}public boolean hasRecoverySnapshot(){return getContext().getSharedPreferences(PREFS,Context.MODE_PRIVATE).contains(RECOVERY_PREFIX+activeBoardId);}public String diagnostics(){return"Axiom Canvas 3.1.0\nAndroid "+android.os.Build.VERSION.RELEASE+" / API "+android.os.Build.VERSION.SDK_INT+"\nBoard: "+activeBoardTitle+"\nObjects: "+objects.size()+"\nGraphs: "+graphExpressions().size()+"\nTable: "+dataTable.rowCount()+"×"+dataTable.columnCount()+"\nMeasurements: 1 grid unit = "+view.measurementScale+" "+view.measurementUnit+"\nConstraints: "+constraints.size();}
    public int constructionStepCount(){return objects.size();}public void setPresentationStep(int step){presentationStep=Math.max(0,Math.min(objects.size(),step));invalidate();}public void stopPresentation(){presentationStep=Integer.MAX_VALUE;invalidate();}public String constructionInstructions(){StringBuilder s=new StringBuilder("Construction history — ").append(activeBoardTitle).append('\n');int i=1;for(GeoObject o:objects){s.append(i++).append(". Create ").append(o.displayName());if(o instanceof GraphObject)s.append(": ").append(((GraphObject)o).equation());s.append('\n');}for(ConstraintLink c:constraints)s.append("• Keep ").append(c.type.toLowerCase(Locale.US).replace('_',' ')).append('\n');return s.toString();}
    public void applyTemplate(String name){checkpoint();objects.clear();constraints.clear();dataTable=new DataTableModel();if(name.equals("Coordinate triangle")){objects.add(new PolyObject(Kind.TRIANGLE,list(p(-3,-2),p(3,-2),p(0,3)),drawColor,drawWidth));objects.add(new PointObject(p(-3,-2),drawColor,drawWidth,true));objects.add(new PointObject(p(3,-2),drawColor,drawWidth,true));objects.add(new PointObject(p(0,3),drawColor,drawWidth,true));}else if(name.equals("Circle theorem")){objects.add(new CircleObject(p(0,0),p(3,0),drawColor,drawWidth));objects.add(new PolyObject(Kind.TRIANGLE,list(p(-3,0),p(3,0),p(0,3)),drawColor,drawWidth));objects.add(new PolyObject(Kind.PROTRACTOR,list(p(-3,0),p(0,3),p(3,0)),0xFFE54B4B,drawWidth));}else if(name.equals("Function study")){objects.add(new GraphObject(GraphMode.CARTESIAN,"x^2-4","",-10,10,0xFF526DFF,drawWidth));dataTable.fill(0,-5,1);dataTable.setFormula(1,"x^2-4");}else if(name.equals("Isometric design"))backgroundStyle=BackgroundStyle.ISOMETRIC;else backgroundStyle=BackgroundStyle.PLAIN;select(null);afterStateChange();zoomToFit();}

    public void setTool(Tool tool) {
        if (this.tool == tool) return;
        cancelPending(); this.tool = tool; traceEnabled = false;
        if (tool != Tool.SELECT) select(null); dispatchStatus(); invalidate();
    }
    public void setPendingText(String value) { pendingText = value == null || value.trim().isEmpty() ? "Label" : value.trim(); }
    public void setRegularSides(int sides) { regularSides = Math.max(3, Math.min(24, sides)); saveAutosave(); dispatchStatus(); }
    public void setBackgroundStyle(BackgroundStyle style) { backgroundStyle = style; saveAutosave(); invalidate(); }
    public void setGridVisible(boolean visible) { setBackgroundStyle(visible ? BackgroundStyle.CARTESIAN : BackgroundStyle.PLAIN); }
    public void setSnapEnabled(boolean enabled) { snapEnabled = enabled; dispatchStatus(); invalidate(); }
    public void setAngleSnapEnabled(boolean enabled) { angleSnap = enabled; dispatchStatus(); invalidate(); }
    public void setDarkCanvas(boolean dark) { darkCanvas = dark; saveAutosave(); invalidate(); }
    public void setTraceEnabled(boolean enabled) {
        traceEnabled = enabled && firstCartesianGraph() != null; traceX = Float.NaN;
        if (traceEnabled) { tool = Tool.SELECT; dispatchStatus(); } invalidate();
    }

    public void setDrawColor(int color) {
        drawColor = color;
        if (selected != null && selected.color != color) { checkpoint(); selected.color = color; afterStateChange(); }
        else invalidate();
    }
    public void setDrawWidth(float width) {
        drawWidth = clamp(width, 2f, 14f);
        if (selected != null && Math.abs(selected.strokeWidth - drawWidth) > .01f) { checkpoint(); selected.strokeWidth = drawWidth; afterStateChange(); }
        else invalidate();
    }
    public void setSelectedStyle(int dash, float fillValue) {
        if (selected == null) return; checkpoint(); selected.dashStyle = clampInt(dash, 0, 2); selected.fillOpacity = clamp(fillValue, 0, .45f); afterStateChange();
    }
    public int getSelectedDash() { return selected == null ? 0 : selected.dashStyle; }
    public float getSelectedFill() { return selected == null ? 0 : selected.fillOpacity; }
    public String getSelectedName() { return selected == null ? "" : selected.displayName(); }
    public boolean isSelectedLocked() { return selected != null && selected.locked; }
    public int selectionCount(){return multiSelection.isEmpty()?(selected==null?0:1):multiSelection.size();}public void startLassoSelection(){setTool(Tool.SELECT);select(null);lassoMode=true;dispatchStatus();}public void selectAllVisible(){clearSelection();for(GeoObject o:objects)if(o.visible){o.selected=true;multiSelection.add(o);}selected=multiSelection.isEmpty()?null:multiSelection.get(multiSelection.size()-1);if(listener!=null)listener.onSelectionChanged(selected!=null);invalidate();}
    public void groupSelection(){List<GeoObject>t=targets();if(t.size()<2)return;checkpoint();String id=UUID.randomUUID().toString();for(GeoObject o:t)o.groupId=id;afterStateChange();}public void ungroupSelection(){List<GeoObject>t=targets();if(t.isEmpty())return;checkpoint();for(GeoObject o:t)o.groupId="";afterStateChange();}
    public void alignSelection(int mode){List<GeoObject>t=targets();if(t.size()<2)return;checkpoint();float ref=(mode==0||mode==2)?Float.MAX_VALUE:-Float.MAX_VALUE;for(GeoObject o:t){PointF c=o.center();if(mode==0)ref=Math.min(ref,c.x);else if(mode==1)ref=Math.max(ref,c.x);else if(mode==2)ref=Math.min(ref,c.y);else if(mode==3)ref=Math.max(ref,c.y);}if(mode>=4){ref=0;for(GeoObject o:t)ref+=mode==4?o.center().x:o.center().y;ref/=t.size();}for(GeoObject o:t){PointF c=o.center();o.translate(mode==0||mode==1||mode==4?ref-c.x:0,mode==2||mode==3||mode==5?ref-c.y:0);}afterStateChange();}
    public void distributeSelection(boolean horizontal){List<GeoObject>t=new ArrayList<>(targets());if(t.size()<3)return;t.sort((a,b)->Float.compare(horizontal?a.center().x:a.center().y,horizontal?b.center().x:b.center().y));checkpoint();float first=horizontal?t.get(0).center().x:t.get(0).center().y,last=horizontal?t.get(t.size()-1).center().x:t.get(t.size()-1).center().y;for(int i=1;i<t.size()-1;i++){GeoObject o=t.get(i);float desired=first+(last-first)*i/(t.size()-1f),current=horizontal?o.center().x:o.center().y;o.translate(horizontal?desired-current:0,horizontal?0:desired-current);}afterStateChange();}
    public void duplicatePattern(int copies,double dx,double dy,double degrees){List<GeoObject>t=new ArrayList<>(targets());if(t.isEmpty())return;checkpoint();try{for(int k=1;k<=clampInt(copies,1,50);k++)for(GeoObject original:t){GeoObject copy=GeometryModel.fromJson(original.toJson());copy.id=UUID.randomUUID().toString();copy.groupId="";PointF c=copy.center();copy.rotateScale(c.x,c.y,(float)(degrees*k),1);copy.translate((float)(dx*k),(float)(dy*k));objects.add(copy);}}catch(JSONException ignored){}select(objects.get(objects.size()-1));afterStateChange();}
    public String addConstraint(String type){List<GeoObject>t=targets();String n=type.toUpperCase(Locale.US);if(n.equals("FIXED_LENGTH")){GeoObject o=firstOf(t,TwoPointObject.class);if(!(o instanceof TwoPointObject))return"Select a line-like object.";TwoPointObject line=(TwoPointObject)o;checkpoint();constraints.add(new ConstraintLink(n,o.id,"",distance(line.a,line.b)));afterStateChange();return"Fixed length added.";}if(n.equals("FIXED_ANGLE")){GeoObject o=firstAngle(t);if(!(o instanceof PolyObject))return"Select a three-point angle.";PolyObject angle=(PolyObject)o;checkpoint();constraints.add(new ConstraintLink(n,o.id,"",angleDegrees(angle.vertices.get(0),angle.vertices.get(1),angle.vertices.get(2))));afterStateChange();return"Fixed angle added.";}GeoObject a=t.size()>0?t.get(0):null,b=t.size()>1?t.get(1):null;if(n.equals("MIDPOINT")||n.equals("POINT_ON_OBJECT")){PointObject point=a instanceof PointObject?(PointObject)a:b instanceof PointObject?(PointObject)b:null;GeoObject support=point==a?b:a;if(point==null||support==null)return"Select a point and supporting object.";checkpoint();constraints.add(new ConstraintLink(n,point.id,support.id,0));enforceConstraints();afterStateChange();return"Constraint added.";}if(!(a instanceof TwoPointObject)||!(b instanceof TwoPointObject))return"Lasso-select two line-like objects.";checkpoint();constraints.add(new ConstraintLink(n,a.id,b.id,0));enforceConstraints();afterStateChange();return n.toLowerCase(Locale.US).replace('_',' ')+" constraint added.";}
    public String solveSelection(){List<GeoObject>t=targets();if(t.isEmpty())t=new ArrayList<>(objects);StringBuilder s=new StringBuilder("Geometry solver\n");for(GeoObject o:t)if(o instanceof TwoPointObject){TwoPointObject l=(TwoPointObject)o;double dx=l.b.x-l.a.x;s.append('\n').append(o.displayName()).append(": length ").append(lengthText(distance(l.a,l.b),view)).append(", slope ").append(Math.abs(dx)<1e-9?"vertical":format((l.b.y-l.a.y)/dx));}else if(o instanceof CircleObject){CircleObject c=(CircleObject)o;s.append('\n').append(o.displayName()).append(": radius ").append(lengthText(c.radius(),view)).append(", circumference ").append(lengthText(2*Math.PI*c.radius(),view)).append(", area ").append(areaText(Math.PI*c.radius()*c.radius(),view));}else if(o instanceof PolyObject&&((PolyObject)o).vertices.size()>=3){PolyObject p=(PolyObject)o;s.append('\n').append(o.displayName()).append(": area ").append(areaText(polygonArea(p.vertices),view)).append(", perimeter ").append(lengthText(polygonPerimeter(p.vertices),view));}s.append("\n\nInspected ").append(t.size()).append(" objects. Values use exact coordinates and the active measurement calibration.");return s.toString();}

    public void undo() { if (undo.isEmpty()) return; redo.addLast(serialize()); restore(undo.removeLast()); afterStateChange(); }
    public void redo() { if (redo.isEmpty()) return; undo.addLast(serialize()); restore(redo.removeLast()); afterStateChange(); }
    public void clearAll() { if (objects.isEmpty()) return; checkpoint(); objects.clear(); select(null); afterStateChange(); }
    public void deleteSelected(){List<GeoObject>t=targets();if(t.isEmpty())return;checkpoint();objects.removeAll(t);constraints.removeIf(c->contains(t,c.first)||contains(t,c.second));select(null);afterStateChange();}private static boolean contains(List<GeoObject>t,String id){for(GeoObject o:t)if(o.id.equals(id))return true;return false;}
    public void duplicateSelected() {
        if (selected == null) return;if(!multiSelection.isEmpty()){duplicatePattern(1,.3,-.3,0);return;}
        try { checkpoint(); GeoObject copy = GeometryModel.fromJson(selected.toJson());copy.id=UUID.randomUUID().toString();copy.groupId=""; copy.locked = false; copy.translate(.3f, -.3f); objects.add(copy); select(copy); afterStateChange(); }
        catch (JSONException ignored) { }
    }
    public void renameSelected(String name) { if (selected == null) return; checkpoint(); selected.name = name == null ? "" : name.trim(); afterStateChange(); }
    public void transformSelected(double dx, double dy, double degrees, double factor) {
        if (selected == null || selected.locked || !finite(dx, dy, degrees, factor) || factor <= .01 || factor > 100) return;
        checkpoint(); PointF center = selected.center(); selected.rotateScale(center.x, center.y, (float) degrees, (float) factor); selected.translate((float) dx, (float) dy); afterStateChange();
    }
    public void reflectSelected(boolean acrossXAxis) {
        if (selected == null || selected.locked) return; checkpoint();
        for (PointF p : selected.handles()) { if (acrossXAxis) p.y = -p.y; else p.x = -p.x; } afterStateChange();
    }
    public void toggleSelectedLocked() { if (selected == null) return; checkpoint(); selected.locked = !selected.locked; afterStateChange(); }
    public void toggleSelectedVisible() { if (selected == null) return; checkpoint(); selected.visible = !selected.visible; if (!selected.visible) select(null); afterStateChange(); }
    public void bringSelectedToFront() { moveSelectedTo(objects.size() - 1); }
    public void sendSelectedToBack() { moveSelectedTo(0); }
    public void moveSelectedForward() { if (selected != null) moveSelectedTo(Math.min(objects.size() - 1, objects.indexOf(selected) + 1)); }
    public void moveSelectedBackward() { if (selected != null) moveSelectedTo(Math.max(0, objects.indexOf(selected) - 1)); }
    private void moveSelectedTo(int target) {
        if (selected == null) return; int current = objects.indexOf(selected); if (current == target || current < 0) return;
        checkpoint(); objects.remove(current); objects.add(target, selected); afterStateChange();
    }

    public List<String> objectSummaries() {
        ArrayList<String> result = new ArrayList<>();
        for (int i = objects.size() - 1; i >= 0; i--) {
            GeoObject o = objects.get(i); result.add((o.visible ? "◉ " : "○ ") + (o.locked ? "🔒 " : "") + o.displayName());
        }
        return result;
    }
    public void selectDisplayObject(int displayIndex) {
        int index = objects.size() - 1 - displayIndex; if (index < 0 || index >= objects.size()) return; select(objects.get(index));
    }

    public EditSpec selectedEditSpec() {
        if (selected instanceof PointObject) { PointF p = ((PointObject) selected).point; return spec("Point coordinates", new String[]{"x", "y"}, p.x, p.y); }
        if (selected instanceof TwoPointObject) { TwoPointObject o = (TwoPointObject) selected; return spec("Endpoint coordinates", new String[]{"x₁", "y₁", "x₂", "y₂"}, o.a.x, o.a.y, o.b.x, o.b.y); }
        if (selected instanceof CircleObject) { CircleObject o = (CircleObject) selected; return spec("Circle geometry", new String[]{"centre x", "centre y", "radius"}, o.center.x, o.center.y, o.radius()); }
        if (selected instanceof EllipseObject) { EllipseObject o = (EllipseObject) selected; return spec("Ellipse geometry", new String[]{"centre x", "centre y", "radius x", "radius y"}, o.center.x, o.center.y, o.radiusX(), o.radiusY()); }
        if (selected instanceof TextObject) { TextObject o = (TextObject) selected; return spec("Text position", new String[]{"x", "y"}, o.position.x, o.position.y); }
        return null;
    }
    private EditSpec spec(String title, String[] labels, double... values) { return new EditSpec(title, labels, values); }
    public void applySelectedExact(double[] values) {
        if (selected == null || selected.locked || values == null) return; for (double value : values) if (!Double.isFinite(value) || Math.abs(value) > 1e7) return;
        checkpoint();
        if (selected instanceof PointObject && values.length >= 2) { PointF p = ((PointObject) selected).point; p.set((float) values[0], (float) values[1]); }
        else if (selected instanceof TwoPointObject && values.length >= 4) { TwoPointObject o = (TwoPointObject) selected; o.a.set((float) values[0], (float) values[1]); o.b.set((float) values[2], (float) values[3]); }
        else if (selected instanceof CircleObject && values.length >= 3 && values[2] > 0) { CircleObject o = (CircleObject) selected; o.center.set((float) values[0], (float) values[1]); o.edge.set((float) (values[0] + values[2]), (float) values[1]); }
        else if (selected instanceof EllipseObject && values.length >= 4 && values[2] > 0 && values[3] > 0) { EllipseObject o = (EllipseObject) selected; o.center.set((float) values[0], (float) values[1]); o.edge.set((float) (values[0] + values[2]), (float) (values[1] + values[3])); }
        else if (selected instanceof TextObject && values.length >= 2) { ((TextObject) selected).position.set((float) values[0], (float) values[1]); }
        else { undo.removeLast(); return; }
        afterStateChange();
    }

    public void createExact(Tool type, double[] values) {
        for (double value : values) if (!Double.isFinite(value) || Math.abs(value) > 1e7) throw new IllegalArgumentException("Use finite values smaller than 10,000,000");
        GeoObject object;
        switch (type) {
            case POINT: case COORDINATE:
                requireValues(values, 2); object = new PointObject(p(values[0], values[1]), drawColor, drawWidth, type == Tool.COORDINATE); break;
            case SEGMENT: case LINE: case RAY: case RULER:
                requireValues(values, 4); object = new TwoPointObject(kindFor(type), p(values[0], values[1]), p(values[2], values[3]), drawColor, drawWidth); break;
            case CIRCLE: case CIRCLE_MEASURE:
                requireValues(values, 3); if (values[2] <= 0) throw new IllegalArgumentException("Radius must be positive");
                object = new CircleObject(type == Tool.CIRCLE ? Kind.CIRCLE : Kind.CIRCLE_MEASURE, p(values[0], values[1]), p(values[0] + values[2], values[1]), drawColor, drawWidth); break;
            case ELLIPSE:
                requireValues(values, 4); if (values[2] <= 0 || values[3] <= 0) throw new IllegalArgumentException("Both radii must be positive");
                object = new EllipseObject(p(values[0], values[1]), p(values[0] + values[2], values[1] + values[3]), drawColor, drawWidth); break;
            case RECTANGLE:
                requireValues(values, 4); object = new PolyObject(Kind.RECTANGLE, rectanglePoints(p(values[0], values[1]), p(values[2], values[3])), drawColor, drawWidth); break;
            case REGULAR_POLYGON:
                requireValues(values, 4); if (values[2] <= 0) throw new IllegalArgumentException("Radius must be positive");
                object = new PolyObject(Kind.REGULAR_POLYGON, regularPolygon(p(values[0], values[1]), (float) values[2], (float) values[3], regularSides), drawColor, drawWidth); break;
            default: throw new IllegalArgumentException("Exact creation is not available for this tool");
        }
        checkpoint(); objects.add(object); select(object); afterStateChange();
    }
    private static void requireValues(double[] values, int count) { if (values == null || values.length < count) throw new IllegalArgumentException("Complete every field"); }
    private static PointF p(double x, double y) { return new PointF((float) x, (float) y); }

    public void finishCurrentConstruction() {
        if ((tool == Tool.POLYGON || tool == Tool.AREA) && pending.size() >= 3) {
            checkpoint(); objects.add(new PolyObject(tool == Tool.AREA ? Kind.AREA : Kind.POLYGON, pending, drawColor, drawWidth)); pending.clear(); afterStateChange();
        }
    }
    public void cancelPending() { pending.clear(); activeStroke.clear(); hoverWorld = cursorWorld = null; hoverSnapLabel = null; dispatchStatus(); invalidate(); }

    public void addGraph(String expression, int color) { addGraph(GraphMode.CARTESIAN, expression, "", -1e9, 1e9, color); }
    public void addGraph(GraphMode mode, String expressionA, String expressionB, double domainMin, double domainMax, int color) {
        ExpressionParser.compile(expressionA);
        if (mode == GraphMode.PARAMETRIC) ExpressionParser.compile(expressionB);
        if (!Double.isFinite(domainMin) || !Double.isFinite(domainMax) || domainMax <= domainMin) throw new IllegalArgumentException("Domain end must be greater than its start");
        checkpoint(); GraphObject graph = new GraphObject(mode, expressionA, expressionB, domainMin, domainMax, color, Math.max(3f, drawWidth)); objects.add(graph); select(graph); afterStateChange();
    }
    public void addGraph(GraphMode mode,String expressionA,String expressionB,double domainMin,double domainMax,int color,double a,double b,double c){ExpressionParser.compileVariables(expressionA);if(mode==GraphMode.PARAMETRIC)ExpressionParser.compileVariables(expressionB);if(!Double.isFinite(domainMin)||!Double.isFinite(domainMax)||domainMax<=domainMin)throw new IllegalArgumentException("Domain end must exceed start");checkpoint();GraphObject graph=new GraphObject(mode,expressionA,expressionB,domainMin,domainMax,color,Math.max(3f,drawWidth)).parameters(a,b,c);objects.add(graph);select(graph);afterStateChange();}
    public List<String> graphExpressions() { ArrayList<String> result = new ArrayList<>(); for (GeoObject o : objects) if (o instanceof GraphObject) result.add(((GraphObject) o).equation()); return result; }
    public void clearGraphs() {
        boolean found = false; for (GeoObject o : objects) if (o instanceof GraphObject) { found = true; break; } if (!found) return;
        checkpoint(); objects.removeIf(o -> o instanceof GraphObject); if (selected instanceof GraphObject) select(null); traceEnabled = false; afterStateChange();
    }
    public String analyzeVisibleGraph() {
        GraphObject graph = selected instanceof GraphObject && isFunction((GraphObject)selected) ? (GraphObject) selected : firstCartesianGraph();
        if (graph == null) return "Add or select a Cartesian graph first.";
        double from = Math.max(view.left(), graph.domainMin), to = Math.min(view.right(), graph.domainMax);
        if (to <= from) return "The selected graph is outside the visible x-range.";
        ArrayList<Double> roots = new ArrayList<>(); double minY = Double.POSITIVE_INFINITY, maxY = Double.NEGATIVE_INFINITY, minX = 0, maxX = 0;
        PointF previous = graph.pointAt(from);
        for (int i = 1; i <= 1000; i++) {
            double x = from + (to - from) * i / 1000.0; PointF point = graph.pointAt(x);
            if (Float.isFinite(point.y)) {
                if (point.y < minY) { minY = point.y; minX = x; } if (point.y > maxY) { maxY = point.y; maxX = x; }
                if (Float.isFinite(previous.y) && previous.y * point.y <= 0 && Math.abs(previous.y - point.y) < 1e5) {
                    double root = bisect(graph, x - (to - from) / 1000.0, x);
                    if (roots.isEmpty() || Math.abs(root - roots.get(roots.size() - 1)) > (to - from) / 500.0) roots.add(root);
                }
            }
            previous = point;
        }
        StringBuilder result = new StringBuilder(graph.equation()).append("\nVisible x: ").append(format(from)).append(" to ").append(format(to));
        result.append("\nRoots: "); if (roots.isEmpty()) result.append("none detected"); else { for (int i = 0; i < Math.min(12, roots.size()); i++) { if (i > 0) result.append(", "); result.append(format(roots.get(i))); } if (roots.size() > 12) result.append(" …"); }
        if (Double.isFinite(minY)) result.append("\nSampled minimum: (").append(format(minX)).append(", ").append(format(minY)).append(")\nSampled maximum: (").append(format(maxX)).append(", ").append(format(maxY)).append(")");
        if (graph.domainMin <= 0 && graph.domainMax >= 0) result.append("\ny-intercept: ").append(format(graph.pointAt(0).y));
        result.append("\n\nExtrema are numerical samples of the current window."); return result.toString();
    }
    private double bisect(GraphObject graph, double left, double right) {
        double a = graph.pointAt(left).y;
        for (int i = 0; i < 28; i++) { double mid = (left + right) * .5, value = graph.pointAt(mid).y; if (!Double.isFinite(value)) break; if (a * value <= 0) right = mid; else { left = mid; a = value; } }
        return (left + right) * .5;
    }
    private GraphObject firstCartesianGraph() {
        if (selected instanceof GraphObject && selected.visible && isFunction((GraphObject) selected)) return (GraphObject) selected;
        for (int i = objects.size() - 1; i >= 0; i--) if (objects.get(i) instanceof GraphObject && objects.get(i).visible && isFunction((GraphObject) objects.get(i))) return (GraphObject) objects.get(i);
        return null;
    }
    private static boolean isFunction(GraphObject graph){return graph.mode==GraphMode.CARTESIAN||graph.mode==GraphMode.PIECEWISE||graph.mode==GraphMode.DERIVATIVE;}

    public void resetView() { view.scale = 72f; view.panX = view.panY = 0; saveAutosave(); invalidate(); }
    public void zoomBy(float factor) {
        float next = clamp(view.scale * factor, 12f, 480f); PointF centerWorld = view.toWorld(getWidth() * .5f, getHeight() * .5f); view.scale = next;
        PointF moved = view.toScreen(centerWorld); view.panX += getWidth() * .5f - moved.x; view.panY += getHeight() * .5f - moved.y; saveAutosave(); invalidate();
    }
    public void zoomToFit() {
        ArrayList<PointF> anchors = collectObjectPoints(false); if (anchors.isEmpty()) { resetView(); return; }
        float minX = Float.MAX_VALUE, minY = Float.MAX_VALUE, maxX = -Float.MAX_VALUE, maxY = -Float.MAX_VALUE;
        for (PointF p : anchors) { minX = Math.min(minX, p.x); maxX = Math.max(maxX, p.x); minY = Math.min(minY, p.y); maxY = Math.max(maxY, p.y); }
        float spanX = Math.max(1, maxX - minX), spanY = Math.max(1, maxY - minY);
        view.scale = clamp(Math.min(getWidth() * .72f / spanX, getHeight() * .68f / spanY), 12f, 300f);
        view.panX = -(minX + maxX) * .5f * view.scale; view.panY = (minY + maxY) * .5f * view.scale; saveAutosave(); invalidate();
    }

    @Override protected void onSizeChanged(int w, int h, int oldw, int oldh) { view.width = w; view.height = h; }
    @Override protected void onDraw(Canvas canvas) { super.onDraw(canvas); drawScene(canvas, true, true); }
    private void drawScene(Canvas canvas, boolean interactive, boolean includeBackground) {
        view.darkCanvas=darkCanvas;
        if (includeBackground) {
            canvas.drawColor(darkCanvas ? 0xFF151923 : 0xFFF9FAFE);
            if (backgroundStyle != BackgroundStyle.PLAIN) drawBackground(canvas);
        }
        int steps=Math.min(objects.size(),presentationStep);for(int i=0;i<steps;i++){GeoObject object=objects.get(i);if(object.visible)object.draw(canvas,view,stroke,fill,text);}
        if (interactive) {drawInstrument(canvas);drawLasso(canvas);drawPending(canvas);drawSnapIndicator(canvas);drawTrace(canvas);drawSelectionMetrics(canvas);drawCursorHud(canvas);}
    }
    private void drawSelectionMetrics(Canvas canvas){if(selected==null||selected instanceof GraphObject||selected instanceof TextObject||selected.kind==Kind.RULER||selected.kind==Kind.PROTRACTOR||selected.kind==Kind.AREA||selected.kind==Kind.CIRCLE_MEASURE)return;String title=selected.displayName();String[]values=null;if(selected instanceof TwoPointObject){TwoPointObject line=(TwoPointObject)selected;double dx=line.b.x-line.a.x;String spanLabel=line.kind==Kind.SEGMENT?"Length  ":"Anchor span  ";values=new String[]{spanLabel+lengthText(distance(line.a,line.b),view),"Direction  "+angleText(directionDegrees(line.a,line.b),view),"Slope  "+(Math.abs(dx)<1e-9?"vertical":format((line.b.y-line.a.y)/dx))};}else if(selected instanceof CircleObject){CircleObject circle=(CircleObject)selected;values=new String[]{"Radius  "+lengthText(circle.radius(),view),"Diameter  "+lengthText(circle.radius()*2,view),"Circumference  "+lengthText(2*Math.PI*circle.radius(),view),"Area  "+areaText(Math.PI*circle.radius()*circle.radius(),view)};}else if(selected instanceof EllipseObject){EllipseObject ellipse=(EllipseObject)selected;values=new String[]{"Horizontal radius  "+lengthText(ellipse.radiusX(),view),"Vertical radius  "+lengthText(ellipse.radiusY(),view),"Area  "+areaText(Math.PI*ellipse.radiusX()*ellipse.radiusY(),view)};}else if(selected instanceof PolyObject){PolyObject polygon=(PolyObject)selected;if(polygon.kind==Kind.ANGLE&&polygon.vertices.size()==3)values=new String[]{"Angle  "+angleText(angleDegrees(polygon.vertices.get(0),polygon.vertices.get(1),polygon.vertices.get(2)),view)};else if(polygon.vertices.size()>=3)values=new String[]{"Area  "+areaText(polygonArea(polygon.vertices),view),"Perimeter  "+lengthText(polygonPerimeter(polygon.vertices),view)};}else if(selected instanceof PointObject){PointObject point=(PointObject)selected;values=new String[]{"x  "+coordinateText(point.point.x,view),"y  "+coordinateText(point.point.y,view)};}if(values!=null)measurementCallout(canvas,view,getWidth()*.5f,dp(140),title,selected.color,values);}
    private void drawLasso(Canvas c){if(lassoStart==null||lassoEnd==null)return;PointF a=view.toScreen(lassoStart),b=view.toScreen(lassoEnd);preview.setStyle(Paint.Style.FILL);preview.setColor(0x286C8CFF);c.drawRect(Math.min(a.x,b.x),Math.min(a.y,b.y),Math.max(a.x,b.x),Math.max(a.y,b.y),preview);preview.setStyle(Paint.Style.STROKE);preview.setColor(0xAA6C8CFF);}
    private void drawInstrument(Canvas c){if(instrument==Instrument.NONE)return;Paint edge=new Paint(Paint.ANTI_ALIAS_FLAG);edge.setColor(0xCC526D9A);edge.setStrokeWidth(dp(2));edge.setStyle(Paint.Style.STROKE);Paint guide=new Paint(edge);guide.setColor(0x5595A7CE);guide.setStyle(Paint.Style.FILL);float x=getWidth()*.52f,y=getHeight()*.58f;if(instrument==Instrument.RULER){RectF r=new RectF(x-dp(140),y-dp(22),x+dp(140),y+dp(22));c.drawRoundRect(r,dp(5),dp(5),guide);c.drawRoundRect(r,dp(5),dp(5),edge);for(int i=0;i<=20;i++){float px=r.left+r.width()*i/20;c.drawLine(px,r.top,px,r.top+dp(i%5==0?13:7),edge);}}else if(instrument==Instrument.PROTRACTOR){RectF r=new RectF(x-dp(120),y-dp(120),x+dp(120),y+dp(120));c.drawArc(r,180,180,true,guide);c.drawArc(r,180,180,true,edge);}else if(instrument==Instrument.SET_SQUARE){Path p=new Path();p.moveTo(x-dp(110),y+dp(80));p.lineTo(x+dp(110),y+dp(80));p.lineTo(x-dp(110),y-dp(100));p.close();c.drawPath(p,guide);c.drawPath(p,edge);}else{float spread=instrument==Instrument.COMPASS?dp(75):dp(55);c.drawLine(x,y-dp(95),x-spread,y+dp(95),edge);c.drawLine(x,y-dp(95),x+spread,y+dp(95),edge);}}

    private void drawBackground(Canvas canvas) {
        if (backgroundStyle == BackgroundStyle.ISOMETRIC) { drawIsometric(canvas); return; }
        float step = gridStep(), pixels = step * view.scale, left = (float) Math.floor(view.left() / step) * step;
        float right = view.right(), bottom = (float) Math.floor(view.bottom() / step) * step, top = view.top();
        gridPaint.setStrokeWidth(1f); gridPaint.setColor(darkCanvas ? 0x24FFFFFF : 0x180F1930);
        if (backgroundStyle == BackgroundStyle.DOTS) {
            gridPaint.setStyle(Paint.Style.FILL);
            for (float x = left; x <= right; x += step) for (float y = bottom; y <= top; y += step) { PointF p = view.toScreen(new PointF(x, y)); canvas.drawCircle(p.x, p.y, pixels > 45 ? 1.8f : 1.2f, gridPaint); }
        } else {
            gridPaint.setStyle(Paint.Style.STROKE);
            for (float x = left; x <= right; x += step) { PointF a = view.toScreen(new PointF(x, 0)); canvas.drawLine(a.x, 0, a.x, getHeight(), gridPaint); }
            for (float y = bottom; y <= top; y += step) { PointF a = view.toScreen(new PointF(0, y)); canvas.drawLine(0, a.y, getWidth(), a.y, gridPaint); }
        }
        gridPaint.setStrokeWidth(dp(1.5f)); gridPaint.setColor(darkCanvas ? 0x65FFFFFF : 0x552A3345);
        PointF origin = view.toScreen(new PointF(0, 0)); canvas.drawLine(origin.x, 0, origin.x, getHeight(), gridPaint); canvas.drawLine(0, origin.y, getWidth(), origin.y, gridPaint);
        if (pixels >= 46) drawAxisLabels(canvas, step, left, right, bottom, top, origin);
    }
    private void drawIsometric(Canvas canvas) {
        float spacing = gridStep() * view.scale, row = spacing * .8660254f; if (row < 8) return;
        PointF origin = view.toScreen(new PointF()); gridPaint.setColor(darkCanvas ? 0x24FFFFFF : 0x180F1930); gridPaint.setStrokeWidth(1f);
        float firstY = origin.y % row; for (float y = firstY - row; y < getHeight() + row; y += row) canvas.drawLine(0, y, getWidth(), y, gridPaint);
        float run = getHeight() / 1.7320508f;
        float firstX = origin.x % spacing; for (float x = firstX - getHeight(); x < getWidth() + getHeight(); x += spacing) {
            canvas.drawLine(x - run, getHeight(), x + run, 0, gridPaint); canvas.drawLine(x + run, getHeight(), x - run, 0, gridPaint);
        }
    }
    private void drawAxisLabels(Canvas canvas, float step, float left, float right, float bottom, float top, PointF origin) {
        Paint labels = new Paint(Paint.ANTI_ALIAS_FLAG); labels.setTextSize(dp(10)); labels.setColor(darkCanvas ? 0x99FFFFFF : 0x88323A4A);
        for (float x = left; x <= right; x += step) if (Math.abs(x) >= step * .1f) { PointF p = view.toScreen(new PointF(x, 0)); canvas.drawText(format(x), p.x + 3, clamp(origin.y + dp(15), dp(12), getHeight() - dp(4)), labels); }
        for (float y = bottom; y <= top; y += step) if (Math.abs(y) >= step * .1f) { PointF p = view.toScreen(new PointF(0, y)); canvas.drawText(format(y), clamp(origin.x + dp(5), dp(3), getWidth() - dp(40)), p.y - 3, labels); }
    }
    private void drawPending(Canvas canvas) {
        if (!activeStroke.isEmpty()) canvas.drawPath(path(activeStroke, view, false), preview);
        if (pending.isEmpty()) return;
        ArrayList<PointF> line = copy(pending); if (hoverWorld != null) line.add(hoverWorld);
        if (tool == Tool.RECTANGLE && line.size() == 2) line = rectanglePoints(line.get(0), line.get(1));
        if (tool == Tool.REGULAR_POLYGON && line.size() == 2) line = regularPolygon(line.get(0), distance(line.get(0), line.get(1)), (float) Math.toDegrees(Math.atan2(line.get(1).y - line.get(0).y, line.get(1).x - line.get(0).x)), regularSides);
        boolean close = tool == Tool.RECTANGLE || tool == Tool.REGULAR_POLYGON || ((tool == Tool.POLYGON || tool == Tool.AREA) && pending.size() > 2 && hoverWorld != null && distance(hoverWorld, pending.get(0)) < 15f / view.scale);
        canvas.drawPath(path(line, view, close), preview);
        for (PointF point : pending) { PointF s = view.toScreen(point); canvas.drawCircle(s.x, s.y, dp(5), preview); }
        if ((tool == Tool.CIRCLE || tool == Tool.CIRCLE_MEASURE) && pending.size() == 1 && hoverWorld != null) { PointF c = view.toScreen(pending.get(0)); canvas.drawCircle(c.x, c.y, distance(pending.get(0), hoverWorld) * view.scale, preview); }
        if (tool == Tool.ELLIPSE && pending.size() == 1 && hoverWorld != null) { PointF c = view.toScreen(pending.get(0)); canvas.drawOval(new RectF(c.x - Math.abs(hoverWorld.x - pending.get(0).x) * view.scale, c.y - Math.abs(hoverWorld.y - pending.get(0).y) * view.scale, c.x + Math.abs(hoverWorld.x - pending.get(0).x) * view.scale, c.y + Math.abs(hoverWorld.y - pending.get(0).y) * view.scale), preview); }
        if ((tool == Tool.ANGLE || tool == Tool.PROTRACTOR || tool == Tool.ANGLE_BISECTOR) && line.size() >= 3) { PointF o = line.get(1), so = view.toScreen(o); label(canvas, so.x, so.y - dp(38), format(angleDegrees(line.get(0), o, line.get(2))) + "°", text); }
        if(tool==Tool.RULER&&pending.size()==1&&hoverWorld!=null){PointF a=view.toScreen(pending.get(0)),b=view.toScreen(hoverWorld);measurementCallout(canvas,view,(a.x+b.x)*.5f,(a.y+b.y)*.5f-dp(38),"Distance preview",drawColor,lengthText(distance(pending.get(0),hoverWorld),view));}
        if(tool==Tool.CIRCLE_MEASURE&&pending.size()==1&&hoverWorld!=null){PointF c=view.toScreen(pending.get(0));double r=distance(pending.get(0),hoverWorld);measurementCallout(canvas,view,c.x,(float)(c.y-r*view.scale-dp(38)),"Circle preview",drawColor,"Radius  "+lengthText(r,view),"Area  "+areaText(Math.PI*r*r,view));}
        if(tool==Tool.AREA&&line.size()>=3){PointF center=view.toScreen(polygonCentroid(line));measurementCallout(canvas,view,center.x,center.y,"Area preview",drawColor,"Area  "+areaText(polygonArea(line),view),"Perimeter  "+lengthText(polygonPerimeter(line),view));}
    }
    private void drawSnapIndicator(Canvas canvas) {
        if (!snapEnabled || hoverWorld == null || hoverSnapLabel == null) return; PointF screen = view.toScreen(hoverWorld);
        canvas.drawCircle(screen.x, screen.y, dp(7), snapPaint); canvas.drawLine(screen.x - dp(10), screen.y, screen.x + dp(10), screen.y, snapPaint); canvas.drawLine(screen.x, screen.y - dp(10), screen.x, screen.y + dp(10), snapPaint);
        label(canvas, screen.x, screen.y - dp(18), hoverSnapLabel, text);
    }
    private void drawCursorHud(Canvas canvas) {
        if (cursorWorld == null) return; String value = "x " + format(cursorWorld.x) + "   y " + format(cursorWorld.y);
        text.setTextAlign(Paint.Align.LEFT); text.setTextSize(dp(11)); text.setColor(darkCanvas ? Color.WHITE : 0xFF303746);
        float width = text.measureText(value) + dp(18); Paint panel = new Paint(Paint.ANTI_ALIAS_FLAG); panel.setColor(darkCanvas ? 0xD928303D : 0xEFFFFFFF);
        RectF rect = new RectF(dp(10), getHeight() - dp(38), dp(10) + width, getHeight() - dp(10)); canvas.drawRoundRect(rect, dp(10), dp(10), panel); canvas.drawText(value, dp(19), getHeight() - dp(19), text);
    }
    private void drawTrace(Canvas canvas) {
        if (!traceEnabled || !Float.isFinite(traceX)) return; GraphObject graph = firstCartesianGraph(); if (graph == null || traceX < graph.domainMin || traceX > graph.domainMax) return;
        PointF world = graph.pointAt(traceX); if (!Float.isFinite(world.y)) return; PointF screen = view.toScreen(world);
        Paint trace = new Paint(Paint.ANTI_ALIAS_FLAG); trace.setColor(0xFFED9E2F); trace.setStrokeWidth(dp(1.5f)); trace.setPathEffect(new DashPathEffect(new float[]{dp(5), dp(4)}, 0));
        canvas.drawLine(screen.x, 0, screen.x, getHeight(), trace); canvas.drawLine(0, screen.y, getWidth(), screen.y, trace); trace.setPathEffect(null); trace.setStyle(Paint.Style.FILL); canvas.drawCircle(screen.x, screen.y, dp(5), trace);
        label(canvas, clamp(screen.x, dp(70), getWidth() - dp(70)), clamp(screen.y - dp(18), dp(24), getHeight() - dp(24)), "(" + format(world.x) + ", " + format(world.y) + ")", text);
    }

    @Override public boolean onTouchEvent(MotionEvent event) {
        scaleDetector.onTouchEvent(event); int action = event.getActionMasked();
        if (event.getPointerCount() >= 2) {
            float fx = 0, fy = 0; for (int i = 0; i < event.getPointerCount(); i++) { fx += event.getX(i); fy += event.getY(i); } fx /= event.getPointerCount(); fy /= event.getPointerCount();
            if (action == MotionEvent.ACTION_POINTER_DOWN) { lastFocusX = fx; lastFocusY = fy; multiTouch = true; activeStroke.clear(); movingObject = navigating = false; beforeDrag = null; }
            else if (action == MotionEvent.ACTION_MOVE && !scaleDetector.isInProgress()) { view.panX += fx - lastFocusX; view.panY += fy - lastFocusY; lastFocusX = fx; lastFocusY = fy; invalidate(); }
            if (action == MotionEvent.ACTION_POINTER_UP) { lastFocusX = fx; lastFocusY = fy; } return true;
        }
        if (multiTouch && action == MotionEvent.ACTION_MOVE) return true;
        PointF raw = view.toWorld(event.getX(), event.getY()); cursorWorld = raw; PointF world = snapped(raw);
        if (traceEnabled) {
            if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_MOVE || action == MotionEvent.ACTION_UP) { traceX = raw.x; cursorWorld = raw; invalidate(); return true; }
        }
        switch (action) {
            case MotionEvent.ACTION_DOWN:
                multiTouch = false; lastWorld = raw; lastTouchX = event.getX(); lastTouchY = event.getY(); hoverWorld = world;
                if (tool == Tool.SELECT) beginSelect(raw);
                else if (tool == Tool.PEN) { activeStroke.clear(); activeStroke.add(raw); pressureTotal = event.getPressure(); pressureSamples = 1; }
                else if (tool == Tool.ERASER) eraseAt(raw); invalidate(); return true;
            case MotionEvent.ACTION_MOVE:
                hoverWorld = world;
                if (tool == Tool.SELECT) moveSelection(raw, event.getX(), event.getY());
                else if (tool == Tool.PEN && !multiTouch) { addStrokePoint(raw); pressureTotal += event.getPressure(); pressureSamples++; }
                else if (tool == Tool.ERASER) eraseAt(raw); invalidate(); return true;
            case MotionEvent.ACTION_UP:
                if (multiTouch) { multiTouch = false; movingObject = navigating = false; hoverWorld = cursorWorld = null; saveAutosave(); invalidate(); return true; }
                if (tool == Tool.SELECT) endSelect(); else if (tool == Tool.PEN) finishStroke(event.getToolType(0) == MotionEvent.TOOL_TYPE_STYLUS); else if (tool != Tool.ERASER) registerPoint(world);
                hoverWorld = cursorWorld = null; hoverSnapLabel = null; invalidate(); return true;
            case MotionEvent.ACTION_CANCEL:
                activeStroke.clear(); movingObject = navigating = false; hoverWorld = cursorWorld = null; hoverSnapLabel = null; invalidate(); return true;
            default: return true;
        }
    }
    private void beginSelect(PointF p) {
        if(lassoMode){lassoStart=new PointF(p.x,p.y);lassoEnd=new PointF(p.x,p.y);movingObject=navigating=false;return;}
        GeoObject hit = hitObject(p); if (hit != null) { select(hit); movingObject = !hit.locked; navigating = false; dragChanged = false; beforeDrag = serialize(); }
        else { select(null); movingObject = false; navigating = true; }
    }
    private void moveSelection(PointF p, float screenX, float screenY) {
        if(lassoMode&&lassoStart!=null){lassoEnd=new PointF(p.x,p.y);invalidate();return;}
        if (lastWorld == null) lastWorld = p; float dx = p.x - lastWorld.x, dy = p.y - lastWorld.y;
        if (movingObject && selected != null) {if(multiSelection.isEmpty())selected.translate(dx,dy);else for(GeoObject o:multiSelection)if(!o.locked)o.translate(dx,dy); dragChanged |= Math.abs(dx) + Math.abs(dy) > 1e-5; }
        else if (navigating) { view.panX += screenX - lastTouchX; view.panY += screenY - lastTouchY; }
        lastWorld = p; lastTouchX = screenX; lastTouchY = screenY;
    }
    private void endSelect(){if(lassoMode&&lassoStart!=null&&lassoEnd!=null){completeLasso();return;}if(movingObject&&dragChanged&&beforeDrag!=null){enforceConstraints();pushUndo(beforeDrag);afterStateChange();}movingObject=navigating=false;beforeDrag=null;saveAutosave();}
    private void addStrokePoint(PointF p) { if (activeStroke.isEmpty() || distance(activeStroke.get(activeStroke.size() - 1), p) * view.scale >= dp(1.5f)) activeStroke.add(new PointF(p.x, p.y)); }
    private void finishStroke(boolean stylus) {
        if (activeStroke.size() >= 2) { float width = drawWidth; if (stylus && pressureSamples > 0) width *= clamp(pressureTotal / pressureSamples * 1.3f, .65f, 1.55f); checkpoint(); objects.add(new FreehandObject(simplify(activeStroke, dp(1.2f) / view.scale), drawColor, width)); afterStateChange(); }
        activeStroke.clear(); pressureSamples = 0;
    }
    private void registerPoint(PointF point) {
        if (tool == Tool.POINT || tool == Tool.COORDINATE) { checkpoint(); objects.add(new PointObject(point, drawColor, drawWidth, tool == Tool.COORDINATE)); afterStateChange(); return; }
        if (tool.pointCount == 0) return;
        long now = SystemClock.uptimeMillis(); boolean doubleTap = lastTapWorld != null && now - lastTapTime < 340 && distance(lastTapWorld, point) * view.scale < dp(22); lastTapTime = now; lastTapWorld = new PointF(point.x, point.y);
        if ((tool == Tool.POLYGON || tool == Tool.AREA) && pending.size() >= 3 && (distance(pending.get(0), point) * view.scale < dp(18) || doubleTap)) { finishCurrentConstruction(); return; }
        pending.add(new PointF(point.x, point.y)); if (tool.pointCount > 0 && pending.size() >= tool.pointCount) completeFixedConstruction(); dispatchStatus();
    }
    private void completeFixedConstruction() {
        GeoObject object = null;
        switch (tool) {
            case TEXT: object = new TextObject(pending.get(0), pendingText, drawColor, drawWidth); break;
            case SEGMENT: object = new TwoPointObject(Kind.SEGMENT, pending.get(0), pending.get(1), drawColor, drawWidth); break;
            case LINE: object = new TwoPointObject(Kind.LINE, pending.get(0), pending.get(1), drawColor, drawWidth); break;
            case RAY: object = new TwoPointObject(Kind.RAY, pending.get(0), pending.get(1), drawColor, drawWidth); break;
            case RULER: object = new TwoPointObject(Kind.RULER, pending.get(0), pending.get(1), drawColor, drawWidth); break;
            case CIRCLE: object = new CircleObject(pending.get(0), pending.get(1), drawColor, drawWidth); break;
            case CIRCLE_MEASURE: object = new CircleObject(Kind.CIRCLE_MEASURE, pending.get(0), pending.get(1), drawColor, drawWidth); break;
            case ARC: object = new ArcObject(pending.get(0), pending.get(1), pending.get(2), drawColor, drawWidth); break;
            case ELLIPSE: object = new EllipseObject(pending.get(0), pending.get(1), drawColor, drawWidth); break;
            case RECTANGLE: object = new PolyObject(Kind.RECTANGLE, rectanglePoints(pending.get(0), pending.get(1)), drawColor, drawWidth); break;
            case TRIANGLE: object = new PolyObject(Kind.TRIANGLE, pending, drawColor, drawWidth); break;
            case REGULAR_POLYGON:
                PointF center = pending.get(0), edge = pending.get(1); object = new PolyObject(Kind.REGULAR_POLYGON, regularPolygon(center, distance(center, edge), (float) Math.toDegrees(Math.atan2(edge.y - center.y, edge.x - center.x)), regularSides), drawColor, drawWidth); break;
            case ANGLE: object = new PolyObject(Kind.ANGLE, pending, drawColor, drawWidth); break;
            case PROTRACTOR: object = new PolyObject(Kind.PROTRACTOR, pending, drawColor, drawWidth); break;
            case MIDPOINT:
                object = new PointObject(midpoint(pending.get(0), pending.get(1)), drawColor, drawWidth); object.name = "Midpoint"; break;
            case PARALLEL: object = constrainedLine(false); break;
            case PERPENDICULAR: object = constrainedLine(true); break;
            case PERP_BISECTOR:
                PointF a = pending.get(0), b = pending.get(1), mid = midpoint(a, b); float dx = b.x - a.x, dy = b.y - a.y;
                object = new TwoPointObject(Kind.LINE, mid, new PointF(mid.x - dy, mid.y + dx), drawColor, drawWidth); object.name = "Perpendicular bisector"; break;
            case ANGLE_BISECTOR: object = angleBisector(); break;
            default: break;
        }
        if (object != null) { checkpoint(); objects.add(object); pending.clear(); afterStateChange(); }
    }
    private GeoObject constrainedLine(boolean perpendicular) {
        PointF a = pending.get(0), b = pending.get(1), through = pending.get(2); float dx = b.x - a.x, dy = b.y - a.y; if (perpendicular) { float hold = dx; dx = -dy; dy = hold; }
        TwoPointObject line = new TwoPointObject(Kind.LINE, through, new PointF(through.x + dx, through.y + dy), drawColor, drawWidth); line.name = perpendicular ? "Perpendicular" : "Parallel"; return line;
    }
    private GeoObject angleBisector() {
        PointF a = pending.get(0), o = pending.get(1), b = pending.get(2); float ax = a.x - o.x, ay = a.y - o.y, bx = b.x - o.x, by = b.y - o.y;
        float al = (float) Math.hypot(ax, ay), bl = (float) Math.hypot(bx, by); if (al < 1e-6 || bl < 1e-6) return null;
        float dx = ax / al + bx / bl, dy = ay / al + by / bl; if (Math.hypot(dx, dy) < 1e-5) { dx = -ay / al; dy = ax / al; }
        TwoPointObject ray = new TwoPointObject(Kind.RAY, o, new PointF(o.x + dx, o.y + dy), drawColor, drawWidth); ray.name = "Angle bisector"; return ray;
    }
    private void eraseAt(PointF point) { GeoObject hit = hitObject(point); if (hit == null || hit.locked) return; checkpoint(); objects.remove(hit); if (hit == selected) select(null); afterStateChange(); }
    private GeoObject hitObject(PointF point) { float tolerance = dp(14) / view.scale; for (int i = objects.size() - 1; i >= 0; i--) { GeoObject o = objects.get(i); if (o.visible && o.hit(point, tolerance)) return o; } return null; }

    private PointF snapped(PointF raw) {
        hoverSnapLabel = null; if (!snapEnabled) return raw; float tolerance = dp(15) / view.scale; SnapCandidate best = null; float bestDistance = tolerance;
        for (SnapCandidate candidate : collectSnapCandidates()) { float d = distance(raw, candidate.point); if (d < bestDistance) { best = candidate; bestDistance = d; } }
        PointF result = raw;
        if (best != null) { result = new PointF(best.point.x, best.point.y); hoverSnapLabel = best.label; }
        else {
            float step = gridStep(); PointF grid = new PointF(Math.round(raw.x / step) * step, Math.round(raw.y / step) * step);
            if (distance(raw, grid) <= tolerance) { result = grid; hoverSnapLabel = "Grid"; }
        }
        if (angleSnap && !pending.isEmpty() && tool != Tool.POLYGON && tool != Tool.AREA && tool != Tool.ARC) {
            PointF origin = pending.get(pending.size() - 1); float r = distance(origin, result);
            if (r > .0001f) { double theta = Math.atan2(result.y - origin.y, result.x - origin.x), angle = Math.round(theta / Math.toRadians(15)) * Math.toRadians(15); PointF angular = new PointF(origin.x + (float) Math.cos(angle) * r, origin.y + (float) Math.sin(angle) * r); if (distance(result, angular) * view.scale < dp(10)) { result = angular; hoverSnapLabel = "15°"; } }
        }
        if (hoverSnapLabel != null && !hoverSnapLabel.equals(previousSnapLabel)) performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK);
        previousSnapLabel = hoverSnapLabel; return result;
    }
    private ArrayList<SnapCandidate> collectSnapCandidates() {
        ArrayList<SnapCandidate> result = new ArrayList<>(); ArrayList<TwoPointObject> lines = new ArrayList<>(); ArrayList<CircleObject> circles = new ArrayList<>();
        for (GeoObject object : objects) {
            if (!object.visible) continue;
            if (object instanceof PointObject) result.add(new SnapCandidate(((PointObject) object).point, "Point"));
            else if (object instanceof TwoPointObject) { TwoPointObject line = (TwoPointObject) object; result.add(new SnapCandidate(line.a, "Endpoint")); result.add(new SnapCandidate(line.b, "Endpoint")); result.add(new SnapCandidate(midpoint(line.a, line.b), "Midpoint")); if (object.kind != Kind.RULER) lines.add(line); }
            else if (object instanceof CircleObject) { CircleObject circle = (CircleObject) object; result.add(new SnapCandidate(circle.center, "Centre")); result.add(new SnapCandidate(circle.edge, "Radius point")); circles.add(circle); }
            else if (object instanceof EllipseObject) { EllipseObject ellipse = (EllipseObject) object; result.add(new SnapCandidate(ellipse.center, "Centre")); result.add(new SnapCandidate(ellipse.edge, "Radius point")); }
            else if (object instanceof ArcObject) { ArcObject a = (ArcObject) object; result.add(new SnapCandidate(a.center, "Centre")); result.add(new SnapCandidate(a.start, "Endpoint")); result.add(new SnapCandidate(a.end, "Endpoint")); }
            else if (object instanceof PolyObject) { List<PointF> vertices = ((PolyObject) object).vertices; for (int i = 0; i < vertices.size(); i++) { result.add(new SnapCandidate(vertices.get(i), "Vertex")); if (((PolyObject) object).closed() || i + 1 < vertices.size()) result.add(new SnapCandidate(midpoint(vertices.get(i), vertices.get((i + 1) % vertices.size())), "Midpoint")); } }
        }
        for (int i = 0; i < lines.size(); i++) for (int j = i + 1; j < lines.size(); j++) { PointF p = lineIntersection(lines.get(i).a, lines.get(i).b, lines.get(j).a, lines.get(j).b); if (p != null && accepts(lines.get(i), p) && accepts(lines.get(j), p) && bounded(p)) result.add(new SnapCandidate(p, "Intersection")); }
        for (TwoPointObject line : lines) for (CircleObject circle : circles) for (PointF p : lineCircleIntersections(line.a, line.b, circle.center, circle.radius())) if (accepts(line, p) && bounded(p)) result.add(new SnapCandidate(p, "Intersection"));
        for (int i = 0; i < circles.size(); i++) for (int j = i + 1; j < circles.size(); j++) for (PointF p : circleIntersections(circles.get(i), circles.get(j))) if (bounded(p)) result.add(new SnapCandidate(p, "Intersection"));
        return result;
    }
    private ArrayList<PointF> collectObjectPoints(boolean includeFreehand) {
        ArrayList<PointF> result = new ArrayList<>(); for (GeoObject object : objects) if (object.visible && !(object instanceof GraphObject)) { if (!includeFreehand && object instanceof FreehandObject) continue; result.addAll(object.handles()); } return result;
    }
    private static PointF lineIntersection(PointF a, PointF b, PointF c, PointF d) {
        float den = (a.x - b.x) * (c.y - d.y) - (a.y - b.y) * (c.x - d.x); if (Math.abs(den) < 1e-7) return null;
        float d1 = a.x * b.y - a.y * b.x, d2 = c.x * d.y - c.y * d.x;
        return new PointF((d1 * (c.x - d.x) - (a.x - b.x) * d2) / den, (d1 * (c.y - d.y) - (a.y - b.y) * d2) / den);
    }
    private static boolean accepts(TwoPointObject line, PointF p) {
        if (line.kind == Kind.LINE) return true; float dx = line.b.x - line.a.x, dy = line.b.y - line.a.y, l2 = dx * dx + dy * dy; if (l2 < 1e-10) return false;
        float t = ((p.x - line.a.x) * dx + (p.y - line.a.y) * dy) / l2; return line.kind == Kind.RAY ? t >= -1e-5f : t >= -1e-5f && t <= 1.00001f;
    }
    private static ArrayList<PointF> lineCircleIntersections(PointF a, PointF b, PointF c, float r) {
        ArrayList<PointF> out = new ArrayList<>(); float dx = b.x - a.x, dy = b.y - a.y, fx = a.x - c.x, fy = a.y - c.y;
        float aa = dx * dx + dy * dy; if (aa < 1e-10) return out; float bb = 2 * (fx * dx + fy * dy), cc = fx * fx + fy * fy - r * r, disc = bb * bb - 4 * aa * cc;
        if (disc < -1e-6) return out; disc = Math.max(0, disc); float root = (float) Math.sqrt(disc), t1 = (-bb - root) / (2 * aa), t2 = (-bb + root) / (2 * aa);
        out.add(new PointF(a.x + t1 * dx, a.y + t1 * dy)); if (Math.abs(t1 - t2) > 1e-5) out.add(new PointF(a.x + t2 * dx, a.y + t2 * dy)); return out;
    }
    private static ArrayList<PointF> circleIntersections(CircleObject a, CircleObject b) {
        ArrayList<PointF> out = new ArrayList<>(); float d = distance(a.center, b.center), r1 = a.radius(), r2 = b.radius(); if (d < 1e-7 || d > r1 + r2 + 1e-6 || d < Math.abs(r1 - r2) - 1e-6) return out;
        float along = (r1 * r1 - r2 * r2 + d * d) / (2 * d), h2 = Math.max(0, r1 * r1 - along * along), h = (float) Math.sqrt(h2), x = a.center.x + along * (b.center.x - a.center.x) / d, y = a.center.y + along * (b.center.y - a.center.y) / d;
        float rx = -(b.center.y - a.center.y) * h / d, ry = (b.center.x - a.center.x) * h / d; out.add(new PointF(x + rx, y + ry)); if (h > 1e-6) out.add(new PointF(x - rx, y - ry)); return out;
    }
    private float gridStep() { double target = 70.0 / view.scale, power = Math.pow(10, Math.floor(Math.log10(target))), normalized = target / power, nice = normalized < 1.5 ? 1 : normalized < 3.5 ? 2 : normalized < 7.5 ? 5 : 10; return (float) (nice * power); }
    private static boolean bounded(PointF p) { return Math.abs(p.x) < 1e6 && Math.abs(p.y) < 1e6; }

    private void select(GeoObject object){clearSelection();selected=object;if(object!=null){object.selected=true;if(!object.groupId.isEmpty())for(GeoObject o:objects)if(o.visible&&o.groupId.equals(object.groupId)){o.selected=true;multiSelection.add(o);}}if(listener!=null)listener.onSelectionChanged(selected!=null);invalidate();}private void clearSelection(){for(GeoObject o:objects)o.selected=false;multiSelection.clear();}private List<GeoObject>targets(){if(!multiSelection.isEmpty())return new ArrayList<>(multiSelection);ArrayList<GeoObject>r=new ArrayList<>();if(selected!=null)r.add(selected);return r;}
    private void completeLasso(){clearSelection();float l=Math.min(lassoStart.x,lassoEnd.x),r=Math.max(lassoStart.x,lassoEnd.x),b=Math.min(lassoStart.y,lassoEnd.y),t=Math.max(lassoStart.y,lassoEnd.y);for(GeoObject o:objects)if(o.visible){PointF c=o.center();if(c.x>=l&&c.x<=r&&c.y>=b&&c.y<=t){o.selected=true;multiSelection.add(o);}}selected=multiSelection.isEmpty()?null:multiSelection.get(multiSelection.size()-1);lassoStart=lassoEnd=null;lassoMode=false;if(listener!=null)listener.onSelectionChanged(selected!=null);dispatchStatus();invalidate();}
    private static GeoObject firstOf(List<GeoObject>t,Class<?>type){for(GeoObject o:t)if(type.isInstance(o))return o;return null;}private static GeoObject firstAngle(List<GeoObject>t){for(GeoObject o:t)if(o instanceof PolyObject&&((PolyObject)o).vertices.size()==3)return o;return null;}private GeoObject byId(String id){for(GeoObject o:objects)if(o.id.equals(id))return o;return null;}
    private void enforceConstraints(){for(int pass=0;pass<3;pass++)for(ConstraintLink c:constraints){GeoObject a=byId(c.first),b=byId(c.second);if(a==null)continue;if(c.type.equals("FIXED_LENGTH")&&a instanceof TwoPointObject)setLength((TwoPointObject)a,c.value);else if(c.type.equals("FIXED_ANGLE")&&a instanceof PolyObject){PolyObject angle=(PolyObject)a;if(angle.vertices.size()==3){PointF arm=angle.vertices.get(0),o=angle.vertices.get(1),end=angle.vertices.get(2);double base=Math.atan2(arm.y-o.y,arm.x-o.x),length=distance(o,end),direction=base+Math.toRadians(c.value);end.set((float)(o.x+Math.cos(direction)*length),(float)(o.y+Math.sin(direction)*length));}}else if(c.type.equals("MIDPOINT")&&a instanceof PointObject&&b!=null){ArrayList<PointF>h=b.handles();if(h.size()>=2)((PointObject)a).point.set((h.get(0).x+h.get(1).x)/2,(h.get(0).y+h.get(1).y)/2);}else if(c.type.equals("POINT_ON_OBJECT")&&a instanceof PointObject&&b!=null)project(((PointObject)a).point,b);else if(a instanceof TwoPointObject&&b instanceof TwoPointObject){TwoPointObject ref=(TwoPointObject)a,target=(TwoPointObject)b;double dx=ref.b.x-ref.a.x,dy=ref.b.y-ref.a.y,length=distance(target.a,target.b);if(c.type.equals("PARALLEL"))setDirection(target,dx,dy,length);else if(c.type.equals("PERPENDICULAR"))setDirection(target,-dy,dx,length);else if(c.type.equals("EQUAL_LENGTH"))setLength(target,distance(ref.a,ref.b));}}}
    private static void setLength(TwoPointObject l,double length){double dx=l.b.x-l.a.x,dy=l.b.y-l.a.y,n=Math.hypot(dx,dy);if(n<1e-9){dx=1;dy=0;n=1;}l.b.set((float)(l.a.x+dx/n*length),(float)(l.a.y+dy/n*length));}private static void setDirection(TwoPointObject l,double dx,double dy,double length){double n=Math.hypot(dx,dy);if(n>1e-9)l.b.set((float)(l.a.x+dx/n*length),(float)(l.a.y+dy/n*length));}private static void project(PointF p,GeoObject o){if(o instanceof TwoPointObject){TwoPointObject l=(TwoPointObject)o;float dx=l.b.x-l.a.x,dy=l.b.y-l.a.y;double den=dx*dx+dy*dy;if(den>1e-12){double t=((p.x-l.a.x)*dx+(p.y-l.a.y)*dy)/den;if(l.kind==Kind.SEGMENT||l.kind==Kind.RULER)t=Math.max(0,Math.min(1,t));else if(l.kind==Kind.RAY)t=Math.max(0,t);p.set((float)(l.a.x+t*dx),(float)(l.a.y+t*dy));}}else if(o instanceof CircleObject){CircleObject c=(CircleObject)o;double dx=p.x-c.center.x,dy=p.y-c.center.y,n=Math.hypot(dx,dy);if(n<1e-9){dx=1;dy=0;n=1;}p.set((float)(c.center.x+dx/n*c.radius()),(float)(c.center.y+dy/n*c.radius()));}}
    private void checkpoint() { pushUndo(serialize()); }
    private void pushUndo(String state) { undo.addLast(state); while (undo.size() > MAX_HISTORY) undo.removeFirst(); redo.clear(); dispatchHistory(); }
    private void afterStateChange() { saveAutosave(); dispatchHistory(); dispatchStatus(); invalidate(); }
    private void dispatchStatus() {
        if (listener == null) return; String hint = traceEnabled ? "Drag across the plot to trace exact coordinates" : tool.hint;
        if (!pending.isEmpty()) { if (tool == Tool.POLYGON || tool == Tool.AREA) hint = pending.size() + " vertices • tap first point or Done to close"; else hint = pending.size() + " of " + tool.pointCount + " points chosen"; }
        if (tool == Tool.REGULAR_POLYGON) hint += " • " + regularSides + " sides";
        if (tool == Tool.RULER || tool == Tool.AREA || tool == Tool.COORDINATE || tool == Tool.CIRCLE_MEASURE) hint += " • 1 grid unit = " + format(view.measurementScale) + " " + view.measurementUnit;
        listener.onToolStatus(traceEnabled ? "Graph trace" : tool.label, hint, (tool == Tool.POLYGON || tool == Tool.AREA) && pending.size() >= 3); dispatchHistory();
    }
    private void dispatchHistory() { if (listener != null) listener.onHistoryChanged(!undo.isEmpty(), !redo.isEmpty()); }

    public String serialize() {
        JSONObject root = new JSONObject(); JSONArray items = new JSONArray();
        try {
            for (GeoObject object : objects) items.put(object.toJson()); root.put("version", 3); root.put("objects", items);root.put("table",dataTable.toJson());JSONArray links=new JSONArray();for(ConstraintLink link:constraints)links.put(link.json());root.put("constraints",links);
            root.put("background", backgroundStyle.name()); root.put("grid", backgroundStyle != BackgroundStyle.PLAIN); root.put("dark", darkCanvas);
            root.put("snap", snapEnabled); root.put("angleSnap", angleSnap); root.put("regularSides", regularSides);
            root.put("measurementUnit",view.measurementUnit);root.put("measurementScale",view.measurementScale);root.put("measurementPrecision",view.measurementPrecision);
            root.put("scale", view.scale); root.put("panX", view.panX); root.put("panY", view.panY);
        } catch (JSONException ignored) { }
        return root.toString();
    }
    public void importProject(String data) throws JSONException {
        JSONObject root = new JSONObject(data); int version = root.optInt("version", -1); if (!root.has("objects") || (version != 1 && version != 2 && version != 3)) throw new JSONException("Not a supported Axiom Canvas project");
        JSONArray items = root.getJSONArray("objects"); if (items.length() > 10000) throw new JSONException("Project contains too many objects");
        for (int i = 0; i < items.length(); i++) GeometryModel.fromJson(items.getJSONObject(i)); checkpoint(); restore(data); afterStateChange();
    }
    public void restore(String data) {
        try {
            JSONObject root = new JSONObject(data); JSONArray items = root.getJSONArray("objects"); ArrayList<GeoObject> restored = new ArrayList<>();
            for (int i = 0; i < Math.min(items.length(), 10000); i++) try { restored.add(GeometryModel.fromJson(items.getJSONObject(i))); } catch (RuntimeException | JSONException ignored) { }
            objects.clear(); objects.addAll(restored);constraints.clear();JSONArray links=root.optJSONArray("constraints");if(links!=null)for(int i=0;i<Math.min(links.length(),2000);i++)constraints.add(ConstraintLink.from(links.getJSONObject(i)));JSONObject table=root.optJSONObject("table");dataTable=table==null?new DataTableModel():DataTableModel.fromJson(table);enforceConstraints();
            String background = root.optString("background", root.optBoolean("grid", true) ? "CARTESIAN" : "PLAIN"); try { backgroundStyle = BackgroundStyle.valueOf(background); } catch (IllegalArgumentException ignored) { backgroundStyle = BackgroundStyle.CARTESIAN; }
            darkCanvas = root.optBoolean("dark", false); snapEnabled = root.optBoolean("snap", true); angleSnap = root.optBoolean("angleSnap", true); regularSides = clampInt(root.optInt("regularSides", 6), 3, 24);
            String restoredUnit=root.optString("measurementUnit","units").trim();view.measurementUnit=restoredUnit.isEmpty()?"units":restoredUnit.substring(0,Math.min(12,restoredUnit.length()));double restoredMeasurementScale=root.optDouble("measurementScale",1);view.measurementScale=Double.isFinite(restoredMeasurementScale)?Math.max(1e-12,Math.min(1e9,restoredMeasurementScale)):1;view.measurementPrecision=clampInt(root.optInt("measurementPrecision",2),0,4);
            view.scale = clamp((float) root.optDouble("scale", 72), 12f, 480f); view.panX = clamp((float) root.optDouble("panX", 0), -1e7f, 1e7f); view.panY = clamp((float) root.optDouble("panY", 0), -1e7f, 1e7f); select(null);
        } catch (JSONException ignored) { }
    }

    private void loadWorkspace() {
        SharedPreferences prefs = getContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE); String index = prefs.getString(BOARD_INDEX, null);
        if (index == null) {
            JSONArray boards = new JSONArray(); JSONObject main = new JSONObject(); try { main.put("id", "main"); main.put("title", "My Canvas"); boards.put(main); } catch (JSONException ignored) { }
            String legacy = prefs.getString(LEGACY_PROJECT, null); if (legacy == null) legacy = emptyProject();
            prefs.edit().putString(BOARD_INDEX, boards.toString()).putString(ACTIVE_BOARD, "main").putString(BOARD_PREFIX + "main", legacy).apply();
        }
        List<BoardInfo> boards = boards(); activeBoardId = prefs.getString(ACTIVE_BOARD, boards.isEmpty() ? "main" : boards.get(0).id); activeBoardTitle = titleFor(activeBoardId, boards);
        restore(prefs.getString(BOARD_PREFIX + activeBoardId, emptyProject()));
    }
    private void saveAutosave() { getContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(BOARD_PREFIX + activeBoardId, serialize()).putString(ACTIVE_BOARD, activeBoardId).apply(); }
    public List<BoardInfo> boards() {
        ArrayList<BoardInfo> result = new ArrayList<>(); String data = getContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(BOARD_INDEX, "[]");
        try { JSONArray array = new JSONArray(data); for (int i = 0; i < array.length(); i++) { JSONObject item = array.getJSONObject(i); result.add(new BoardInfo(item.getString("id"), item.optString("title", "Untitled"))); } } catch (JSONException ignored) { }
        return result;
    }
    public void switchBoard(String id) {
        for (BoardInfo board : boards()) if (board.id.equals(id)) { saveAutosave(); activeBoardId = id; activeBoardTitle = board.title; getContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(ACTIVE_BOARD, id).apply(); restore(getContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(BOARD_PREFIX + id, emptyProject())); undo.clear(); redo.clear(); dispatchHistory(); dispatchStatus(); invalidate(); return; }
    }
    public void createBoard(String title) {
        saveAutosave(); String id = UUID.randomUUID().toString(); List<BoardInfo> list = boards(); list.add(new BoardInfo(id, cleanTitle(title))); writeBoards(list);
        getContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(BOARD_PREFIX + id, emptyProject()).apply(); switchBoard(id);
    }
    public void duplicateCurrentBoard(String title) {
        saveAutosave(); String id = UUID.randomUUID().toString(); List<BoardInfo> list = boards(); list.add(new BoardInfo(id, cleanTitle(title))); writeBoards(list);
        getContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(BOARD_PREFIX + id, serialize()).apply(); switchBoard(id);
    }
    public void renameCurrentBoard(String title) {
        List<BoardInfo> list = boards(); for (int i = 0; i < list.size(); i++) if (list.get(i).id.equals(activeBoardId)) list.set(i, new BoardInfo(activeBoardId, cleanTitle(title))); writeBoards(list); activeBoardTitle = cleanTitle(title);
    }
    public boolean deleteCurrentBoard() {
        List<BoardInfo> list = boards(); if (list.size() <= 1) return false; String old = activeBoardId; list.removeIf(board -> board.id.equals(old)); writeBoards(list);
        getContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(BOARD_PREFIX + old).apply(); switchBoard(list.get(0).id); return true;
    }
    private void writeBoards(List<BoardInfo> list) {
        JSONArray array = new JSONArray(); for (BoardInfo board : list) { JSONObject item = new JSONObject(); try { item.put("id", board.id); item.put("title", board.title); array.put(item); } catch (JSONException ignored) { } }
        getContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(BOARD_INDEX, array.toString()).apply();
    }
    private static String cleanTitle(String title) { String value = title == null ? "Untitled" : title.trim(); return value.isEmpty() ? "Untitled" : value.substring(0, Math.min(60, value.length())); }
    private static String titleFor(String id, List<BoardInfo> boards) { for (BoardInfo b : boards) if (b.id.equals(id)) return b.title; return boards.isEmpty() ? "My Canvas" : boards.get(0).title; }
    private static String emptyProject() { return "{\"version\":3,\"objects\":[],\"background\":\"CARTESIAN\",\"scale\":72}"; }

    public byte[] renderPng(int maxSide) { return renderPng(maxSide, false); }
    public byte[] renderPng(int maxSide, boolean transparent) {
        int sourceW = Math.max(1, getWidth()), sourceH = Math.max(1, getHeight()); float factor = Math.min(1f, maxSide / (float) Math.max(sourceW, sourceH));
        int w = Math.max(1, Math.round(sourceW * factor)), h = Math.max(1, Math.round(sourceH * factor)); Bitmap bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888); Canvas canvas = new Canvas(bitmap); canvas.scale(factor, factor);
        GeoObject keep = selected; if (keep != null) keep.selected = false; try { if (transparent) canvas.drawColor(Color.TRANSPARENT, android.graphics.PorterDuff.Mode.CLEAR); drawScene(canvas, false, !transparent); } finally { if (keep != null) keep.selected = true; }
        ByteArrayOutputStream stream = new ByteArrayOutputStream(); bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream); bitmap.recycle(); return stream.toByteArray();
    }
    public byte[] renderPdf() {
        PdfDocument document = new PdfDocument(); PdfDocument.Page page = document.startPage(new PdfDocument.PageInfo.Builder(842, 595, 1).create()); Canvas out = page.getCanvas(); out.drawColor(Color.WHITE);
        float scale = Math.min(802f / Math.max(1, getWidth()), 555f / Math.max(1, getHeight())); out.translate(20, 20); out.scale(scale, scale);
        GeoObject keep = selected; if (keep != null) keep.selected = false; try { drawScene(out, false, true); } finally { if (keep != null) keep.selected = true; }
        document.finishPage(page); ByteArrayOutputStream bytes = new ByteArrayOutputStream(); try { document.writeTo(bytes); } catch (java.io.IOException impossible) { throw new IllegalStateException(impossible); } finally { document.close(); } return bytes.toByteArray();
    }
    public byte[] renderSvg() {
        StringBuilder s = new StringBuilder(); String bg = darkCanvas ? "#151923" : "#F9FAFE";
        s.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"").append(getWidth()).append("\" height=\"").append(getHeight()).append("\" viewBox=\"0 0 ").append(getWidth()).append(' ').append(getHeight()).append("\">\n<rect width=\"100%\" height=\"100%\" fill=\"").append(bg).append("\"/>\n");
        if (backgroundStyle == BackgroundStyle.CARTESIAN || backgroundStyle == BackgroundStyle.DOTS) appendSvgGrid(s);
        for (GeoObject object : objects) if (object.visible) appendSvgObject(s, object); s.append("</svg>"); return s.toString().getBytes(StandardCharsets.UTF_8);
    }
    private void appendSvgGrid(StringBuilder s) {
        float step = gridStep(), left = (float) Math.floor(view.left() / step) * step; String minor = darkCanvas ? "#242A36" : "#E4E7EF";
        if (backgroundStyle == BackgroundStyle.DOTS) {
            for (float x = left; x <= view.right(); x += step) for (float y = (float) Math.floor(view.bottom() / step) * step; y <= view.top(); y += step) { PointF p = view.toScreen(new PointF(x, y)); s.append("<circle cx=\"").append(f(p.x)).append("\" cy=\"").append(f(p.y)).append("\" r=\"1.4\" fill=\"").append(minor).append("\"/>\n"); }
        } else {
            for (float x = left; x <= view.right(); x += step) { PointF p = view.toScreen(new PointF(x, 0)); svgLine(s, p.x, 0, p.x, getHeight(), minor, 1, 0); }
            for (float y = (float) Math.floor(view.bottom() / step) * step; y <= view.top(); y += step) { PointF p = view.toScreen(new PointF(0, y)); svgLine(s, 0, p.y, getWidth(), p.y, minor, 1, 0); }
        }
        PointF o = view.toScreen(new PointF()); String axis = darkCanvas ? "#778092" : "#9AA1AF"; svgLine(s, o.x, 0, o.x, getHeight(), axis, 1.5f, 0); svgLine(s, 0, o.y, getWidth(), o.y, axis, 1.5f, 0);
    }
    private void appendSvgObject(StringBuilder s, GeoObject o) {
        String color = String.format(Locale.US, "#%06X", 0xFFFFFF & o.color); float width = o.strokeWidth; String dash = o.dashStyle == 1 ? " stroke-dasharray=\"18 12\"" : o.dashStyle == 2 ? " stroke-dasharray=\"3 9\"" : "";
        if (o instanceof PointObject) { PointF p = view.toScreen(((PointObject) o).point); s.append("<circle cx=\"").append(f(p.x)).append("\" cy=\"").append(f(p.y)).append("\" r=\"5\" fill=\"").append(color).append("\"/>\n"); }
        else if (o instanceof TwoPointObject) {
            TwoPointObject line = (TwoPointObject) o; PointF a = view.toScreen(line.a), b = view.toScreen(line.b);
            if (line.kind == Kind.LINE || line.kind == Kind.RAY) { float dx = b.x-a.x,dy=b.y-a.y,length=(float)Math.hypot(dx,dy); if(length<.001)return;dx/=length;dy/=length;if(line.kind==Kind.LINE)svgLine(s,a.x-dx*10000,a.y-dy*10000,a.x+dx*10000,a.y+dy*10000,color,width,line.dashStyle);else svgLine(s,a.x,a.y,a.x+dx*10000,a.y+dy*10000,color,width,line.dashStyle); }
            else svgLine(s,a.x,a.y,b.x,b.y,color,width,line.dashStyle);
        } else if (o instanceof CircleObject) { CircleObject circle=(CircleObject)o;PointF c=view.toScreen(circle.center);s.append("<circle cx=\"").append(f(c.x)).append("\" cy=\"").append(f(c.y)).append("\" r=\"").append(f(circle.radius()*view.scale)).append("\" fill=\"").append(color).append("\" fill-opacity=\"").append(f(o.fillOpacity)).append("\" stroke=\"").append(color).append("\" stroke-width=\"").append(f(width)).append("\"").append(dash).append("/>\n"); }
        else if (o instanceof EllipseObject) { EllipseObject e=(EllipseObject)o;PointF c=view.toScreen(e.center);s.append("<ellipse cx=\"").append(f(c.x)).append("\" cy=\"").append(f(c.y)).append("\" rx=\"").append(f(e.radiusX()*view.scale)).append("\" ry=\"").append(f(e.radiusY()*view.scale)).append("\" fill=\"").append(color).append("\" fill-opacity=\"").append(f(o.fillOpacity)).append("\" stroke=\"").append(color).append("\" stroke-width=\"").append(f(width)).append("\"").append(dash).append("/>\n"); }
        else if (o instanceof TextObject) { TextObject t=(TextObject)o;PointF p=view.toScreen(t.position);s.append("<text x=\"").append(f(p.x)).append("\" y=\"").append(f(p.y)).append("\" fill=\"").append(color).append("\" font-family=\"sans-serif\" font-size=\"").append(f(Math.max(13,10+o.strokeWidth*1.6f))).append("\">").append(xml(t.value)).append("</text>\n"); }
        else if (o instanceof GraphObject) {
            GraphObject graph=(GraphObject)o;s.append("<polyline fill=\"none\" stroke=\"").append(color).append("\" stroke-width=\"").append(f(width)).append("\"").append(dash).append(" points=\"");int samples=Math.max(500,getWidth());double from=graph.mode==GraphMode.CARTESIAN?Math.max(view.left(),graph.domainMin):graph.domainMin,to=graph.mode==GraphMode.CARTESIAN?Math.min(view.right(),graph.domainMax):graph.domainMax;
            for(int i=0;i<=samples;i++){PointF w=graph.pointAt(from+(to-from)*i/samples);if(Float.isFinite(w.x)&&Float.isFinite(w.y)){PointF p=view.toScreen(w);s.append(f(p.x)).append(',').append(f(p.y)).append(' ');}}s.append("\"/>\n");
        } else {
            List<PointF> points; boolean close=false;
            if(o instanceof FreehandObject)points=((FreehandObject)o).path; else if(o instanceof PolyObject){points=((PolyObject)o).vertices;close=((PolyObject)o).closed();}
            else if(o instanceof ArcObject){ArcObject arc=(ArcObject)o;PointF c=view.toScreen(arc.center),a=view.toScreen(arc.start),b=view.toScreen(arc.end);float r=distance(arc.center,arc.start)*view.scale,sweep=normalizeSweep(screenAngle(arc.center,arc.end)-screenAngle(arc.center,arc.start)),endAngle=(float)Math.atan2(b.y-c.y,b.x-c.x);s.append("<path d=\"M ").append(f(a.x)).append(' ').append(f(a.y)).append(" A ").append(f(r)).append(' ').append(f(r)).append(" 0 ").append(sweep>180?"1":"0").append(" 1 ").append(f(c.x+(float)Math.cos(endAngle)*r)).append(' ').append(f(c.y+(float)Math.sin(endAngle)*r)).append("\" fill=\"none\" stroke=\"").append(color).append("\" stroke-width=\"").append(f(width)).append("\"").append(dash).append("/>\n");return;} else return;
            s.append(close?"<polygon":"<polyline").append(" points=\"");for(PointF p:points){PointF q=view.toScreen(p);s.append(f(q.x)).append(',').append(f(q.y)).append(' ');}s.append("\" fill=\"").append(close?color:"none").append("\" fill-opacity=\"").append(close?f(o.fillOpacity):"0").append("\" stroke=\"").append(color).append("\" stroke-width=\"").append(f(width)).append("\"").append(dash).append(" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>\n");
        }
    }
    private static void svgLine(StringBuilder s,float x1,float y1,float x2,float y2,String color,float width,int dash){s.append("<line x1=\"").append(f(x1)).append("\" y1=\"").append(f(y1)).append("\" x2=\"").append(f(x2)).append("\" y2=\"").append(f(y2)).append("\" stroke=\"").append(color).append("\" stroke-width=\"").append(f(width)).append("\"");if(dash==1)s.append(" stroke-dasharray=\"18 12\"");else if(dash==2)s.append(" stroke-dasharray=\"3 9\"");s.append("/>\n");}
    private static String f(float v){return String.format(Locale.US,"%.2f",v);} private static String xml(String s){return s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;");}

    private static Kind kindFor(Tool tool) { switch (tool) { case SEGMENT:return Kind.SEGMENT;case LINE:return Kind.LINE;case RAY:return Kind.RAY;case RULER:return Kind.RULER;default:throw new IllegalArgumentException(); } }
    private static ArrayList<PointF> rectanglePoints(PointF a, PointF b) { return list(new PointF(a.x,a.y),new PointF(b.x,a.y),new PointF(b.x,b.y),new PointF(a.x,b.y)); }
    private static ArrayList<PointF> regularPolygon(PointF center,float radius,float degrees,int sides){ArrayList<PointF> out=new ArrayList<>();double start=Math.toRadians(degrees);for(int i=0;i<sides;i++){double a=start+i*Math.PI*2/sides;out.add(new PointF(center.x+(float)Math.cos(a)*radius,center.y+(float)Math.sin(a)*radius));}return out;}
    private static PointF midpoint(PointF a,PointF b){return new PointF((a.x+b.x)*.5f,(a.y+b.y)*.5f);}
    private static ArrayList<PointF> simplify(List<PointF> input,float tolerance){if(input.size()<3)return copy(input);ArrayList<PointF> out=new ArrayList<>();out.add(new PointF(input.get(0).x,input.get(0).y));for(int i=1;i<input.size()-1;i++)if(segmentDistance(input.get(i),out.get(out.size()-1),input.get(i+1))>tolerance)out.add(new PointF(input.get(i).x,input.get(i).y));out.add(new PointF(input.get(input.size()-1).x,input.get(input.size()-1).y));return out;}
    private float dp(float value){return value*getResources().getDisplayMetrics().density;} private static float clamp(float value,float min,float max){return Math.max(min,Math.min(max,value));} private static int clampInt(int value,int min,int max){return Math.max(min,Math.min(max,value));}
    private static boolean finite(double... values){for(double v:values)if(!Double.isFinite(v))return false;return true;}
    private static double directionDegrees(PointF a,PointF b){double degrees=Math.toDegrees(Math.atan2(b.y-a.y,b.x-a.x));return degrees<0?degrees+360:degrees;}
}
