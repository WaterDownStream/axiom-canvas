package io.axiom.canvas;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputFilter;
import android.text.InputType;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowInsetsController;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONException;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Canvas-first application shell for Axiom Canvas 3.1. */
public final class MainActivity extends Activity implements GeometryCanvas.Listener {
    private static final String TAG = "AxiomCanvas";
    private static final int EXPORT_FILE = 91;
    private static final int IMPORT_PROJECT = 92;
    private static final int IMPORT_CSV = 93;
    private static final int[] PALETTE = {
            0xFF26354F, 0xFF526DFF, 0xFFE54B4B, 0xFF00A37A,
            0xFFF29E32, 0xFF7B55D9, 0xFFE83E8C, 0xFF111111,
            0xFF18A7C7, 0xFF7A8A46
    };

    private enum Shelf { DRAW, CONSTRUCT, CONSTRAIN, MEASURE }
    private static final GeometryCanvas.Tool[] DRAW_TOOLS = {
            GeometryCanvas.Tool.SELECT, GeometryCanvas.Tool.PEN, GeometryCanvas.Tool.ERASER, GeometryCanvas.Tool.TEXT
    };
    private static final GeometryCanvas.Tool[] CONSTRUCT_TOOLS = {
            GeometryCanvas.Tool.POINT, GeometryCanvas.Tool.SEGMENT, GeometryCanvas.Tool.LINE, GeometryCanvas.Tool.RAY,
            GeometryCanvas.Tool.CIRCLE, GeometryCanvas.Tool.ARC, GeometryCanvas.Tool.ELLIPSE, GeometryCanvas.Tool.RECTANGLE,
            GeometryCanvas.Tool.TRIANGLE, GeometryCanvas.Tool.POLYGON, GeometryCanvas.Tool.REGULAR_POLYGON, GeometryCanvas.Tool.ANGLE
    };
    private static final GeometryCanvas.Tool[] CONSTRAIN_TOOLS = {
            GeometryCanvas.Tool.MIDPOINT, GeometryCanvas.Tool.PARALLEL, GeometryCanvas.Tool.PERPENDICULAR,
            GeometryCanvas.Tool.PERP_BISECTOR, GeometryCanvas.Tool.ANGLE_BISECTOR
    };
    private static final GeometryCanvas.Tool[] MEASURE_TOOLS = {
            GeometryCanvas.Tool.RULER, GeometryCanvas.Tool.PROTRACTOR, GeometryCanvas.Tool.AREA,
            GeometryCanvas.Tool.COORDINATE, GeometryCanvas.Tool.CIRCLE_MEASURE
    };

    private GeometryCanvas canvas;
    private LinearLayout toolRow, shelfRow;
    private TextView toolTitle, toolHint, boardTitle;
    private Button undoButton, redoButton, finishButton, colorButton, widthButton, exactButton;
    private LinearLayout selectionBar;
    private GeometryCanvas.Tool selectedTool = GeometryCanvas.Tool.SELECT;
    private Shelf selectedShelf = Shelf.DRAW;
    private byte[] pendingExport;
    private int tablePage;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        TextView launchSurface = new TextView(this);
        launchSurface.setText("△\nAXIOM CANVAS"); launchSurface.setTextColor(Color.WHITE); launchSurface.setTextSize(22);
        launchSurface.setGravity(Gravity.CENTER); launchSurface.setBackgroundColor(0xFF11141B); setContentView(launchSurface);
        // Retain the proven OEM-safe delayed initialization used by 1.0.1.
        launchSurface.post(() -> initializeApplication(state));
    }

    private void initializeApplication(Bundle state) {
        try {
            configureWindow(); setContentView(buildInterface()); canvas.setListener(this); selectTool(GeometryCanvas.Tool.SELECT); refreshBoardTitle();
            if (!getPreferences(MODE_PRIVATE).getBoolean("v3_seen", false)) {
                getPreferences(MODE_PRIVATE).edit().putBoolean("v3_seen", true).apply();
                Toast.makeText(this, "Axiom 3.1 — simple by default, powerful when you need it", Toast.LENGTH_LONG).show();
            }
        } catch (Throwable error) { Log.e(TAG, "Startup failed", error); showStartupFailure(error); }
    }

    @SuppressWarnings("deprecation")
    private void configureWindow() {
        Window window = getWindow(); window.setStatusBarColor(0xFF11141B); window.setNavigationBarColor(0xFF11141B);
        if (android.os.Build.VERSION.SDK_INT >= 30) { WindowInsetsController controller = window.getInsetsController(); if (controller != null) controller.setSystemBarsAppearance(0, WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS | WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS); }
    }

    private View buildInterface() {
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(0xFFF6F7FB);
        root.addView(buildTopBar(), new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(62)));
        FrameLayout stage = new FrameLayout(this); canvas = new GeometryCanvas(this);
        stage.addView(canvas, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        stage.addView(buildContextBar(),frame(ViewGroup.LayoutParams.MATCH_PARENT,dp(58),Gravity.TOP,dp(12),dp(10),dp(12),0));
        stage.addView(buildZoomRail(), frame(dp(44), ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.END | Gravity.CENTER_VERTICAL, 0, 0, dp(10), 0));
        selectionBar = buildSelectionBar(); stage.addView(selectionBar, frame(ViewGroup.LayoutParams.WRAP_CONTENT, dp(48), Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL, 0, 0, 0, dp(10))); selectionBar.setVisibility(View.GONE);
        root.addView(stage, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));
        root.addView(buildToolDock(), new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(78)));
        return root;
    }

    private View buildTopBar() {
        LinearLayout bar = new LinearLayout(this); bar.setGravity(Gravity.CENTER_VERTICAL); bar.setPadding(dp(14), 0, dp(8), 0); bar.setBackgroundColor(0xFF111827);
        TextView mark = text("A", 15, Color.WHITE, true); mark.setGravity(Gravity.CENTER);mark.setBackground(roundRect(0xFF5B6CFF,12,0,0));bar.addView(mark, new LinearLayout.LayoutParams(dp(36), dp(36)));
        LinearLayout brand = new LinearLayout(this); brand.setOrientation(LinearLayout.VERTICAL);
        brand.setPadding(dp(10),0,0,0);TextView title = text("Axiom Canvas", 16, Color.WHITE, true); boardTitle = text("My Canvas", 10, 0xFF9FA8BA, false); boardTitle.setSingleLine(true);
        brand.addView(title); brand.addView(boardTitle); brand.setOnClickListener(v -> showBoardsDialog()); bar.addView(brand, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        undoButton = iconButton("↶", "Undo", v -> canvas.undo()); redoButton = iconButton("↷", "Redo", v -> canvas.redo());
        Button more = iconButton("⋮", "More options", this::showMoreMenu);
        bar.addView(undoButton); bar.addView(redoButton); bar.addView(more); return bar;
    }

    private View buildContextBar() {
        LinearLayout bar = new LinearLayout(this); bar.setGravity(Gravity.CENTER_VERTICAL); bar.setPadding(dp(14), dp(6), dp(7), dp(6)); bar.setBackground(roundRect(0xF9FFFFFF,18,0x18000000,1));bar.setElevation(dp(4));
        LinearLayout copy = new LinearLayout(this); copy.setOrientation(LinearLayout.VERTICAL); toolTitle = text("Select", 14, 0xFF172033, true);
        toolHint = text("Tap an object, or drag empty space to move around", 10.5f, 0xFF667085, false); toolHint.setSingleLine(true); toolHint.setEllipsize(android.text.TextUtils.TruncateAt.END);
        copy.addView(toolTitle); copy.addView(toolHint); bar.addView(copy, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        finishButton = compactButton("Done", 0xFF526DFF, Color.WHITE, v -> canvas.finishCurrentConstruction()); finishButton.setVisibility(View.GONE);
        exactButton = compactButton("123", 0xFFF0F2F7, 0xFF364152, v -> showExactDialog()); exactButton.setContentDescription("Exact numeric entry");
        colorButton = compactButton("●", 0xFFF0F2F7, canvasColor(), v -> showColorDialog()); widthButton = compactButton("4", 0xFFF0F2F7, 0xFF364152, v -> showWidthDialog());
        bar.addView(finishButton, margin(dp(60), dp(40), 0, 0, dp(6), 0)); bar.addView(exactButton, margin(dp(42), dp(40), 0, 0, dp(6), 0));
        bar.addView(colorButton, margin(dp(42), dp(40), 0, 0, dp(6), 0)); bar.addView(widthButton, margin(dp(44), dp(40), 0, 0, 0, 0)); return bar;
    }

    private View buildToolDock() {
        LinearLayout dock = new LinearLayout(this); dock.setOrientation(LinearLayout.VERTICAL);dock.setPadding(dp(6),dp(5),dp(6),dp(7));dock.setBackgroundColor(0xFFFFFFFF);dock.setElevation(dp(10));
        toolRow = new LinearLayout(this); toolRow.setGravity(Gravity.CENTER);dock.addView(toolRow,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT));
        rebuildTools(); return dock;
    }

    private void rebuildShelves() {
        rebuildTools();
    }
    private void rebuildTools() {
        if (toolRow == null) return; toolRow.removeAllViews();
        GeometryCanvas.Tool[] quick={GeometryCanvas.Tool.SELECT,GeometryCanvas.Tool.PEN,GeometryCanvas.Tool.SEGMENT,GeometryCanvas.Tool.CIRCLE};
        for(GeometryCanvas.Tool tool:quick){Button button=quickToolButton(toolGlyph(tool),shortLabel(tool),tool==selectedTool,v->selectTool(tool));if(tool==GeometryCanvas.Tool.SELECT)button.setOnLongClickListener(v->{canvas.startLassoSelection();Toast.makeText(this,"Drag around objects to select them",Toast.LENGTH_SHORT).show();return true;});toolRow.addView(button,new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.MATCH_PARENT,1));}
        Button measure=quickToolButton("↔","Measure",isMeasurementTool(selectedTool),v->showMeasureMenu());toolRow.addView(measure,new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.MATCH_PARENT,1));
        Button all=quickToolButton("＋","Tools",false,v->showToolLibrary());toolRow.addView(all,new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.MATCH_PARENT,1));
    }

    private View buildZoomRail() {
        LinearLayout rail = new LinearLayout(this); rail.setOrientation(LinearLayout.VERTICAL); rail.setGravity(Gravity.CENTER); rail.setPadding(dp(3), dp(4), dp(3), dp(4)); rail.setBackground(roundRect(0xEFFFFFFF, 16, 0x16000000, 1));
        rail.addView(miniButton("+", v -> canvas.zoomBy(1.25f))); rail.addView(miniButton("⊡", v -> canvas.zoomToFit())); rail.addView(miniButton("−", v -> canvas.zoomBy(.8f))); return rail;
    }
    private LinearLayout buildSelectionBar() {
        LinearLayout bar = new LinearLayout(this); bar.setGravity(Gravity.CENTER); bar.setPadding(dp(5), dp(4), dp(5), dp(4)); bar.setBackground(roundRect(0xF7FFFFFF, 18, 0x22000000, 1));bar.setElevation(dp(8));
        bar.addView(compactButton("Edit", 0xFF5B6CFF, Color.WHITE, v -> showSelectionInspector()), margin(dp(68), dp(38), 0, 0, dp(5), 0));
        bar.addView(compactButton("More", 0xFFF0F2F7, 0xFF344054, this::showSelectionActions), margin(dp(68), dp(38), 0, 0, dp(5), 0));
        bar.addView(compactButton("Layer", 0xFFF0F2F7, 0xFF344054, this::showLayerMenu), margin(dp(66), dp(38), 0, 0, dp(5), 0));
        bar.addView(compactButton("Delete", 0xFFFFE8EA, 0xFFB42333, v -> canvas.deleteSelected()), margin(dp(68), dp(38), 0, 0, 0, 0)); return bar;
    }

    private boolean isMeasurementTool(GeometryCanvas.Tool tool){for(GeometryCanvas.Tool candidate:MEASURE_TOOLS)if(candidate==tool)return true;return false;}

    private void showMeasureMenu(){String unit=canvas.getMeasurementUnit();String[]items={"Distance","Angle","Area & perimeter","Coordinates","Circle data","Measurement settings  •  "+unit};new AlertDialog.Builder(this).setTitle("Measure").setItems(items,(d,which)->{if(which<5)selectTool(MEASURE_TOOLS[which]);else showMeasurementSettings();}).setNegativeButton("Cancel",null).show();}

    private void showMeasurementSettings(){LinearLayout panel=verticalPanel();panel.addView(text("Every measurement uses this calibration. Example: if one grid square represents 5 cm, enter 5 and cm.",12,0xFF667085,false));EditText scale=edit("Value of one grid unit",true);scale.setText(GeometryModel.format(canvas.getMeasurementScale()));EditText unit=edit("Unit label, such as cm",false);unit.setText(canvas.getMeasurementUnit());TextView precisionLabel=text("Decimal places: "+canvas.getMeasurementPrecision(),12,0xFF344054,true);SeekBar precision=new SeekBar(this);precision.setMax(4);precision.setProgress(canvas.getMeasurementPrecision());precision.setOnSeekBarChangeListener(simpleSeek(p->precisionLabel.setText("Decimal places: "+p)));panel.addView(text("One grid unit equals",11,0xFF667085,true));panel.addView(scale,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(50)));panel.addView(unit,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(50)));panel.addView(precisionLabel);panel.addView(precision);AlertDialog dialog=new AlertDialog.Builder(this).setTitle("Measurement settings").setView(panel).setNegativeButton("Cancel",null).setPositiveButton("Save",null).create();dialog.setOnShowListener(ignored->dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{try{canvas.setMeasurementSettings(unit.getText().toString(),number(scale),precision.getProgress());dialog.dismiss();}catch(RuntimeException error){showInlineError(scale,error.getMessage());}}));dialog.show();}

    private void showToolLibrary(){final AlertDialog[]holder=new AlertDialog[1];LinearLayout panel=verticalPanel();panel.setPadding(dp(18),dp(4),dp(18),dp(16));panel.addView(text("Choose a tool. Everyday tools stay on the bottom bar; everything else is here when you need it.",12,0xFF667085,false));LinearLayout labs=new LinearLayout(this);labs.setPadding(0,dp(12),0,dp(8));labs.addView(libraryAction("Graph Lab",v->{if(holder[0]!=null)holder[0].dismiss();showGraphDialog();}),new LinearLayout.LayoutParams(0,dp(48),1));labs.addView(libraryAction("Data Table",v->{if(holder[0]!=null)holder[0].dismiss();showDataTableDialog();}),new LinearLayout.LayoutParams(0,dp(48),1));labs.addView(libraryAction("Learn",v->{if(holder[0]!=null)holder[0].dismiss();showManual();}),new LinearLayout.LayoutParams(0,dp(48),1));panel.addView(labs);addToolSection(panel,"DRAW",DRAW_TOOLS,holder);addToolSection(panel,"GEOMETRY",CONSTRUCT_TOOLS,holder);addToolSection(panel,"CONSTRAINTS",CONSTRAIN_TOOLS,holder);addToolSection(panel,"MEASURE",MEASURE_TOOLS,holder);Button calibration=compactButton("Measurement settings",0xFFEEF0FF,0xFF4252C5,v->{if(holder[0]!=null)holder[0].dismiss();showMeasurementSettings();});panel.addView(calibration,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(44)));ScrollView scroll=new ScrollView(this);scroll.addView(panel);holder[0]=new AlertDialog.Builder(this).setTitle("All tools").setView(scroll).setNegativeButton("Close",null).create();holder[0].show();}

    private void addToolSection(LinearLayout panel,String title,GeometryCanvas.Tool[]tools,AlertDialog[]holder){TextView heading=text(title,10,0xFF667085,true);heading.setPadding(0,dp(12),0,dp(5));panel.addView(heading);HorizontalScrollView scroll=new HorizontalScrollView(this);scroll.setHorizontalScrollBarEnabled(false);LinearLayout row=new LinearLayout(this);for(GeometryCanvas.Tool tool:tools){Button button=compactButton(toolGlyph(tool)+"  "+shortLabel(tool),tool==selectedTool?0xFF5B6CFF:0xFFF2F4F7,tool==selectedTool?Color.WHITE:0xFF344054,v->{selectTool(tool);if(holder[0]!=null)holder[0].dismiss();});row.addView(button,margin(dp(118),dp(44),0,0,dp(6),0));}scroll.addView(row);panel.addView(scroll,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(46)));}

    private void selectTool(GeometryCanvas.Tool tool) {
        selectedTool = tool; canvas.setTool(tool); rebuildTools();
        if (tool == GeometryCanvas.Tool.TEXT) showTextToolDialog();
    }

    private void showTextToolDialog() {
        EditText input = edit("Annotation", false); input.setFilters(new InputFilter[]{new InputFilter.LengthFilter(120)});
        new AlertDialog.Builder(this).setTitle("Text annotation").setMessage("Enter the label, then tap its position on the canvas.").setView(input).setNegativeButton("Cancel", null).setPositiveButton("Use text", (d, w) -> canvas.setPendingText(input.getText().toString())).show();
    }

    private void showGraphDialog() {
        LinearLayout panel = verticalPanel(); panel.addView(text("Cartesian, piecewise, polar, parametric, implicit, inequality and derivative plots. Use a, b and c as parameters.",12,0xFF555D6D,false));
        RadioGroup modes=new RadioGroup(this);modes.setOrientation(RadioGroup.VERTICAL);modes.addView(radio("Cartesian y=f(x)",410));modes.addView(radio("Piecewise / conditional",413));modes.addView(radio("Polar r=f(theta)",411));modes.addView(radio("Parametric x(t), y(t)",412));modes.addView(radio("Implicit F(x,y)=0",414));modes.addView(radio("Inequality / region",415));modes.addView(radio("Numerical derivative",416));modes.check(410);panel.addView(modes);
        EditText a = edit("y = sin(x)", false); a.setText("sin(x)"); EditText b = edit("y(t) = sin(3t)", false); b.setVisibility(View.GONE);
        LinearLayout domain = new LinearLayout(this); domain.setOrientation(LinearLayout.HORIZONTAL); EditText min = edit("from", true); EditText max = edit("to", true); min.setText("-1000"); max.setText("1000"); domain.addView(min, new LinearLayout.LayoutParams(0, dp(54), 1)); domain.addView(max, new LinearLayout.LayoutParams(0, dp(54), 1));
        TextView domainLabel = text("Domain", 11, 0xFF6E7686, true); panel.addView(a, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54))); panel.addView(b, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54))); panel.addView(domainLabel); panel.addView(domain);
        LinearLayout parameters=new LinearLayout(this);parameters.setOrientation(LinearLayout.HORIZONTAL);EditText pa=edit("a",true),pb=edit("b",true),pc=edit("c",true);pa.setText("0");pb.setText("1");pc.setText("0");parameters.addView(pa,new LinearLayout.LayoutParams(0,dp(48),1));parameters.addView(pb,new LinearLayout.LayoutParams(0,dp(48),1));parameters.addView(pc,new LinearLayout.LayoutParams(0,dp(48),1));panel.addView(text("Parameters a, b, c",11,0xFF6E7686,true));panel.addView(parameters);
        TextView current = text(canvas.graphExpressions().isEmpty() ? "No curves yet" : canvas.graphExpressions().size() + " curve(s) on this board", 11, 0xFF6E7686, false); panel.addView(current);
        Button trace = compactButton(canvas.isTraceEnabled() ? "Stop trace" : "Trace a Cartesian curve", 0xFFEEF1FF, 0xFF4257C8, v -> {
            canvas.setTraceEnabled(!canvas.isTraceEnabled());
            selectedShelf = Shelf.DRAW; selectedTool = GeometryCanvas.Tool.SELECT; rebuildShelves(); rebuildTools();
            Toast.makeText(this, canvas.isTraceEnabled() ? "Trace enabled — drag across the graph" : "Trace off", Toast.LENGTH_SHORT).show();
        }); panel.addView(trace, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(42)));
        modes.setOnCheckedChangeListener((group, checked) -> {
            if (checked == 410) { a.setHint("y = f(x)");a.setText("a*sin(b*x)+c"); b.setVisibility(View.GONE); min.setText("-1000"); max.setText("1000"); }
            else if (checked == 411) { a.setHint("r = f(theta)"); a.setText("2sin(5theta)"); b.setVisibility(View.GONE); min.setText("0"); max.setText("6.283185"); }
            else if(checked==412){a.setHint("x(t)");a.setText("3cos(t)");b.setVisibility(View.VISIBLE);b.setText("2sin(3t)");min.setText("-6.283185");max.setText("6.283185");}else if(checked==413){a.setText("x<0?-x:x");b.setVisibility(View.GONE);}else if(checked==414){a.setText("x^2+y^2-4");b.setVisibility(View.GONE);}else if(checked==415){a.setText("y<=sin(x)");b.setVisibility(View.GONE);}else{a.setText("sin(x)");b.setVisibility(View.GONE);}
        });
        ScrollView graphScroll=new ScrollView(this);graphScroll.addView(panel);AlertDialog dialog = new AlertDialog.Builder(this).setTitle("Graph Lab").setView(graphScroll).setNegativeButton("Close", null).setNeutralButton("Analyze", null).setPositiveButton("Plot", null).create();
        dialog.setOnShowListener(ignored -> {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
                try {
                    GeometryModel.GraphMode mode=graphMode(modes.getCheckedRadioButtonId());String expA=normalizeGraph(a.getText().toString(),mode),expB=mode==GeometryModel.GraphMode.PARAMETRIC?normalizeExpression(b.getText().toString()):"";canvas.addGraph(mode,expA,expB,number(min),number(max),graphColor(),number(pa),number(pb),number(pc));
                    selectedShelf = Shelf.DRAW; rebuildShelves(); selectTool(GeometryCanvas.Tool.SELECT); dialog.dismiss();
                } catch (RuntimeException ex) { showInlineError(a, ex.getMessage()); }
            });
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v -> new AlertDialog.Builder(this).setTitle("Visible-window analysis").setMessage(canvas.analyzeVisibleGraph()).setPositiveButton("OK", null).show());
        }); dialog.show();
    }

    private static final class Cell{final int row,column;final EditText input;Cell(int r,int c,EditText i){row=r;column=c;input=i;}}private interface ColAction{void use(int c);}private interface PairAction{void use(int x,int y);}
    private void showDataTableDialog(){DataTableModel table=canvas.getDataTable();int pageSize=8,pages=Math.max(1,(table.rowCount()+pageSize-1)/pageSize);tablePage=Math.max(0,Math.min(tablePage,pages-1));LinearLayout panel=verticalPanel();panel.addView(text("Saved formula table • "+table.rowCount()+"×"+table.columnCount(),12,0xFF555D6D,false));HorizontalScrollView horizontal=new HorizontalScrollView(this);LinearLayout grid=new LinearLayout(this);grid.setOrientation(LinearLayout.VERTICAL);horizontal.addView(grid);ArrayList<Cell>editors=new ArrayList<>();LinearLayout heading=new LinearLayout(this);heading.addView(tableLabel("#",42,true));for(int c=0;c<table.columnCount();c++)heading.addView(tableLabel(table.header(c)+(table.formula(c).isEmpty()?"":"  fx"),104,true));grid.addView(heading);int first=tablePage*pageSize,last=Math.min(table.rowCount(),first+pageSize);for(int r=first;r<last;r++){LinearLayout line=new LinearLayout(this);line.addView(tableLabel(Integer.toString(r+1),42,false));for(int c=0;c<table.columnCount();c++){EditText cell=edit("",false);cell.setText(table.formula(c).isEmpty()?table.raw(r,c):table.display(r,c));cell.setTextSize(12);cell.setSelectAllOnFocus(true);cell.setEnabled(table.formula(c).isEmpty());cell.setBackground(roundRect(cell.isEnabled()?0xFFF8F9FC:0xFFECEFFF,6,0xFFD8DCE6,1));line.addView(cell,margin(dp(104),dp(44),dp(1),dp(1),dp(1),0));if(cell.isEnabled())editors.add(new Cell(r,c,cell));}grid.addView(line);}panel.addView(horizontal,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(420)));LinearLayout pager=new LinearLayout(this);pager.setGravity(Gravity.CENTER);Button previous=tableButton("‹"),next=tableButton("›");pager.addView(previous);pager.addView(tableLabel("Page "+(tablePage+1)+" / "+pages,120,true));pager.addView(next);panel.addView(pager);LinearLayout a=new LinearLayout(this);for(String label:new String[]{"Rows/cols","Formula","Fill"})a.addView(tableButton(label),new LinearLayout.LayoutParams(0,dp(42),1));LinearLayout b=new LinearLayout(this);for(String label:new String[]{"Analysis","Plot","CSV"})b.addView(tableButton(label),new LinearLayout.LayoutParams(0,dp(42),1));panel.addView(a);panel.addView(b);ScrollView vertical=new ScrollView(this);vertical.addView(panel);AlertDialog dialog=new AlertDialog.Builder(this).setTitle("Data Table Lab").setView(vertical).setNegativeButton("Close",null).setNeutralButton("Help",null).create();Runnable commit=()->{for(Cell cell:editors)table.setRaw(cell.row,cell.column,cell.input.getText().toString());canvas.tableChanged();};previous.setEnabled(tablePage>0);next.setEnabled(tablePage+1<pages);previous.setOnClickListener(v->{commit.run();tablePage--;dialog.dismiss();showDataTableDialog();});next.setOnClickListener(v->{commit.run();tablePage++;dialog.dismiss();showDataTableDialog();});Button structure=(Button)a.getChildAt(0),formula=(Button)a.getChildAt(1),fill=(Button)a.getChildAt(2),analysis=(Button)b.getChildAt(0),plot=(Button)b.getChildAt(1),csv=(Button)b.getChildAt(2);structure.setOnClickListener(v->{commit.run();dialog.dismiss();showTableStructure();});formula.setOnClickListener(v->{commit.run();dialog.dismiss();showFormula();});fill.setOnClickListener(v->{commit.run();dialog.dismiss();showFill();});analysis.setOnClickListener(v->{commit.run();dialog.dismiss();showAnalysis();});plot.setOnClickListener(v->{commit.run();dialog.dismiss();choosePair((x,y)->{try{canvas.plotTablePoints(x,y,graphColor());Toast.makeText(this,"Points added to canvas",Toast.LENGTH_SHORT).show();}catch(RuntimeException e){showError("Could not plot",e.getMessage());}});});csv.setOnClickListener(v->{commit.run();dialog.dismiss();showCsv();});dialog.setOnDismissListener(d->commit.run());dialog.setOnShowListener(d->dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v->showManualEntry("Data Table basics")));dialog.show();}
    private TextView tableLabel(String value,int width,boolean bold){TextView v=text(value,11,bold?0xFF333B49:0xFF737B8A,bold);v.setGravity(Gravity.CENTER);v.setLayoutParams(new LinearLayout.LayoutParams(dp(width),dp(42)));return v;}private Button tableButton(String label){Button b=compactButton(label,0xFFEEF1FF,0xFF4257C8,null);b.setMinWidth(dp(52));return b;}
    private void chooseColumn(String title,ColAction action){DataTableModel t=canvas.getDataTable();String[]names=new String[t.columnCount()];for(int i=0;i<names.length;i++)names[i]=t.header(i);new AlertDialog.Builder(this).setTitle(title).setItems(names,(d,w)->action.use(w)).show();}private void choosePair(PairAction action){chooseColumn("Choose x column",x->chooseColumn("Choose y column",y->action.use(x,y)));}
    private void showTableStructure(){String[]items={"Add 10 rows","Remove last row","Add column","Remove last column","Rename column","Sort ascending","Sort descending","Clear values & formulas"};new AlertDialog.Builder(this).setTitle("Rows & columns").setItems(items,(d,w)->{DataTableModel t=canvas.getDataTable();if(w==0)for(int i=0;i<10&&t.rowCount()<500;i++)t.addRow();else if(w==1)t.removeRow();else if(w==2){if(t.columnCount()<26)t.addColumn();}else if(w==3)t.removeColumn();else if(w==4)chooseColumn("Rename column",c->{EditText name=edit("Name",false);name.setText(t.header(c));new AlertDialog.Builder(this).setTitle("Rename").setView(name).setPositiveButton("Save",(x,y)->{t.setHeader(c,name.getText().toString());canvas.tableChanged();showDataTableDialog();}).show();});else if(w==5||w==6)chooseColumn("Sort by",c->{t.sort(c,w==5);canvas.tableChanged();showDataTableDialog();});else t.clear();canvas.tableChanged();if(w<4||w==7)showDataTableDialog();}).show();}
    private void showFormula(){chooseColumn("Computed column",c->{DataTableModel t=canvas.getDataTable();EditText input=edit("x^2 or score>=50?1:0",false);input.setText(t.formula(c));new AlertDialog.Builder(this).setTitle("Formula for "+t.header(c)).setMessage("Use headings, A–Z, c1–c26, row and math functions. Blank makes it editable.").setView(input).setNegativeButton("Cancel",null).setPositiveButton("Apply",(d,w)->{try{t.setFormula(c,input.getText().toString());canvas.tableChanged();showDataTableDialog();}catch(RuntimeException e){showError("Formula error",e.getMessage());}}).show();});}
    private void showFill(){chooseColumn("Fill column",c->{LinearLayout p=verticalPanel();EditText start=edit("Start",true),step=edit("Step",true);start.setText("0");step.setText("1");p.addView(start);p.addView(step);new AlertDialog.Builder(this).setTitle("Fill series").setView(p).setPositiveButton("Fill",(d,w)->{try{canvas.getDataTable().fill(c,number(start),number(step));canvas.tableChanged();showDataTableDialog();}catch(RuntimeException e){showError("Fill error",e.getMessage());}}).show();});}
    private void showAnalysis(){String[]items={"Descriptive summary","Pearson correlation","Linear regression","Quadratic regression","Exponential regression"};new AlertDialog.Builder(this).setTitle("Table analysis").setItems(items,(d,w)->{DataTableModel t=canvas.getDataTable();if(w==0)chooseColumn("Summarize",c->showReport(t.summarize(c).report(t.header(c)),null));else choosePair((x,y)->{if(w==1)showReport("Pearson r = "+formatNumber(t.correlation(x,y)),null);else try{DataTableModel.Regression kind=w==2?DataTableModel.Regression.LINEAR:w==3?DataTableModel.Regression.QUADRATIC:DataTableModel.Regression.EXPONENTIAL;DataTableModel.Fit fit=t.regression(x,y,kind);showReport(fit.report(),()->canvas.plotRegression(fit,graphColor()));}catch(RuntimeException e){showError("Analysis unavailable",e.getMessage());}});}).show();}private void showReport(String report,Runnable plot){AlertDialog.Builder b=new AlertDialog.Builder(this).setTitle("Data Lab result").setMessage(report).setPositiveButton("Copy",(d,w)->copyText("Axiom Data result",report)).setNegativeButton("Close",null);if(plot!=null)b.setNeutralButton("Plot fit",(d,w)->plot.run());b.show();}
    private void showCsv(){String[]items={"Export raw CSV","Export computed CSV","Import CSV file","Paste CSV text","Copy computed CSV"};new AlertDialog.Builder(this).setTitle("CSV").setItems(items,(d,w)->{if(w<2)exportBytes(canvas.getDataTable().toCsv(w==1).getBytes(StandardCharsets.UTF_8),"text/csv","csv");else if(w==2){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("text/*");startActivityForResult(i,IMPORT_CSV);}else if(w==3){EditText input=edit("Paste CSV",false);input.setSingleLine(false);input.setMinLines(8);new AlertDialog.Builder(this).setTitle("Paste CSV").setView(input).setPositiveButton("Import",(x,y)->{canvas.replaceDataTable(DataTableModel.fromCsv(input.getText().toString()));tablePage=0;showDataTableDialog();}).show();}else{copyText("Axiom CSV",canvas.getDataTable().toCsv(true));showDataTableDialog();}}).show();}
    private void showManual(){LinearLayout panel=verticalPanel();EditText search=edit("Search every tool…",false);LinearLayout results=new LinearLayout(this);results.setOrientation(LinearLayout.VERTICAL);ScrollView list=new ScrollView(this);list.addView(results);panel.addView(search);panel.addView(list,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(440)));Runnable rebuild=()->{results.removeAllViews();for(ManualContent.Entry entry:ManualContent.search(search.getText().toString())){Button item=new Button(this);item.setAllCaps(false);item.setGravity(Gravity.START|Gravity.CENTER_VERTICAL);item.setText(entry.title+"\n"+entry.category);item.setTextSize(12);item.setOnClickListener(v->showManualEntry(entry.title));results.addView(item,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(58)));}};search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int b,int c){rebuild.run();}public void afterTextChanged(Editable e){}});rebuild.run();new AlertDialog.Builder(this).setTitle("Instructions & tool manual").setView(panel).setPositiveButton("Done",null).show();}
    private void showManualEntry(String title){for(ManualContent.Entry entry:ManualContent.search(title))if(entry.title.equals(title)){TextView body=text(entry.text(),14,0xFF303744,false);body.setTextIsSelectable(true);body.setPadding(dp(22),dp(12),dp(22),dp(12));ScrollView scroll=new ScrollView(this);scroll.addView(body);new AlertDialog.Builder(this).setTitle(entry.category).setView(scroll).setPositiveButton("Done",null).show();return;}}

    private void showExactDialog() {
        GeometryCanvas.EditSpec selectedSpec = canvas.selectedEditSpec();
        if (selectedSpec != null) { showNumericDialog(selectedSpec.title, selectedSpec.labels, selectedSpec.values, values -> canvas.applySelectedExact(values)); return; }
        String[] labels; double[] values;
        switch (selectedTool) {
            case POINT: case COORDINATE: labels = new String[]{"x", "y"}; values = new double[]{0, 0}; break;
            case SEGMENT: case LINE: case RAY: case RULER: labels = new String[]{"x₁", "y₁", "x₂", "y₂"}; values = new double[]{0, 0, 4, 0}; break;
            case CIRCLE: case CIRCLE_MEASURE: labels = new String[]{"centre x", "centre y", "radius"}; values = new double[]{0, 0, 2}; break;
            case ELLIPSE: labels = new String[]{"centre x", "centre y", "radius x", "radius y"}; values = new double[]{0, 0, 3, 2}; break;
            case RECTANGLE: labels = new String[]{"x₁", "y₁", "x₂", "y₂"}; values = new double[]{-2, -1.5, 2, 1.5}; break;
            case REGULAR_POLYGON: labels = new String[]{"centre x", "centre y", "radius", "rotation °"}; values = new double[]{0, 0, 2, 90}; break;
            default: Toast.makeText(this, "Use tap construction for this tool, or select an object to transform it numerically", Toast.LENGTH_LONG).show(); return;
        }
        showNumericDialog("Exact " + selectedTool.label.toLowerCase(Locale.US), labels, values, result -> canvas.createExact(selectedTool, result));
    }

    private interface NumericAction { void apply(double[] values); }
    private void showNumericDialog(String title, String[] labels, double[] values, NumericAction action) {
        LinearLayout panel = verticalPanel(); EditText[] inputs = new EditText[labels.length];
        for (int i = 0; i < labels.length; i++) { TextView label = text(labels[i], 11, 0xFF596171, true); inputs[i] = edit(labels[i], true); inputs[i].setText(GeometryModel.format(values[i])); panel.addView(label); panel.addView(inputs[i], new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48))); }
        AlertDialog dialog = new AlertDialog.Builder(this).setTitle(title).setView(panel).setNegativeButton("Cancel", null).setPositiveButton("Apply", null).create();
        dialog.setOnShowListener(ignored -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> { try { double[] result = new double[inputs.length]; for (int i = 0; i < inputs.length; i++) result[i] = number(inputs[i]); action.apply(result); dialog.dismiss(); } catch (RuntimeException error) { showInlineError(inputs[0], error.getMessage()); } })); dialog.show();
    }

    private void showSelectionInspector() {
        String[] actions = {"Rename", "Edit exact geometry", "Transform", "Stroke & fill", "Reflect across x-axis", "Reflect across y-axis"};
        new AlertDialog.Builder(this).setTitle(canvas.getSelectedName()).setItems(actions, (d, which) -> {
            switch (which) {
                case 0: showRenameObject(); break;
                case 1: GeometryCanvas.EditSpec spec = canvas.selectedEditSpec(); if (spec == null) Toast.makeText(this, "Use Transform for this object type", Toast.LENGTH_SHORT).show(); else showNumericDialog(spec.title, spec.labels, spec.values, canvas::applySelectedExact); break;
                case 2: showTransformDialog(); break;
                case 3: showObjectStyleDialog(); break;
                case 4: canvas.reflectSelected(true); break;
                case 5: canvas.reflectSelected(false); break;
                default: break;
            }
        }).show();
    }
    private void showRenameObject() { EditText input = edit("Object name", false); input.setText(canvas.getSelectedName()); input.setFilters(new InputFilter[]{new InputFilter.LengthFilter(60)}); new AlertDialog.Builder(this).setTitle("Rename object").setView(input).setNegativeButton("Cancel", null).setPositiveButton("Rename", (d, w) -> canvas.renameSelected(input.getText().toString())).show(); }
    private void showTransformDialog() {
        showNumericDialog("Transform selection", new String[]{"move x", "move y", "rotate °", "scale factor"}, new double[]{0, 0, 0, 1}, v -> { if (v[3] <= .01 || v[3] > 100) throw new IllegalArgumentException("Scale must be between 0.01 and 100"); canvas.transformSelected(v[0], v[1], v[2], v[3]); });
    }
    private void showObjectStyleDialog() {
        LinearLayout panel = verticalPanel(); TextView dashLabel = text("Line style", 12, 0xFF596171, true); panel.addView(dashLabel);
        RadioGroup dash = new RadioGroup(this); dash.setOrientation(RadioGroup.HORIZONTAL); dash.addView(radio("Solid", 510)); dash.addView(radio("Dash", 511)); dash.addView(radio("Dot", 512)); dash.check(510 + canvas.getSelectedDash()); panel.addView(dash);
        TextView fillValue = text("Fill " + Math.round(canvas.getSelectedFill() * 100) + "%", 12, 0xFF596171, true); SeekBar fill = new SeekBar(this); fill.setMax(35); fill.setProgress(Math.round(canvas.getSelectedFill() * 100)); fill.setOnSeekBarChangeListener(simpleSeek(p -> fillValue.setText("Fill " + p + "%"))); panel.addView(fillValue); panel.addView(fill);
        new AlertDialog.Builder(this).setTitle("Stroke & fill").setView(panel).setNegativeButton("Cancel", null).setPositiveButton("Apply", (d, w) -> canvas.setSelectedStyle(dash.getCheckedRadioButtonId() - 510, fill.getProgress() / 100f)).show();
    }

    private void showLayerMenu(View anchor) {
        PopupMenu popup = new PopupMenu(this, anchor); Menu menu = popup.getMenu();
        menu.add(0, 601, 0, "Bring to front"); menu.add(0, 602, 1, "Move forward"); menu.add(0, 603, 2, "Move backward"); menu.add(0, 604, 3, "Send to back");
        menu.add(0, 605, 4, canvas.isSelectedLocked() ? "Unlock object" : "Lock object"); menu.add(0, 606, 5, "Hide object"); menu.add(0, 607, 6, "All objects…");
        popup.setOnMenuItemClickListener(item -> { switch (item.getItemId()) { case 601:canvas.bringSelectedToFront();break;case 602:canvas.moveSelectedForward();break;case 603:canvas.moveSelectedBackward();break;case 604:canvas.sendSelectedToBack();break;case 605:canvas.toggleSelectedLocked();break;case 606:canvas.toggleSelectedVisible();break;case 607:showObjectManager();break;default:return false;} return true; }); popup.show();
    }
    private void showSelectionActions(View anchor){PopupMenu p=new PopupMenu(this,anchor);Menu m=p.getMenu();m.add(0,700,0,"Duplicate");m.add(0,701,1,"Lasso selection");m.add(0,702,2,"Select all visible");m.add(0,703,3,"Group");m.add(0,704,4,"Ungroup");SubMenu align=m.addSubMenu("Align / distribute");String[]names={"Align left","Align right","Align bottom","Align top","Centre horizontally","Centre vertically","Distribute horizontally","Distribute vertically"};for(int i=0;i<names.length;i++)align.add(0,710+i,i,names[i]);SubMenu constraints=m.addSubMenu("Dynamic constraint");String[]labels={"Parallel","Perpendicular","Equal length","Fixed length","Fixed angle","Midpoint","Point on object"};for(int i=0;i<labels.length;i++)constraints.add(0,720+i,i,labels[i]);m.add(0,705,8,"Duplicate pattern…");m.add(0,706,9,"Geometry solver");p.setOnMenuItemClickListener(item->{int id=item.getItemId();if(id==700)canvas.duplicateSelected();else if(id==701)canvas.startLassoSelection();else if(id==702)canvas.selectAllVisible();else if(id==703)canvas.groupSelection();else if(id==704)canvas.ungroupSelection();else if(id>=710&&id<=715)canvas.alignSelection(id-710);else if(id==716||id==717)canvas.distributeSelection(id==716);else if(id>=720&&id<=726){String[]types={"PARALLEL","PERPENDICULAR","EQUAL_LENGTH","FIXED_LENGTH","FIXED_ANGLE","MIDPOINT","POINT_ON_OBJECT"};Toast.makeText(this,canvas.addConstraint(types[id-720]),Toast.LENGTH_LONG).show();}else if(id==705)showPattern();else if(id==706)showSolver();else return false;return true;});p.show();}
    private void showPattern(){LinearLayout p=verticalPanel();EditText count=edit("Copies",true),dx=edit("Δx",true),dy=edit("Δy",true),angle=edit("Δ rotation °",true);count.setText("5");dx.setText("1");dy.setText("0");angle.setText("0");p.addView(count);p.addView(dx);p.addView(dy);p.addView(angle);new AlertDialog.Builder(this).setTitle("Duplicate pattern").setView(p).setPositiveButton("Create",(d,w)->canvas.duplicatePattern((int)number(count),number(dx),number(dy),number(angle))).show();}private void showSolver(){String report=canvas.solveSelection();new AlertDialog.Builder(this).setTitle("Geometry solver").setMessage(report).setPositiveButton("Copy",(d,w)->copyText("Axiom solver",report)).setNegativeButton("Close",null).show();}
    private void showObjectManager() {
        List<String> objects = canvas.objectSummaries(); if (objects.isEmpty()) { Toast.makeText(this, "This board has no objects", Toast.LENGTH_SHORT).show(); return; }
        new AlertDialog.Builder(this).setTitle("Objects • top layer first").setItems(objects.toArray(new String[0]), (d, which) -> { canvas.selectDisplayObject(which); Toast.makeText(this, "Selected — use Layer or Inspect", Toast.LENGTH_SHORT).show(); }).setNegativeButton("Close", null).show();
    }

    private void showBoardsDialog() {
        List<GeometryCanvas.BoardInfo> boards = canvas.boards(); String[] names = new String[boards.size()]; for (int i = 0; i < names.length; i++) names[i] = boards.get(i).title + (boards.get(i).title.equals(canvas.getActiveBoardTitle()) ? "  ✓" : "");
        AlertDialog dialog = new AlertDialog.Builder(this).setTitle("Boards").setItems(names, (d, which) -> { canvas.switchBoard(boards.get(which).id); refreshBoardTitle(); }).setNegativeButton("Close", null).setNeutralButton("Manage current", null).setPositiveButton("New board", null).create();
        dialog.setOnShowListener(ignored -> { dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> showNewBoard(false)); dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v -> showManageBoard()); }); dialog.show();
    }
    private void showNewBoard(boolean duplicate) {
        EditText name = edit("Board name", false); name.setText(duplicate ? canvas.getActiveBoardTitle() + " copy" : "Untitled board"); name.setSelectAllOnFocus(true);
        new AlertDialog.Builder(this).setTitle(duplicate ? "Duplicate board" : "New board").setView(name).setNegativeButton("Cancel", null).setPositiveButton("Create", (d, w) -> { if (duplicate) canvas.duplicateCurrentBoard(name.getText().toString()); else canvas.createBoard(name.getText().toString()); refreshBoardTitle(); }).show();
    }
    private void showManageBoard() {
        String[] actions = {"Rename", "Duplicate", "Delete"}; new AlertDialog.Builder(this).setTitle(canvas.getActiveBoardTitle()).setItems(actions, (d, which) -> { if (which == 0) showRenameBoard(); else if (which == 1) showNewBoard(true); else confirmDeleteBoard(); }).show();
    }
    private void showRenameBoard() { EditText name = edit("Board name", false); name.setText(canvas.getActiveBoardTitle()); name.setSelectAllOnFocus(true); new AlertDialog.Builder(this).setTitle("Rename board").setView(name).setNegativeButton("Cancel", null).setPositiveButton("Rename", (d, w) -> { canvas.renameCurrentBoard(name.getText().toString()); refreshBoardTitle(); }).show(); }
    private void confirmDeleteBoard() { new AlertDialog.Builder(this).setTitle("Delete this board?").setMessage("This cannot be undone. Other boards are unaffected.").setNegativeButton("Cancel", null).setPositiveButton("Delete", (d, w) -> { if (!canvas.deleteCurrentBoard()) Toast.makeText(this, "Keep at least one board", Toast.LENGTH_SHORT).show(); refreshBoardTitle(); }).show(); }
    private void refreshBoardTitle() { if (boardTitle != null && canvas != null) boardTitle.setText(canvas.getActiveBoardTitle()); }

    private void showColorDialog() {
        String[] names = {"Ink", "Blue", "Red", "Green", "Amber", "Violet", "Pink", "Black", "Cyan", "Olive"};
        new AlertDialog.Builder(this).setTitle("Drawing colour").setItems(names, (d, which) -> { canvas.setDrawColor(PALETTE[which]); colorButton.setTextColor(PALETTE[which]); }).show();
    }
    private void showWidthDialog() {
        LinearLayout panel = verticalPanel(); TextView value = text(Math.round(canvas.getDrawWidth()) + " px", 18, 0xFF202633, true); value.setGravity(Gravity.CENTER); SeekBar seek = new SeekBar(this); seek.setMax(12); seek.setProgress(Math.round(canvas.getDrawWidth()) - 2); seek.setOnSeekBarChangeListener(simpleSeek(p -> value.setText((p + 2) + " px"))); panel.addView(value); panel.addView(seek);
        new AlertDialog.Builder(this).setTitle("Stroke width").setView(panel).setNegativeButton("Cancel", null).setPositiveButton("Apply", (d, w) -> { canvas.setDrawWidth(seek.getProgress() + 2); widthButton.setText(String.valueOf(seek.getProgress() + 2)); }).show();
    }
    private void showRegularSidesDialog() {
        LinearLayout panel = verticalPanel(); TextView value = text(canvas.getRegularSides() + " sides", 18, 0xFF202633, true); value.setGravity(Gravity.CENTER); SeekBar seek = new SeekBar(this); seek.setMax(21); seek.setProgress(canvas.getRegularSides() - 3); seek.setOnSeekBarChangeListener(simpleSeek(p -> value.setText((p + 3) + " sides"))); panel.addView(value); panel.addView(seek);
        new AlertDialog.Builder(this).setTitle("Regular polygon").setView(panel).setNegativeButton("Cancel", null).setPositiveButton("Use", (d, w) -> canvas.setRegularSides(seek.getProgress() + 3)).show();
    }

    private void showMoreMenu(View anchor) {
        PopupMenu popup = new PopupMenu(this, anchor); Menu menu = popup.getMenu();
        menu.add(0,16,0,"All tools & workspaces");menu.add(0,17,1,"Measurement settings");menu.add(0,1,2,"Boards"); menu.add(0, 2, 3, "Clear current board"); menu.add(0, 3, 4, "Objects & layers");
        SubMenu paper = menu.addSubMenu("Canvas paper"); paper.add(0, 20, 0, "Cartesian grid"); paper.add(0, 21, 1, "Dot paper"); paper.add(0, 22, 2, "Isometric paper"); paper.add(0, 23, 3, "Plain");
        menu.add(0, 4, 4, "Snap to geometry & grid").setCheckable(true).setChecked(canvas.isSnapEnabled()); menu.add(0, 5, 5, "15° angle snap").setCheckable(true).setChecked(canvas.isAngleSnapEnabled()); menu.add(0, 6, 6, "Dark canvas").setCheckable(true).setChecked(canvas.isDarkCanvas());
        menu.add(0, 7, 7, "Fit drawing to screen"); menu.add(0, 8, 8, "Reset view");
        SubMenu export = menu.addSubMenu("Export / backup"); export.add(0, 30, 0, "PNG image"); export.add(0, 31, 1, "Transparent PNG"); export.add(0, 32, 2, "SVG vector"); export.add(0, 33, 3, "PDF page"); export.add(0, 34, 4, "Axiom project");
        menu.add(0, 9, 10, "Open project file"); menu.add(0, 10, 11, "Instructions & tool manual");menu.add(0,11,12,"Data Table Lab");menu.add(0,12,13,"Construction history");menu.add(0,13,14,"Templates & challenges");menu.add(0,14,15,"Instrument overlay");menu.add(0,15,16,"Recovery & diagnostics"); popup.setOnMenuItemClickListener(this::handleMenu); popup.show();
    }
    private boolean handleMenu(MenuItem item) {
        switch (item.getItemId()) {
            case 16:showToolLibrary();return true;case 17:showMeasurementSettings();return true;
            case 1: showBoardsDialog(); return true; case 2: confirmClearCanvas(); return true; case 3: showObjectManager(); return true;
            case 4: canvas.setSnapEnabled(!canvas.isSnapEnabled()); return true; case 5: canvas.setAngleSnapEnabled(!canvas.isAngleSnapEnabled()); return true; case 6: canvas.setDarkCanvas(!canvas.isDarkCanvas()); return true;
            case 7: canvas.zoomToFit(); return true; case 8: canvas.resetView(); return true; case 9: openProject(); return true; case 10: showManual(); return true;case 11:showDataTableDialog();return true;case 12:showHistory();return true;case 13:showTemplates();return true;case 14:showInstrument();return true;case 15:showRecovery();return true;
            case 20: canvas.setBackgroundStyle(GeometryCanvas.BackgroundStyle.CARTESIAN); return true; case 21: canvas.setBackgroundStyle(GeometryCanvas.BackgroundStyle.DOTS); return true; case 22: canvas.setBackgroundStyle(GeometryCanvas.BackgroundStyle.ISOMETRIC); return true; case 23: canvas.setBackgroundStyle(GeometryCanvas.BackgroundStyle.PLAIN); return true;
            case 30: exportBytes(canvas.renderPng(4096, false), "image/png", "png"); return true; case 31: exportBytes(canvas.renderPng(4096, true), "image/png", "transparent.png"); return true; case 32: exportBytes(canvas.renderSvg(), "image/svg+xml", "svg"); return true; case 33: exportBytes(canvas.renderPdf(), "application/pdf", "pdf"); return true; case 34: exportBytes(canvas.serialize().getBytes(StandardCharsets.UTF_8), "application/json", "axiom.json"); return true;
            default: return false;
        }
    }
    private void confirmClearCanvas() { if (canvas.objectCount() == 0) return; new AlertDialog.Builder(this).setTitle("Clear this board?").setMessage("All objects will be removed. You can undo immediately afterwards.").setNegativeButton("Cancel", null).setPositiveButton("Clear", (d, w) -> canvas.clearAll()).show(); }

    private void exportBytes(byte[] bytes, String mime, String extension) {
        pendingExport = bytes; String stamp = new SimpleDateFormat("yyyyMMdd-HHmm", Locale.US).format(new Date()); String fileName = extension.equals("axiom.json") ? "AxiomCanvas-" + stamp + ".axiom.json" : "AxiomCanvas-" + stamp + "." + extension;
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT); intent.addCategory(Intent.CATEGORY_OPENABLE); intent.setType(mime); intent.putExtra(Intent.EXTRA_TITLE, fileName); startActivityForResult(intent, EXPORT_FILE);
    }
    private void openProject() { Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT); intent.addCategory(Intent.CATEGORY_OPENABLE); intent.setType("application/json"); startActivityForResult(intent, IMPORT_PROJECT); }
    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data); if (resultCode != RESULT_OK || data == null || data.getData() == null) return; Uri uri = data.getData();
        if (requestCode == EXPORT_FILE && pendingExport != null) {
            try (OutputStream out = getContentResolver().openOutputStream(uri)) { if (out == null) throw new IOException("Could not open destination"); out.write(pendingExport); out.flush(); Toast.makeText(this, "Saved successfully", Toast.LENGTH_SHORT).show(); }
            catch (IOException ex) { showError("Export failed", ex.getMessage()); } finally { pendingExport = null; }
        } else if (requestCode == IMPORT_PROJECT || requestCode==IMPORT_CSV) {
            try (InputStream in = getContentResolver().openInputStream(uri)) {
                if (in == null) throw new IOException("Could not open project"); ByteArrayOutputStream bytes = new ByteArrayOutputStream(); byte[] buffer = new byte[8192]; int read;
                while ((read = in.read(buffer)) != -1) { if (bytes.size() + read > 16 * 1024 * 1024) throw new IOException("Project is larger than 16 MB"); bytes.write(buffer, 0, read); }
                if(requestCode==IMPORT_PROJECT){canvas.importProject(bytes.toString("UTF-8"));Toast.makeText(this,"Project opened",Toast.LENGTH_SHORT).show();}else{canvas.replaceDataTable(DataTableModel.fromCsv(bytes.toString("UTF-8")));tablePage=0;showDataTableDialog();}
            } catch (IOException | JSONException ex) { showError("Could not open file", ex.getMessage()); }
        }
    }

    private void showOnboarding() {
        String guide = "DRAW\nPencil supports stylus pressure. Add annotations, select, transform, copy, style, lock, hide or reorder objects.\n\n" +
                "CONSTRUCT & CONSTRAIN\nBuild standard shapes, ellipses and regular polygons, then construct midpoints, parallels, perpendiculars and bisectors. Long-press Regular to choose 3–24 sides.\n\n" +
                "MEASURE\nDistance, angle, polygon area/perimeter, coordinates and complete circle data remain attached to the drawing.\n\n" +
                "PRECISION\n# opens exact numeric entry. Snapping finds endpoints, centres, midpoints and line/circle intersections. Pinch to zoom.\n\n" +
                "GRAPH LAB\nPlot Cartesian, polar and parametric curves, set domains, trace coordinates and analyze the visible window.\n\nEverything autosaves locally. Tap AXIOM at the top to manage named boards.";
        new AlertDialog.Builder(this).setTitle("Axiom Canvas 3.1 — guide").setMessage(guide).setNeutralButton("Full manual",(d,w)->showManual()).setPositiveButton("Start creating", null).show();
    }
    private void showHistory(){int count=canvas.constructionStepCount();if(count==0){Toast.makeText(this,"No construction steps yet",Toast.LENGTH_SHORT).show();return;}LinearLayout p=verticalPanel();TextView label=text("Showing all "+count+" steps",13,0xFF333B49,true);SeekBar timeline=new SeekBar(this);timeline.setMax(count);timeline.setProgress(count);timeline.setOnSeekBarChangeListener(simpleSeek(v->{canvas.setPresentationStep(v);label.setText("Showing "+v+" of "+count+" steps");}));TextView body=text(canvas.constructionInstructions(),12,0xFF555D6D,false);body.setTextIsSelectable(true);ScrollView scroll=new ScrollView(this);scroll.addView(body);p.addView(label);p.addView(timeline);p.addView(scroll,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(300)));AlertDialog d=new AlertDialog.Builder(this).setTitle("Construction history").setView(p).setNegativeButton("Copy instructions",(x,y)->copyText("Axiom construction",canvas.constructionInstructions())).setPositiveButton("Done",null).create();d.setOnDismissListener(x->canvas.stopPresentation());d.show();}
    private void showTemplates(){String[]items={"Coordinate triangle","Circle theorem","Function study","Isometric design","Worksheet"};new AlertDialog.Builder(this).setTitle("Templates & challenges").setMessage("This replaces the current board; duplicate it first if needed.").setItems(items,(d,w)->new AlertDialog.Builder(this).setTitle("Create "+items[w]+"?").setMessage(w==0?"Challenge: find side lengths, area and classification.":w==1?"Challenge: verify the angle subtended by a diameter.":w==2?"Challenge: find roots, vertex and compare graph with table.":"A clean starting surface.").setPositiveButton("Create",(x,y)->canvas.applyTemplate(items[w])).setNegativeButton("Cancel",null).show()).show();}
    private void showInstrument(){String[]labels={"None","Ruler","Compass","Protractor","Set square","Divider"};new AlertDialog.Builder(this).setTitle("Instrument overlay").setSingleChoiceItems(labels,canvas.getInstrument().ordinal(),(d,w)->{canvas.setInstrument(GeometryCanvas.Instrument.values()[w]);d.dismiss();}).show();}
    private void showRecovery(){String[]items={"Create recovery snapshot","Restore snapshot","Copy diagnostic"};new AlertDialog.Builder(this).setTitle("Recovery & diagnostics").setItems(items,(d,w)->{if(w==0){canvas.createRecoverySnapshot();Toast.makeText(this,"Snapshot created",Toast.LENGTH_SHORT).show();}else if(w==1){if(!canvas.hasRecoverySnapshot())showError("No snapshot","Create one first.");else canvas.restoreRecoverySnapshot();}else copyText("Axiom diagnostic",canvas.diagnostics());}).show();}

    private void showStartupFailure(Throwable error) {
        StringWriter trace = new StringWriter(); error.printStackTrace(new PrintWriter(trace)); String report = "Axiom Canvas 3.1.0 startup error\n\n" + trace;
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(24), dp(40), dp(24), dp(24)); root.setBackgroundColor(0xFFF7F8FC);
        TextView title = text("Axiom Canvas could not initialize", 21, 0xFF202633, true); root.addView(title); TextView explanation = text("The app stayed open so the exact error can be copied and reported.", 14, 0xFF515967, false); explanation.setPadding(0, dp(12), 0, dp(12)); root.addView(explanation);
        TextView details = text(report, 11, 0xFF8A2731, false); details.setTextIsSelectable(true); root.addView(details, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));
        Button copy = new Button(this); copy.setText("Copy diagnostic"); copy.setOnClickListener(v -> { ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE); clipboard.setPrimaryClip(ClipData.newPlainText("Axiom Canvas startup error", report)); Toast.makeText(this, "Diagnostic copied", Toast.LENGTH_SHORT).show(); }); root.addView(copy, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52))); setContentView(root);
    }

    @Override public void onToolStatus(String title, String hint, boolean canFinish) { if (toolTitle == null) return; toolTitle.setText(title); toolHint.setText(hint); finishButton.setVisibility(canFinish ? View.VISIBLE : View.GONE); }
    @Override public void onHistoryChanged(boolean canUndo, boolean canRedo) { if (undoButton == null) return; undoButton.setEnabled(canUndo); undoButton.setAlpha(canUndo ? 1f : .35f); redoButton.setEnabled(canRedo); redoButton.setAlpha(canRedo ? 1f : .35f); }
    @Override public void onSelectionChanged(boolean selected) { if (selectionBar != null) selectionBar.setVisibility(selected ? View.VISIBLE : View.GONE); }

    private GeometryModel.GraphMode graphMode(int id){switch(id){case 411:return GeometryModel.GraphMode.POLAR;case 412:return GeometryModel.GraphMode.PARAMETRIC;case 413:return GeometryModel.GraphMode.PIECEWISE;case 414:return GeometryModel.GraphMode.IMPLICIT;case 415:return GeometryModel.GraphMode.INEQUALITY;case 416:return GeometryModel.GraphMode.DERIVATIVE;default:return GeometryModel.GraphMode.CARTESIAN;}}
    private String normalizeGraph(String value,GeometryModel.GraphMode mode){String s=value.trim().replace("×","*").replace("÷","/").replace("−","-");if(mode==GeometryModel.GraphMode.INEQUALITY){if(s.isEmpty())throw new IllegalArgumentException("Enter an inequality");return s;}if(mode==GeometryModel.GraphMode.IMPLICIT){int equals=s.indexOf('=');if(equals>0&&"<>=!".indexOf(s.charAt(equals-1))<0)s=s.substring(0,equals)+"-("+s.substring(equals+1)+")";if(s.isEmpty())throw new IllegalArgumentException("Enter a relation");return s;}return normalizeExpression(s);}
    private void copyText(String label,String value){ClipboardManager clipboard=(ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);clipboard.setPrimaryClip(ClipData.newPlainText(label,value));}private String formatNumber(double value){return Double.isFinite(value)?String.format(Locale.US,"%.6f",value).replaceAll("0+$","").replaceAll("\\.$",""):"not available";}
    @Override public boolean onKeyDown(int keyCode,KeyEvent event){if(getCurrentFocus() instanceof EditText)return super.onKeyDown(keyCode,event);if(event.isCtrlPressed()&&keyCode==KeyEvent.KEYCODE_Z){canvas.undo();return true;}if(event.isCtrlPressed()&&keyCode==KeyEvent.KEYCODE_Y){canvas.redo();return true;}switch(keyCode){case KeyEvent.KEYCODE_DEL:canvas.deleteSelected();return true;case KeyEvent.KEYCODE_G:showGraphDialog();return true;case KeyEvent.KEYCODE_T:showDataTableDialog();return true;case KeyEvent.KEYCODE_H:showManual();return true;case KeyEvent.KEYCODE_PLUS:case KeyEvent.KEYCODE_EQUALS:canvas.zoomBy(1.25f);return true;case KeyEvent.KEYCODE_MINUS:canvas.zoomBy(.8f);return true;case KeyEvent.KEYCODE_0:canvas.zoomToFit();return true;default:return super.onKeyDown(keyCode,event);}}

    private Button iconButton(String glyph, String description, View.OnClickListener click) { Button b = new Button(this); b.setText(glyph); b.setTextSize(22); b.setTextColor(Color.WHITE); b.setGravity(Gravity.CENTER); b.setPadding(0,0,0,0); b.setBackground(roundRect(0,12,0,0)); b.setContentDescription(description); b.setOnClickListener(click); normalizeButton(b); b.setLayoutParams(new LinearLayout.LayoutParams(dp(43),dp(45))); return b; }
    private Button quickToolButton(String glyph,String label,boolean active,View.OnClickListener click){Button b=new Button(this);b.setAllCaps(false);b.setText(glyph+"\n"+label);b.setTextSize(10);b.setGravity(Gravity.CENTER);b.setPadding(dp(2),dp(4),dp(2),dp(3));b.setTextColor(active?0xFF4252C5:0xFF475467);b.setBackground(roundRect(active?0xFFECEEFD:Color.TRANSPARENT,15,0,0));b.setOnClickListener(click);b.setContentDescription(label);normalizeButton(b);return b;}
    private Button libraryAction(String label,View.OnClickListener click){Button b=compactButton(label,0xFFF0F2F7,0xFF344054,click);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(48),1);p.setMargins(0,0,dp(6),0);b.setLayoutParams(p);return b;}
    private Button miniButton(String label, View.OnClickListener click) { Button b = new Button(this); b.setText(label); b.setTextSize(18); b.setTextColor(0xFF252B36); b.setPadding(0,0,0,0); b.setGravity(Gravity.CENTER); b.setBackgroundColor(Color.TRANSPARENT); b.setOnClickListener(click); normalizeButton(b); b.setLayoutParams(new LinearLayout.LayoutParams(dp(42),dp(42))); return b; }
    private Button compactButton(String label,int bg,int fg,View.OnClickListener click) { Button b=new Button(this);b.setAllCaps(false);b.setText(label);b.setTextSize(11);b.setTextColor(fg);b.setPadding(dp(7),0,dp(7),0);b.setGravity(Gravity.CENTER);b.setBackground(roundRect(bg,12,0,0));b.setOnClickListener(click);normalizeButton(b);return b; }
    private void normalizeButton(Button b){b.setMinHeight(0);b.setMinimumHeight(0);b.setMinWidth(0);b.setMinimumWidth(0);}
    private void styleToolButton(Button b,boolean active){b.setTextColor(active?0xFF4252C5:0xFF475467);b.setBackground(roundRect(active?0xFFECEEFD:0xFFF8F9FC,15,active?0xFFCBD2FF:0xFFE4E7EC,1));normalizeButton(b);}
    private TextView text(String value,float size,int color,boolean bold){TextView v=new TextView(this);v.setText(value);v.setTextSize(size);v.setTextColor(color);v.setTypeface(android.graphics.Typeface.create(bold?"sans-serif-medium":"sans-serif",android.graphics.Typeface.NORMAL));return v;}
    private EditText edit(String hint,boolean number){EditText e=new EditText(this);e.setHint(hint);e.setSingleLine(true);e.setTextSize(14);e.setInputType(number?(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL|InputType.TYPE_NUMBER_FLAG_SIGNED):(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS));return e;}
    private RadioButton radio(String label,int id){RadioButton r=new RadioButton(this);r.setText(label);r.setId(id);r.setTextSize(12);return r;}
    private LinearLayout verticalPanel(){LinearLayout p=new LinearLayout(this);p.setOrientation(LinearLayout.VERTICAL);p.setPadding(dp(22),dp(8),dp(22),0);return p;}
    private interface ProgressAction{void update(int progress);} private SeekBar.OnSeekBarChangeListener simpleSeek(ProgressAction action){return new SeekBar.OnSeekBarChangeListener(){@Override public void onProgressChanged(SeekBar s,int p,boolean from){action.update(p);}@Override public void onStartTrackingTouch(SeekBar s){}@Override public void onStopTrackingTouch(SeekBar s){}};}
    private GradientDrawable roundRect(int color,float radius,int strokeColor,float stroke){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));if(strokeColor!=0&&stroke>0)d.setStroke(dp(stroke),strokeColor);return d;}
    private FrameLayout.LayoutParams frame(int w,int h,int gravity,int l,int t,int r,int b){FrameLayout.LayoutParams p=new FrameLayout.LayoutParams(w,h,gravity);p.setMargins(l,t,r,b);return p;}
    private LinearLayout.LayoutParams margin(int w,int h,int l,int t,int r,int b){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(w,h);p.setMargins(l,t,r,b);return p;}
    private String shelfName(Shelf shelf){switch(shelf){case DRAW:return "DRAW";case CONSTRUCT:return "CONSTRUCT";case CONSTRAIN:return "CONSTRAIN";case MEASURE:return "MEASURE";default:return "TOOLS";}}
    private GeometryCanvas.Tool[] toolsFor(Shelf shelf){switch(shelf){case DRAW:return DRAW_TOOLS;case CONSTRUCT:return CONSTRUCT_TOOLS;case CONSTRAIN:return CONSTRAIN_TOOLS;case MEASURE:return MEASURE_TOOLS;default:return DRAW_TOOLS;}}
    private String toolGlyph(GeometryCanvas.Tool tool){switch(tool){case SELECT:return"↖";case PEN:return"✎";case ERASER:return"⌫";case TEXT:return"T";case POINT:return"•";case SEGMENT:return"╱";case LINE:return"↔";case RAY:return"→";case CIRCLE:return"◯";case CIRCLE_MEASURE:return"◎";case ARC:return"◡";case ELLIPSE:return"⬭";case RECTANGLE:return"□";case TRIANGLE:return"△";case POLYGON:return"⬡";case REGULAR_POLYGON:return"⎔";case ANGLE:return"∠";case MIDPOINT:return"⊙";case PARALLEL:return"∥";case PERPENDICULAR:return"⊥";case PERP_BISECTOR:return"⊥̸";case ANGLE_BISECTOR:return"⌁";case RULER:return"▱";case PROTRACTOR:return"⌒";case AREA:return"A";case COORDINATE:return"(x,y)";default:return"·";}}
    private String shortLabel(GeometryCanvas.Tool tool){switch(tool){case CIRCLE:return"Compass";case REGULAR_POLYGON:return"Regular";case PERPENDICULAR:return"Perpend.";case PERP_BISECTOR:return"Perp bis.";case ANGLE_BISECTOR:return"Angle bis.";case CIRCLE_MEASURE:return"Circle data";default:return tool.label;}}
    private String normalizeExpression(String value){String s=value.trim().replace("×","*").replace("÷","/").replace("−","-").replace("²","^2").replace("³","^3");int equals=s.indexOf('=');if(equals>=0)s=s.substring(equals+1).trim();if(s.isEmpty())throw new IllegalArgumentException("Enter an expression");return s;}
    private double number(EditText input){String value=input.getText().toString().trim();if(value.isEmpty())throw new IllegalArgumentException("Complete every field");try{return Double.parseDouble(value);}catch(NumberFormatException e){throw new IllegalArgumentException("Invalid number: "+value);}}
    private void showInlineError(EditText input,String message){input.setError(message==null?"Invalid value":message);input.requestFocus();}
    private void showError(String title,String message){new AlertDialog.Builder(this).setTitle(title).setMessage(message==null?"Unknown error":message).setPositiveButton("OK",null).show();}
    private int graphColor(){return PALETTE[(canvas.graphExpressions().size()+1)%(PALETTE.length-1)];} private int canvasColor(){return canvas==null?PALETTE[0]:canvas.getDrawColor();} private int dp(float value){return Math.round(value*getResources().getDisplayMetrics().density);}
}
