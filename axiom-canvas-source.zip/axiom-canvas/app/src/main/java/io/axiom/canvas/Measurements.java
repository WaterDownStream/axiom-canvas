package io.axiom.canvas;

import android.graphics.*;
import java.util.*;
import static io.axiom.canvas.GeometryModel.*;

/** One measurement source shared by canvas, inspector and vector export. */
final class Measurements {
    private Measurements() {}
    static boolean supported(GeoObject o){return !(o instanceof GraphObject||o instanceof TextObject||o instanceof FreehandObject);}
    static String[] values(GeoObject o,Viewport v){
        if(o instanceof TwoPointObject){TwoPointObject l=(TwoPointObject)o;return new String[]{(l.kind==Kind.LINE||l.kind==Kind.RAY?"Anchor span  ":"Length  ")+lengthText(distance(l.a,l.b),v)};}
        if(o instanceof PointObject){PointF p=((PointObject)o).point;return new String[]{"x  "+coordinateText(p.x,v),"y  "+coordinateText(p.y,v)};}
        if(o instanceof CircleObject){double r=((CircleObject)o).radius();return new String[]{"Radius  "+lengthText(r,v),"Diameter  "+lengthText(2*r,v),"Circumference  "+lengthText(2*Math.PI*r,v),"Area  "+areaText(Math.PI*r*r,v)};}
        if(o instanceof EllipseObject){EllipseObject e=(EllipseObject)o;return new String[]{"Radii  "+lengthText(e.radiusX(),v)+" / "+lengthText(e.radiusY(),v),"Area  "+areaText(Math.PI*e.radiusX()*e.radiusY(),v)};}
        if(o instanceof ArcObject){ArcObject a=(ArcObject)o;double sweep=normalizeSweep(screenAngle(a.center,a.end)-screenAngle(a.center,a.start));return new String[]{"Sweep  "+angleText(sweep,v),"Arc length  "+lengthText(distance(a.center,a.start)*Math.toRadians(sweep),v)};}
        if(o instanceof PolyObject){PolyObject p=(PolyObject)o;if(!p.closed()){double a=angleDegrees(p.vertices.get(0),p.vertices.get(1),p.vertices.get(2));return new String[]{"Angle  "+(Double.isFinite(a)?angleText(a,v):"undefined")};}return new String[]{"Area  "+areaText(polygonArea(p.vertices),v),"Perimeter  "+lengthText(polygonPerimeter(p.vertices),v)};}
        return new String[0];
    }
    static PointF anchor(GeoObject o,Viewport v){
        PointF p=v.toScreen(o.center());
        if(o instanceof CircleObject){CircleObject c=(CircleObject)o;p=v.toScreen(c.center);p.y-=c.radius()*v.scale;}
        else if(o instanceof EllipseObject){EllipseObject e=(EllipseObject)o;p=v.toScreen(e.center);p.y-=e.radiusY()*v.scale;}
        else if(o instanceof PointObject)p=v.toScreen(((PointObject)o).point);
        p.x+=o.labelDx*v.scale;p.y-=o.labelDy*v.scale;
        return p;
    }
    static boolean shown(GeoObject o,boolean interactive){return supported(o)&&(o.measured||(interactive&&o.selected));}
    static void draw(Canvas c,GeoObject o,Viewport v,float density){
        String[] rows=values(o,v);if(rows.length==0)return;
        // Circle has a compact canvas summary; the inspector contains all four values.
        if(o instanceof CircleObject)rows=new String[]{rows[0],rows[3]};
        Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);p.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));p.setTextSize(12*density);
        float maxWidth=Math.max(90*density,v.width-24*density),width=0;
        for(String row:rows)width=Math.max(width,p.measureText(row));width=Math.min(maxWidth,width+26*density);
        float h=(rows.length*19+16)*density;PointF a=anchor(o,v);
        float x=Math.max(12*density,Math.min(v.width-width-12*density,a.x-width/2));
        float y=Math.max(12*density,Math.min(v.height-h-66*density,a.y-h-20*density));
        o.labelBounds.set(x,y,x+width,y+h);
        p.setColor(v.darkCanvas?0xFA242B3B:0xFAFFFFFF);c.drawRoundRect(o.labelBounds,10*density,10*density,p);
        p.setColor(o.color);c.drawRoundRect(new RectF(x,y,x+3*density,y+h),2*density,2*density,p);
        p.setColor(v.darkCanvas?0xFFF3F4FF:0xFF292C3D);
        for(int i=0;i<rows.length;i++){String row=rows[i];float available=width-24*density;if(p.measureText(row)>available)p.setTextSize(Math.max(8*density,12*density*available/p.measureText(row)));c.drawText(row,x+12*density,y+(21+19*i)*density,p);p.setTextSize(12*density);}
    }
    static String report(GeoObject o,Viewport v){return String.join("\n",values(o,v));}
}
