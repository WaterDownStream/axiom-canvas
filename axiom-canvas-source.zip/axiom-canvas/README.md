# Axiom Canvas 3.1

Axiom Canvas is a compact, offline-first Android geometry workspace: precision construction tools, freehand canvas, measurement system, graphing lab, and formula-aware data table in one permission-free native app.

Version 3.1 introduces a canvas-first interface with six primary bottom actions and an all-tools library for progressive disclosure. Its rebuilt measurement layer adds calibrated units, saved decimal precision, dimension lines and arrows, high-contrast callouts, live previews, and automatic metrics for selected geometry.

## Geometry workspace

- Draw: selection, pressure-aware pencil, eraser, text
- Construct: point, segment, line, ray, circle, arc, ellipse, rectangle, triangle, polygon, regular polygon, angle
- Constrain: midpoint, parallel, perpendicular, perpendicular bisector, angle bisector
- Measure: dimensioned distance, angle, area/perimeter, labelled coordinates, and full circle data
- Per-board measurement calibration, custom units, zero-to-four-place precision, squared area units, and live selection metrics
- Exact numeric creation/editing, geometric/grid/intersection snapping, transforms, styles, object lock/visibility/order
- Lasso multi-selection, groups, alignment/distribution, duplicate patterns, and a geometry solver
- Saved dynamic parallel, perpendicular, equal/fixed length, fixed-angle, midpoint, and point-on-object constraints
- 100-step undo/redo, named boards, autosave, four paper styles, dark canvas, pan/zoom/fit

## Graph Lab

- Cartesian, conditional/piecewise, polar, parametric, implicit, inequality-region, and numerical-derivative modes
- Parameters `a`, `b`, and `c`, per-graph domains, multiple curves, trace, visible-window analysis
- Offline parser with comparisons, ternary conditions, implicit multiplication, powers, factorials, trig, logs, roots, rounding, and common functions

## Data Table Lab

- Up to 500 rows and 26 columns with paging, headings, sorting, add/remove/clear tools
- Computed columns using headings, A–Z, `c1`–`c26`, `row`, math functions, comparisons, and conditionals
- Fill series; descriptive statistics; Pearson correlation; linear, quadratic, and exponential regression with R²
- Scatter points and fitted equations sent directly to the canvas
- CSV import/paste/export with raw or computed values
- Saved inside each board and portable project backup

## Help, projects, and export

- Searchable offline instruction centre covering every tool and workflow
- Construction replay/instruction export, starter templates, guided challenges, physical-instrument overlays, recovery snapshots, and diagnostics
- Backward-compatible v1/v2 project import; v3 saves geometry, graphs, table, canvas, and viewport
- PNG, transparent PNG, SVG, PDF, Axiom project, and CSV export
- No account, ads, analytics, cloud dependency, or Android permissions

## Install

Android 8.0/API 26 or newer is supported. This v3 release uses a new durable owner key because the v2 key password was not retained. Export important v2 work, uninstall v2, install v3, then import the project. Keep the separate owner signing-key archive private; future v3 updates can use it and install in place.

## Build

Java 17, Gradle 8.9, Android Gradle Plugin 8.7.3, compile SDK 35, target SDK 34, min SDK 26. No third-party runtime dependencies.

```bash
./gradlew assembleDebug
```

Copyright © 2026 Annany Pratap Singh. Personal and educational use permitted.
