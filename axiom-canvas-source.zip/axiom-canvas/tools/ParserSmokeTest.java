package io.axiom.canvas;

public final class ParserSmokeTest {
    private static void assertNear(String expression, double x, double expected) {
        double actual = ExpressionParser.compile(expression).evaluate(x);
        if (Math.abs(actual - expected) > 1e-8) throw new AssertionError(expression + ": " + actual + " != " + expected);
    }
    private static void assertNear(double actual,double expected,String label){if(Math.abs(actual-expected)>1e-8)throw new AssertionError(label);}

    public static void main(String[] args) {
        assertNear("2x + 1", 3, 7);
        assertNear("sin(pi/2)", 0, 1);
        assertNear("sqrt(abs(x))", -9, 3);
        assertNear("2^3^2", 0, 512);
        assertNear("max(2, 3x)", 2, 6);
        assertNear("2sin(5theta)", Math.PI / 10, 2);
        assertNear("3cos(t)", 0, 3);
        assertNear("hypot(3,4)", 0, 5);
        assertNear("cbrt(27)+sec(0)", 0, 4);
        ExpressionParser.VariableExpression variables=ExpressionParser.compileVariables("x<0?-x:a*x+b");assertNear(variables.evaluate(n->n.equals("x")?-3:0),3,"piecewise");assertNear(variables.evaluate(n->n.equals("x")?3:n.equals("a")?2:n.equals("b")?1:0),7,"parameters");
        DataTableModel table=new DataTableModel(3,4);table.setHeader(0,"x");table.setHeader(1,"y");table.setHeader(2,"square");for(int r=0;r<4;r++){table.setRaw(r,0,Integer.toString(r+1));table.setRaw(r,1,Integer.toString(2*(r+1)+1));}table.setFormula(2,"x^2");assertNear(table.numeric(3,2),16,"computed column");DataTableModel.Fit fit=table.regression(0,1,DataTableModel.Regression.LINEAR);assertNear(fit.coefficients[0],1,"intercept");assertNear(fit.coefficients[1],2,"slope");DataTableModel csv=DataTableModel.fromCsv("name,value\n\"A, one\",2\nB,4\n");if(!"A, one".equals(csv.raw(0,0)))throw new AssertionError("CSV");
        boolean rejected = false;
        try { ExpressionParser.compile("sin("); } catch (ExpressionParser.ParseException expected) { rejected = true; }
        if (!rejected) throw new AssertionError("Malformed expressions must be rejected");
        System.out.println("Expression parser smoke tests passed");
    }
}
