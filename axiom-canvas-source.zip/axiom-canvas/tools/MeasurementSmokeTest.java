package io.axiom.canvas;

/** Pure formatting checks for the saved measurement calibration model. */
public final class MeasurementSmokeTest {
    private MeasurementSmokeTest() { }

    public static void main(String[] args) {
        GeometryModel.Viewport view = new GeometryModel.Viewport();
        view.measurementUnit = "cm";
        view.measurementScale = 5;
        view.measurementPrecision = 2;
        expect("10.00 cm", GeometryModel.lengthText(2, view));
        expect("100.00 cm²", GeometryModel.areaText(4, view));
        expect("-7.50 cm", GeometryModel.coordinateText(-1.5, view));
        expect("60.00°", GeometryModel.angleText(60, view));
        view.measurementPrecision = 0;
        expect("13 cm", GeometryModel.lengthText(2.5, view));
        System.out.println("MeasurementSmokeTest passed");
    }

    private static void expect(String expected, String actual) {
        if (!expected.equals(actual)) throw new AssertionError("Expected " + expected + " but got " + actual);
    }
}
